<?php
/**
 * Plugin Name: WordPress Animated Popup Plugin
 * Plugin URI: https://wpigo.com/
 * Description: Advanced animated popup system with 22 stunning animated templates, advanced targeting, countdown timers, and WooCommerce integration for WordPress websites.
 * Version: 1.0
 * Author: wpigo
 * Author URI: https://wpigo.com
 * License: Proprietary
 * License URI: https://wpigo.com/license
 * Text Domain: novawanimpop1
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Network: false
 *
 * @package WordPress Animated Popup Plugin
 * @author wpigo
 * @copyright Copyright (c) wpigo
 * @license Proprietary - https://wpigo.com/license
 *
 * LEGAL NOTICE:
 * This plugin is proprietary software owned by wpigo.
 * Unauthorized use, distribution, or modification is strictly prohibited.
 *
 * LICENSE TERMS:
 * - Single Site License: Use on ONE (1) website only
 * - No Redistribution: May not sell, distribute, or share
 * - No Modifications: Reverse engineering prohibited
 * - Commercial Use: Permitted under license terms only
 *
 * For support and licensing: https://wpigo.com
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'wpigo-license.php';
define('NOVAWANIMPOP1_VERSION', '1.0');
define('NOVAWANIMPOP1_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NOVAWANIMPOP1_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NOVAWANIMPOP1_PLUGIN_BASENAME', plugin_basename(__FILE__));

require_once NOVAWANIMPOP1_PLUGIN_PATH . 'includes/novawanimpop1-admin-functions.php';
require_once NOVAWANIMPOP1_PLUGIN_PATH . 'includes/novawanimpop1-frontend-functions.php';
require_once NOVAWANIMPOP1_PLUGIN_PATH . 'includes/novawanimpop1-ajax-functions.php';
require_once NOVAWANIMPOP1_PLUGIN_PATH . 'includes/novawanimpop1-shortcode-functions.php';

register_activation_hook(__FILE__, 'novawanimpop1_activate_plugin');
function novawanimpop1_activate_plugin() {
    $default_settings = array(
        'enable_popups' => true,
        'default_delay' => 3000,
        'animation_speed' => 400,
        'overlay_opacity' => 0.7,
        'close_on_overlay' => true,
        'close_on_esc' => true,
        'mobile_enabled' => true
    );

    if (!get_option('novawanimpop1_settings')) {
        add_option('novawanimpop1_settings', $default_settings);
    }

    if (!get_option('novawanimpop1_popups')) {
        add_option('novawanimpop1_popups', array());
    }

    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'novawanimpop1_deactivate_plugin');
function novawanimpop1_deactivate_plugin() {
    flush_rewrite_rules();
}

add_action('init', 'novawanimpop1_init');
function novawanimpop1_init() {
    load_plugin_textdomain('novawanimpop1', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

add_action('admin_menu', 'novawanimpop1_admin_menu');
add_action('admin_enqueue_scripts', 'novawanimpop1_admin_assets');
add_action('wp_enqueue_scripts', 'novawanimpop1_frontend_assets');
add_action('wp_footer', 'novawanimpop1_render_popups');

add_action('wp_ajax_novawanimpop1_save_popup', 'novawanimpop1_ajax_save_popup');
add_action('wp_ajax_novawanimpop1_delete_popup', 'novawanimpop1_ajax_delete_popup');
add_action('wp_ajax_novawanimpop1_get_popup', 'novawanimpop1_ajax_get_popup');
add_action('wp_ajax_novawanimpop1_toggle_status', 'novawanimpop1_ajax_toggle_status');

add_shortcode('novawanimpop1_popup', 'novawanimpop1_popup_shortcode');
add_shortcode('novawanimpop1_trigger', 'novawanimpop1_trigger_shortcode');

add_filter('plugin_action_links_' . NOVAWANIMPOP1_PLUGIN_BASENAME, 'novawanimpop1_plugin_action_links');
function novawanimpop1_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=animated-popup-plugin') . '">' . __('Settings', 'novawanimpop1') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

add_action('admin_init', 'novawanimpop1_register_settings');
function novawanimpop1_register_settings() {
    register_setting(
        'novawanimpop1_settings_group',
        'novawanimpop1_settings',
        'novawanimpop1_sanitize_settings'
    );
}

function novawanimpop1_sanitize_settings($input) {
    $sanitized = array();
    $sanitized['enable_popups'] = isset($input['enable_popups']) ? (bool)$input['enable_popups'] : false;
    $sanitized['default_delay'] = isset($input['default_delay']) ? absint($input['default_delay']) : 3000;
    $sanitized['animation_speed'] = isset($input['animation_speed']) ? absint($input['animation_speed']) : 400;
    $sanitized['overlay_opacity'] = isset($input['overlay_opacity']) ? floatval($input['overlay_opacity']) : 0.7;
    $sanitized['close_on_overlay'] = isset($input['close_on_overlay']) ? (bool)$input['close_on_overlay'] : true;
    $sanitized['close_on_esc'] = isset($input['close_on_esc']) ? (bool)$input['close_on_esc'] : true;
    $sanitized['mobile_enabled'] = isset($input['mobile_enabled']) ? (bool)$input['mobile_enabled'] : true;
    return $sanitized;
}