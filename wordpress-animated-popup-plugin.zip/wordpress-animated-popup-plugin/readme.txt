=== WordPress Animated Popup Plugin ===
Contributors: wpigo
Tags: popup, modal, conversion, marketing, woocommerce, shop, notifications, countdown, animated
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0
License: Proprietary
License URI: https://wpigo.com/license

Advanced animated popup system with 22 stunning animated templates, targeting options, countdown timers, and WooCommerce integration for WordPress websites.

== Description ==

Create stunning, high-converting animated popups for your WordPress website with our advanced animated popup builder. Perfect for eCommerce stores, lead generation, announcements, and marketing campaigns with eye-catching animations.

**Key Features:**

* **22 Animated Templates** - Choose from beautiful pre-designed animated templates including pulse waves, rotating borders, bounce effects, neon glows, and more
* **Advanced Targeting** - Display popups on specific pages (homepage, shop, product pages, cart, checkout)
* **Multiple Triggers** - Time-based, click-based, scroll-based, and exit-intent triggers
* **Frequency Control** - Control how often popups appear (every page load, once per session, once per day, or custom interval)
* **Countdown Timers** - Create urgency with beautiful animated countdown timers
* **Visual Customization** - Use images or icons with full color and size control
* **Mobile Responsive** - Perfect display on all devices with dedicated mobile optimizations
* **WooCommerce Integration** - Built specifically for online stores
* **Real-time Preview** - See changes instantly in the admin panel

**Template Collection:**

1. Gradient Splash - Purple to Pink elegance
2. Modern Card - Professional blue gradient
3. Elegant Banner - Luxurious gold accent
4. Minimal Box - Clean white design
5. Bold Statement - Energetic red theme
6. Neon Glow - Electric cyan effects
7. Pastel Dream - Soft color harmony
8. Dark Mode - Sophisticated midnight blue
9. Rainbow Edge - Vibrant color mix
10. Glass Effect - Modern frosted style
11. Rainbow Storm - Animated color transitions
12. Neon Cyber - Glowing cyber borders
13. Deep Shadow - Professional floating effect
14. 3D Depth - Immersive perspective view
15. Diagonal Stripes - Dynamic pattern design
16. Wave Pattern - Flowing light effects
17. Matrix Effect - Digital rain animation

**Perfect For:**

* E-commerce stores and WooCommerce shops
* Lead generation and email collection
* Product announcements and promotions
* Special offers and discount campaigns
* Event notifications and reminders
* Newsletter subscriptions

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wordpress-animated-popup-plugin` directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to 'Animated Popup Plugin' in your admin menu
4. Create your first popup and start converting visitors!

== Changelog ==

= 1.0 =
* Initial release
* 22 animated popup templates
* Advanced targeting and trigger system
* Frequency control (every load, per session, daily, custom interval)
* Countdown timer functionality
* Mobile responsive design
* WooCommerce integration
* Real-time preview system

== Upgrade Notice ==

= 1.0 =
Initial release of WordPress Animated Popup Plugin with professional animated templates and advanced features.

== License ==

This plugin is proprietary software owned by wpigo and is protected by copyright law.

**LICENSE TERMS:**
- Single Site License: This license permits use on ONE (1) website only
- No Redistribution: You may not sell, distribute, or share this plugin
- No Modifications: Reverse engineering or code modification is prohibited
- Commercial Use: Permitted only under the terms of this license

**LEGAL NOTICE:**
Unauthorized use, distribution, or modification of this software is strictly prohibited and may result in legal action. wpigo reserves the right to pursue all available legal remedies against violators.

**COPYRIGHT:**
Copyright © wpigo. All rights reserved.

This plugin is sold exclusively through wpigo.com and is subject to the terms and conditions outlined in our license agreement.

For license details: https://wpigo.com/license

== Support ==

For technical support, license inquiries, and plugin documentation, visit: https://wpigo.com/support


== Additional Information ==

**System Requirements:**
- WordPress 5.8 or higher
- PHP 7.4 or higher
- MySQL 5.6 or higher
- Modern web browser support

**Compatibility:**
- Works with all WordPress themes
- Compatible with popular page builders
- Integrates seamlessly with WooCommerce
- Supports WordPress multisite (requires separate licenses)

**Performance:**
- Lightweight and optimized code
- Fast loading times
- Minimal impact on website speed
- Cache-friendly implementation