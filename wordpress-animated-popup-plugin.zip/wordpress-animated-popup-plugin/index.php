<?php
/**
 * Security file to prevent direct access
 *
 * This file prevents direct access to the plugin directory
 * for security purposes.
 *
 * @package WordPress Animated Popup Plugin
 * @version 1.0
 * @author wpigo
 * @copyright Copyright (c) wpigo
 * @license Proprietary - https://wpigo.com/license
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}
require_once plugin_dir_path(__FILE__) . 'wpigo-license.php';
// If someone tries to access this directory directly, redirect to home
if (!defined('WPINC')) {
    header('HTTP/1.0 403 Forbidden');
    exit('Access denied.');
}

// Additional security check
if (!function_exists('add_action')) {
    header('Status: 403 Forbidden');
    header('HTTP/1.1 403 Forbidden');
    exit();
}

/**
 * wpigo - WordPress Animated Popup Plugin
 *
 * This is a premium WordPress plugin developed by wpigo.
 *
 * Unauthorized access, distribution, or modification is prohibited.
 *
 * For licensing information, visit: https://wpigo.com/license
 * For support, visit: https://wpigo.com
 */