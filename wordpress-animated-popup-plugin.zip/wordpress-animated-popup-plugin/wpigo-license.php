<?php
/**
 * WPiGo License System
 *
 * Use the "License" link on the plugins page to activate or reset your license.
 * If you experience any licensing issues, please request support at wpigo.com
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Wpigo_License_System')) {
    class Wpigo_License_System {

    private static $instances = array();
    private $plugin_slug = '';
    private $plugin_name = '';
    private $instance_id = '';

    private function __construct($plugin_slug, $plugin_name) {
        $this->plugin_slug = $plugin_slug;
        $this->plugin_name = $plugin_name;
        $this->instance_id = 'wpigo_license_' . md5($plugin_slug);
        $this->init_hooks();
    }

    public static function init_for_plugin($plugin_slug, $plugin_name) {
        if (isset(self::$instances[$plugin_slug])) {
            return self::$instances[$plugin_slug];
        }
        self::$instances[$plugin_slug] = new self($plugin_slug, $plugin_name);
        return self::$instances[$plugin_slug];
    }

    public static function init_for_file($file) {
    // get_plugins() fonksiyonu için gerekli dosyayı yükle
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugin_dir = basename(dirname($file));
    $all_plugins = get_plugins();  // ✅ Artık tanımlı
    foreach ($all_plugins as $plugin_file => $plugin_data) {
        if (dirname($plugin_file) === $plugin_dir) {
            return self::init_for_plugin($plugin_dir, $plugin_data['Name']);
        }
    }
    return null;
}

    public static function get_instance() {
        $plugin_info = self::detect_plugin();
        if (!$plugin_info) {
            return null;
        }
        $plugin_slug = $plugin_info['slug'];
        $plugin_name = $plugin_info['name'];
        return self::init_for_plugin($plugin_slug, $plugin_name);
    }

    private function init_hooks() {
        $priority = crc32($this->plugin_slug) % 100 + 10;
        add_action('admin_notices', array($this, 'show_license_notice'), $priority);
        add_action('admin_notices', array($this, 'show_announcement_notice'), $priority + 1);
        add_action('admin_init', array($this, 'handle_license_activation'), $priority);
        add_action('admin_init', array($this, 'handle_license_reset'), $priority);
        add_filter('plugin_action_links', array($this, 'add_license_link'), $priority, 2);
        add_action('admin_menu', array($this, 'add_license_page'), $priority);
        add_action('wp_ajax_wpigo_dismiss_announcement', array($this, 'handle_dismiss_announcement'));
    }

    private static function detect_plugin() {
    // get_plugins() fonksiyonu için gerekli dosyayı yükle
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $all_plugins = get_plugins();  // ✅ Artık tanımlı
    $plugin_dir = basename(dirname(__FILE__));
    foreach ($all_plugins as $plugin_file => $plugin_data) {
        if (dirname($plugin_file) === $plugin_dir) {
            return array(
                'slug' => $plugin_dir,
                'name' => $plugin_data['Name']
            );
        }
    }
    return false;
}

    private function get_api_url($endpoint = 'verify') {
        $base_url = 'https://wpigo.com/api/license/';
        return $base_url . $endpoint;
    }

    private function get_site_domain() {
        $url = home_url();
        $parsed = parse_url($url);
        return isset($parsed['host']) ? $parsed['host'] : '';
    }

    private function is_license_active() {
        $license_data = get_option('wpigo_license_' . $this->plugin_slug, array());
        if (empty($license_data) || !is_array($license_data)) {
            return false;
        }
        if (isset($license_data['status']) && $license_data['status'] === 'active') {
            $current_domain = $this->get_site_domain();
            if (isset($license_data['domain']) && $license_data['domain'] === $current_domain) {
                return true;
            }
        }
        return false;
    }

    private function get_license_data() {
        $license_data = get_option('wpigo_license_' . $this->plugin_slug, array());
        return is_array($license_data) ? $license_data : array();
    }

    private function should_show_notice() {
        if ($this->is_license_active()) {
            return false;
        }
        $screen = get_current_screen();
        if (!$screen) {
            return false;
        }
        $allowed_pages = array(
            'dashboard',
            'plugins',
            'themes',
            'update-core',
            'options-general',
        );
        return in_array($screen->id, $allowed_pages);
    }

    public function show_license_notice() {
        if (!$this->should_show_notice()) {
            return;
        }
        ?>
        <div class="notice notice-error wpigo-license-notice wpigo-license-<?php echo esc_attr($this->plugin_slug); ?>" style="position: relative; padding: 15px 20px; border-left-color: #dc3232;">
            <h3 style="margin: 0 0 10px 0; font-size: 14px; font-weight: 600;">
                <strong><?php echo esc_html($this->plugin_name); ?></strong> - License Activation Required
            </h3>
            <p style="margin: 0 0 8px 0; font-size: 13px;">
                <strong>Enter your purchase code to activate your license.</strong>
            </p>
            <p style="margin: 0 0 15px 0; font-size: 11px; color: #646970; line-height: 1.5;">
                <em>Note: Without license activation, you will not be able to receive updates or support, some features may appear to work but many important functions will not operate correctly, and the license agreement requires activation for continued use.</em>
            </p>
            <form method="post" action="" style="display: flex; gap: 10px; align-items: center; max-width: 600px;">
                <?php wp_nonce_field('wpigo_activate_license_' . $this->plugin_slug, 'wpigo_license_nonce'); ?>
                <input type="hidden" name="wpigo_plugin_slug" value="<?php echo esc_attr($this->plugin_slug); ?>">
                <input
                    type="text"
                    name="wpigo_purchase_code"
                    placeholder="WPIGO-XXXX-XXXX-XXXX"
                    required
                    style="padding: 8px 12px; border: 1px solid #7e8993; border-radius: 3px; font-size: 13px; width: 300px; box-shadow: 0 0 0 transparent; transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;"
                    onfocus="this.style.borderColor='#007cba'; this.style.boxShadow='0 0 0 1px #007cba';"
                    onblur="this.style.borderColor='#7e8993'; this.style.boxShadow='0 0 0 transparent';"
                >
                <button
                    type="submit"
                    name="wpigo_activate_license"
                    class="button button-primary"
                    style="height: 36px; padding: 0 16px; font-size: 13px; line-height: 2.15384615; min-height: 30px;"
                >
                    Activate License
                </button>
                <a
                    href="https://wpigo.com/support"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="button button-secondary"
                    style="height: 36px; padding: 0 16px; font-size: 13px; line-height: 2.15384615; min-height: 30px; text-decoration: none; display: inline-flex; align-items: center; gap: 5px;"
                >
                    <span class="dashicons dashicons-sos" style="font-size: 16px;"></span>
                    Get Support
                </a>
            </form>
        </div>
        <?php
    }

    private function call_license_api($purchase_code, $domain, $endpoint = 'verify') {
        $api_url = $this->get_api_url($endpoint);
        $body = array(
            'purchase_code' => $purchase_code,
            'domain' => $domain
        );
        $response = wp_remote_post($api_url, array(
            'timeout' => 15,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($body)
        ));
        if (is_wp_error($response)) {
            return $response;
        }
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);
        if (!$data) {
            return new WP_Error('invalid_response', 'Invalid API response');
        }
        $data['http_code'] = $response_code;
        return $data;
    }

    public function handle_license_activation() {
        if (!isset($_POST['wpigo_activate_license'])) {
            return;
        }
        $plugin_slug = isset($_POST['wpigo_plugin_slug']) ? sanitize_text_field($_POST['wpigo_plugin_slug']) : '';
        if ($plugin_slug !== $this->plugin_slug) {
            return;
        }
        if (!isset($_POST['wpigo_license_nonce']) || !wp_verify_nonce($_POST['wpigo_license_nonce'], 'wpigo_activate_license_' . $plugin_slug)) {
            wp_die('Security verification failed.');
        }
        $purchase_code = isset($_POST['wpigo_purchase_code']) ? sanitize_text_field($_POST['wpigo_purchase_code']) : '';
        if (empty($purchase_code)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p><strong>Error:</strong> Please enter your purchase code.</p></div>';
            });
            return;
        }
        $domain = $this->get_site_domain();
        if (empty($domain)) {
            wp_redirect(add_query_arg(array(
                'page' => 'wpigo-license-' . $plugin_slug,
                'error' => 'invalid_domain'
            ), admin_url('admin.php')));
            exit;
        }
        $api_response = $this->call_license_api($purchase_code, $domain);
        if (is_wp_error($api_response)) {
            wp_redirect(add_query_arg(array(
                'page' => 'wpigo-license-' . $plugin_slug,
                'error' => 'api_error',
                'message' => urlencode($api_response->get_error_message())
            ), admin_url('admin.php')));
            exit;
        }
        if (!isset($api_response['status']) || $api_response['status'] !== 'success') {
            $error_message = isset($api_response['message']) ? $api_response['message'] : 'License activation failed';
            wp_redirect(add_query_arg(array(
                'page' => 'wpigo-license-' . $plugin_slug,
                'error' => 'activation_failed',
                'message' => urlencode($error_message)
            ), admin_url('admin.php')));
            exit;
        }
        if (defined('WPIGO_PRODUCT_SLUG')) {
            $api_product_slug = isset($api_response['data']['product_slug']) ? $api_response['data']['product_slug'] : '';
            if (!empty($api_product_slug) && $api_product_slug !== WPIGO_PRODUCT_SLUG) {
                wp_redirect(add_query_arg(array(
                    'page' => 'wpigo-license-' . $plugin_slug,
                    'error' => 'wrong_product'
                ), admin_url('admin.php')));
                exit;
            }
        }
        $license_data = array(
            'purchase_code' => $purchase_code,
            'domain' => $domain,
            'status' => 'active',
            'activated_at' => current_time('mysql'),
            'product' => isset($api_response['data']['product']) ? $api_response['data']['product'] : '',
            'product_id' => isset($api_response['data']['product_id']) ? $api_response['data']['product_id'] : '',
            'product_slug' => isset($api_response['data']['product_slug']) ? $api_response['data']['product_slug'] : '',
            'api_key' => isset($api_response['data']['api_key']) ? $api_response['data']['api_key'] : '',
            'secret_key' => isset($api_response['data']['secret_key']) ? $api_response['data']['secret_key'] : '',
            'last_check' => current_time('mysql')
        );
        update_option('wpigo_license_' . $plugin_slug, $license_data);

        // Save announcement data if available
        if (isset($api_response['data']['announcement']) && !empty($api_response['data']['announcement'])) {
            update_option('wpigo_announcement_' . $plugin_slug, $api_response['data']['announcement']);
        }
        wp_redirect(add_query_arg(array(
            'page' => 'wpigo-license-' . $plugin_slug,
            'activated' => 'success'
        ), admin_url('admin.php')));
        exit;
    }

    public function add_license_link($actions, $plugin_file) {
        $plugin_dir = dirname($plugin_file);
        if ($plugin_dir === $this->plugin_slug) {
            $license_url = admin_url('admin.php?page=wpigo-license-' . $this->plugin_slug);
            $actions['wpigo_license'] = '<a href="' . esc_url($license_url) . '">License</a>';
            $actions['wpigo_support'] = '<a href="https://wpigo.com/support" target="_blank" rel="noopener noreferrer">Support</a>';
        }
        return $actions;
    }

    public function add_license_page() {
        add_submenu_page(
            null,
            $this->plugin_name . ' - License',
            'License',
            'manage_options',
            'wpigo-license-' . $this->plugin_slug,
            array($this, 'render_license_page')
        );
    }

    public function render_license_page() {
        $license_data = $this->get_license_data();
        $is_active = $this->is_license_active();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($this->plugin_name); ?> - License Information</h1>

            <?php if (isset($_GET['activated']) && $_GET['activated'] === 'success') : ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Success!</strong> Your license has been activated successfully.</p>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['reset']) && $_GET['reset'] === 'success') : ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Success!</strong> Your license has been deactivated on our server and removed from this site. You can now activate it on any domain.</p>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])) : ?>
                <div class="notice notice-error is-dismissible">
                    <p><strong>Error:</strong>
                        <?php
                        $error = sanitize_text_field($_GET['error']);
                        $message = isset($_GET['message']) ? urldecode(sanitize_text_field($_GET['message'])) : '';
                        if ($error === 'invalid_domain') {
                            echo 'Could not determine site domain.';
                        } elseif ($error === 'api_error') {
                            echo 'API Error: ' . esc_html($message);
                        } elseif ($error === 'activation_failed') {
                            echo esc_html($message);
                        } elseif ($error === 'wrong_product') {
                            echo 'This purchase code belongs to a different product. Please check your purchase code and try again.';
                        } else {
                            echo 'An unknown error occurred.';
                        }
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2 style="margin-top: 0;">License Status</h2>

                <?php if ($is_active) : ?>
                    <div style="padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; color: #155724; margin-bottom: 20px;">
                        <p style="margin: 0; font-size: 14px;">
                            <strong style="font-size: 16px;">✓ License Active</strong>
                        </p>
                    </div>

                    <table class="form-table">
                        <tr>
                            <th scope="row">Plugin Name</th>
                            <td><strong><?php echo esc_html($this->plugin_name); ?></strong></td>
                        </tr>
                        <tr>
                            <th scope="row">Purchase Code</th>
                            <td><code style="font-size: 14px; background: #f0f0f1; padding: 5px 10px; border-radius: 3px;"><?php echo esc_html($license_data['purchase_code']); ?></code></td>
                        </tr>
                        <tr>
                            <th scope="row">Licensed Domain</th>
                            <td><strong><?php echo esc_html($license_data['domain']); ?></strong></td>
                        </tr>
                        <tr>
                            <th scope="row">Product Name</th>
                            <td><?php echo esc_html($license_data['product']); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Activated Date</th>
                            <td><?php echo esc_html(date('F j, Y, g:i a', strtotime($license_data['activated_at']))); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Current Site Domain</th>
                            <td>
                                <?php
                                $current_domain = $this->get_site_domain();
                                echo esc_html($current_domain);
                                if ($current_domain !== $license_data['domain']) {
                                    echo ' <span style="color: #d63638;">(⚠️ Domain mismatch!)</span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php if (!empty($license_data['api_key'])) : ?>
                        <tr>
                            <th scope="row">API Key</th>
                            <td>
                                <code style="font-size: 13px; background: #f0f0f1; padding: 8px 12px; border-radius: 3px; display: inline-block; word-break: break-all; max-width: 100%; font-family: 'Courier New', monospace;"><?php echo esc_html($license_data['api_key']); ?></code>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($license_data['secret_key'])) : ?>
                        <tr>
                            <th scope="row">Secret Key</th>
                            <td>
                                <code style="font-size: 13px; background: #f0f0f1; padding: 8px 12px; border-radius: 3px; display: inline-block; word-break: break-all; max-width: 100%; font-family: 'Courier New', monospace;"><?php echo esc_html($license_data['secret_key']); ?></code>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </table>

                    <hr style="margin: 30px 0;">

                    <h3 style="color: #d63638;">Reset & Deactivate License</h3>
                    <p>Warning: This will deactivate your license on our server and remove it from this site. You can activate it again on any domain after reset.</p>

                    <form method="post" action="" onsubmit="return confirm('Are you sure you want to reset and deactivate this license?\n\nThis will:\n• Deactivate the license on our server\n• Remove license data from this site\n• Allow you to use the license on another domain\n\nYou will need to activate it again if you want to continue using it.');">
                        <?php wp_nonce_field('wpigo_reset_license_' . $this->plugin_slug, 'wpigo_reset_nonce'); ?>
                        <input type="hidden" name="wpigo_reset_license" value="1">
                        <input type="hidden" name="wpigo_plugin_slug" value="<?php echo esc_attr($this->plugin_slug); ?>">
                        <button type="submit" class="button button-secondary" style="background: #d63638; color: white; border-color: #d63638;">
                            Reset & Deactivate License
                        </button>
                    </form>

                <?php else : ?>
                    <div style="padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; color: #721c24; margin-bottom: 20px;">
                        <p style="margin: 0; font-size: 14px;">
                            <strong style="font-size: 16px;">✗ No License Found</strong>
                        </p>
                    </div>

                    <h3>Activate Your License</h3>
                    <p>Enter your purchase code to activate your license and receive updates and support.</p>

                    <form method="post" action="">
                        <?php wp_nonce_field('wpigo_activate_license_' . $this->plugin_slug, 'wpigo_license_nonce'); ?>
                        <input type="hidden" name="wpigo_plugin_slug" value="<?php echo esc_attr($this->plugin_slug); ?>">

                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="wpigo_purchase_code">Purchase Code</label>
                                </th>
                                <td>
                                    <input
                                        type="text"
                                        id="wpigo_purchase_code"
                                        name="wpigo_purchase_code"
                                        class="regular-text"
                                        placeholder="WPIGO-XXXX-XXXX-XXXX"
                                        required
                                    >
                                    <p class="description">Enter the purchase code you received after purchase.</p>
                                </td>
                            </tr>
                        </table>

                        <p class="submit">
                            <button type="submit" name="wpigo_activate_license" class="button button-primary">
                                Activate License
                            </button>
                        </p>
                    </form>
                <?php endif; ?>

                <hr style="margin: 30px 0;">

                <div style="text-align: center; padding: 20px 0;">
                    <p style="margin-bottom: 15px; font-size: 14px; color: #646970;">
                        Need help with your license or have questions?
                    </p>
                    <a
                        href="https://wpigo.com/support"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="button button-secondary"
                        style="font-size: 14px; padding: 8px 20px; height: auto; text-decoration: none;"
                    >
                        <span class="dashicons dashicons-sos" style="font-size: 16px; vertical-align: text-bottom; margin-right: 5px;"></span>
                        Get Support
                    </a>
                </div>
            </div>
        </div>
        <?php
    }

    public function handle_license_reset() {
        if (!isset($_POST['wpigo_reset_license'])) {
            return;
        }
        $plugin_slug = isset($_POST['wpigo_plugin_slug']) ? sanitize_text_field($_POST['wpigo_plugin_slug']) : '';
        if ($plugin_slug !== $this->plugin_slug) {
            return;
        }
        if (!isset($_POST['wpigo_reset_nonce']) || !wp_verify_nonce($_POST['wpigo_reset_nonce'], 'wpigo_reset_license_' . $plugin_slug)) {
            wp_die('Security verification failed.');
        }
        $license_data = $this->get_license_data();
        if (!empty($license_data) && isset($license_data['purchase_code']) && isset($license_data['domain'])) {
            $purchase_code = $license_data['purchase_code'];
            $domain = $license_data['domain'];
            $api_response = $this->call_license_api($purchase_code, $domain, 'deactivate');
        }
        delete_option('wpigo_license_' . $plugin_slug);
        wp_redirect(add_query_arg(array(
            'page' => 'wpigo-license-' . $plugin_slug,
            'reset' => 'success'
        ), admin_url('admin.php')));
        exit;
    }

    public function show_announcement_notice() {
        // Get announcement data
        $announcement = get_option('wpigo_announcement_' . $this->plugin_slug);

        if (!$announcement || !is_array($announcement)) {
            return;
        }

        if (!isset($announcement['enabled']) || !$announcement['enabled']) {
            return;
        }

        if (empty($announcement['message'])) {
            return;
        }

        // Check if user has dismissed this announcement
        $dismissed_announcements = get_option('wpigo_dismissed_announcements_' . $this->plugin_slug, array());
        $announcement_id = isset($announcement['id']) ? $announcement['id'] : '';

        if (in_array($announcement_id, $dismissed_announcements)) {
            return;
        }

        $type = isset($announcement['type']) ? $announcement['type'] : 'info';
        $message = wp_kses_post($announcement['message']);

        ?>
        <div class="notice notice-<?php echo esc_attr($type); ?> is-dismissible wpigo-announcement-notice" data-announcement-id="<?php echo esc_attr($announcement_id); ?>" data-plugin-slug="<?php echo esc_attr($this->plugin_slug); ?>" style="position: relative; padding: 15px 20px;">
            <p style="margin: 0;">
                <strong><?php echo esc_html($this->plugin_name); ?>:</strong> <?php echo $message; ?>
            </p>
        </div>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('.wpigo-announcement-notice').on('click', '.notice-dismiss', function() {
                var notice = $(this).closest('.wpigo-announcement-notice');
                var announcementId = notice.data('announcement-id');
                var pluginSlug = notice.data('plugin-slug');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'wpigo_dismiss_announcement',
                        announcement_id: announcementId,
                        plugin_slug: pluginSlug,
                        nonce: '<?php echo wp_create_nonce('wpigo_dismiss_announcement'); ?>'
                    }
                });
            });
        });
        </script>
        <?php
    }

    public function handle_dismiss_announcement() {
        check_ajax_referer('wpigo_dismiss_announcement', 'nonce');

        $announcement_id = isset($_POST['announcement_id']) ? sanitize_text_field($_POST['announcement_id']) : '';
        $plugin_slug = isset($_POST['plugin_slug']) ? sanitize_text_field($_POST['plugin_slug']) : '';

        if (empty($announcement_id) || $plugin_slug !== $this->plugin_slug) {
            wp_send_json_error();
            return;
        }

        $dismissed_announcements = get_option('wpigo_dismissed_announcements_' . $plugin_slug, array());
        if (!in_array($announcement_id, $dismissed_announcements)) {
            $dismissed_announcements[] = $announcement_id;
            update_option('wpigo_dismissed_announcements_' . $plugin_slug, $dismissed_announcements);
        }

        wp_send_json_success();
    }
    }
}

Wpigo_License_System::init_for_file(__FILE__);
