(function($) {
    'use strict';

    var NOVAWANIMPOP1_Admin = {
        previewTimer: null,

        init: function() {
            this.bindEvents();
            this.initColorPickers();
            this.initMediaUploader();
            this.initPreview();
        },

        bindEvents: function() {
            var self = this;

            $('#novawanimpop1-popup-form').on('submit', function(e) {
                e.preventDefault();
                self.savePopup($(this));
            });

            $(document).on('click', '.novawanimpop1-delete-popup', function(e) {
                e.preventDefault();
                if (confirm(novawanimpop1_admin.strings.confirm_delete)) {
                    self.deletePopup($(this).data('popup-id'));
                }
            });

            $(document).on('click', '.novawanimpop1-edit-popup', function(e) {
                e.preventDefault();
                var popupId = $(this).data('popup-id');
                window.location.href = novawanimpop1_admin.edit_url + '&popup_id=' + popupId;
            });

            $(document).on('click', '.novawanimpop1-copy-shortcode', function(e) {
                e.preventDefault();
                self.copyToClipboard($(this).data('shortcode'));
            });

            $('#novawanimpop1-popup-form').on('input change keyup', 'input, textarea, select', function() {
                self.debouncedUpdatePreview();
            });

            $('#novawanimpop1-popup-template').on('change', function() {
                self.updatePreview();
            });

            $('#novawanimpop1-popup-trigger').on('change', function() {
                var trigger = $(this).val();
                if (trigger === 'time') {
                    $('#novawanimpop1-delay-field').show();
                    $('#novawanimpop1-click-selector-field').hide();
                } else if (trigger === 'click') {
                    $('#novawanimpop1-delay-field').hide();
                    $('#novawanimpop1-click-selector-field').show();
                } else {
                    $('#novawanimpop1-delay-field').hide();
                    $('#novawanimpop1-click-selector-field').hide();
                }
            });

            $('#novawanimpop1-popup-countdown').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#novawanimpop1-countdown-end-field').show();
                } else {
                    $('#novawanimpop1-countdown-end-field').hide();
                }
                self.updatePreview();
            });

            $('#novawanimpop1-popup-frequency').on('change', function() {
                var frequency = $(this).val();
                if (frequency === 'custom') {
                    $('#novawanimpop1-frequency-hours-field').show();
                } else {
                    $('#novawanimpop1-frequency-hours-field').hide();
                }
            });

            $(document).on('input change', 'input[type="range"]', function() {
                var value = $(this).val();
                $(this).siblings('.novawanimpop1-range-value').text(value + 'px');
                self.debouncedUpdatePreview();
            });

            $('.novawanimpop1-tab-button').on('click', function() {
                var tab = $(this).data('tab');

                $('.novawanimpop1-tab-button').removeClass('novawanimpop1-active');
                $(this).addClass('novawanimpop1-active');

                $('.novawanimpop1-tab-content').hide();
                $('#novawanimpop1-' + tab + '-tab').show();

                $('#novawanimpop1-visual-type').val(tab);

                self.updatePreview();
            });

            $('#novawanimpop1-choose-icon').on('click', function() {
                $('.novawanimpop1-icon-grid').slideToggle();
            });

            $(document).on('click', '.novawanimpop1-icon-option', function() {
                var iconName = $(this).data('icon');

                $('.novawanimpop1-icon-option').removeClass('novawanimpop1-selected');
                $(this).addClass('novawanimpop1-selected');

                $('#novawanimpop1-selected-icon').attr('class', 'dashicons dashicons-' + iconName);
                $('#novawanimpop1-popup-icon').val(iconName);

                $('.novawanimpop1-icon-grid').slideUp();

                self.updatePreview();
            });

            $('#novawanimpop1-icon-size').on('input', function() {
                var size = $(this).val();
                $('#novawanimpop1-selected-icon').css('font-size', size + 'px');
                self.debouncedUpdatePreview();
            });

            $('#novawanimpop1-icon-position').on('change', function() {
                self.debouncedUpdatePreview();
            });

            $('#novawanimpop1-icon-color, #novawanimpop1-icon-bg').on('input change', function() {
                self.debouncedUpdatePreview();
            });
        },

        initColorPickers: function() {
            var self = this;

            $('.novawanimpop1-color-picker').each(function() {
                var $input = $(this);

                $input.wpColorPicker({
                    change: function(event, ui) {
                        self.debouncedUpdatePreview();
                    },
                    clear: function() {
                        self.debouncedUpdatePreview();
                    },
                    hide: true,
                    palettes: true
                });
            });
        },

        initMediaUploader: function() {
            var self = this;
            var mediaUploader;

            $('#novawanimpop1-upload-image').on('click', function(e) {
                e.preventDefault();

                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }

                mediaUploader = wp.media({
                    title: 'Choose Image',
                    button: {
                        text: 'Choose Image'
                    },
                    multiple: false
                });

                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#novawanimpop1-popup-image').val(attachment.url);
                    self.displayImage(attachment.url);
                    self.updatePreview();
                });

                mediaUploader.open();
            });

            $('#novawanimpop1-remove-image').on('click', function(e) {
                e.preventDefault();
                $('#novawanimpop1-popup-image').val('');
                $('#novawanimpop1-image-preview').removeClass('novawanimpop1-has-image').empty();
                $(this).hide();
                $('#novawanimpop1-upload-image').show();
                self.updatePreview();
            });

            var existingImage = $('#novawanimpop1-popup-image').val();
            if (existingImage) {
                self.displayImage(existingImage);
            }
        },

        displayImage: function(url) {
            $('#novawanimpop1-image-preview')
                .addClass('novawanimpop1-has-image')
                .empty()
                .append($('<img>').attr('src', url).attr('alt', ''));
            $('#novawanimpop1-remove-image').show();
            $('#novawanimpop1-upload-image').hide();
        },

        initPreview: function() {
            this.updatePreview();
        },

        debouncedUpdatePreview: function() {
            var self = this;
            clearTimeout(this.previewTimer);

            $('.novawanimpop1-popup-preview').addClass('novawanimpop1-updating');

            this.previewTimer = setTimeout(function() {
                self.updatePreview();
                $('.novawanimpop1-popup-preview').removeClass('novawanimpop1-updating');
            }, 200);
        },

        updatePreview: function() {
            try {
                var template = $('#novawanimpop1-popup-template').val() || 'template1';
                var title = $('#novawanimpop1-popup-heading').val() || 'Your Popup Title';
                var description = $('#novawanimpop1-popup-description').val() || 'This is your popup description text.';
                var buttonText = $('#novawanimpop1-popup-button-text').val() || 'Click Here';
                var image = $('#novawanimpop1-popup-image').val();
                var showCountdown = $('#novawanimpop1-popup-countdown').is(':checked');
                var visualType = $('.novawanimpop1-tab-button.novawanimpop1-active').data('tab') || 'image';

                var headingSize = parseInt($('#novawanimpop1-popup-heading-size').val()) || 32;
                var headingColor = this.getColorValue('#novawanimpop1-popup-heading-color') || '#ffffff';
                var descriptionSize = parseInt($('#novawanimpop1-popup-description-size').val()) || 16;
                var descriptionColor = this.getColorValue('#novawanimpop1-popup-description-color') || '#ffffff';
                var buttonSize = parseInt($('#novawanimpop1-popup-button-size').val()) || 18;
                var buttonColor = this.getColorValue('#novawanimpop1-popup-button-color') || '#764ba2';
                var buttonBg = this.getColorValue('#novawanimpop1-popup-button-bg') || '#ffffff';

                var previewHtml = '<div class="novawanimpop1-popup-preview-inner novawanimpop1-' + template + '">';
                previewHtml += '<button class="novawanimpop1-popup-close"><span class="dashicons dashicons-no-alt"></span></button>';
                previewHtml += '<div class="novawanimpop1-popup-content">';

                if (visualType === 'icon') {
                    var iconName = $('#novawanimpop1-popup-icon').val() || 'star-filled';
                    var iconSize = parseInt($('#novawanimpop1-icon-size').val()) || 60;
                    var iconColor = this.getColorValue('#novawanimpop1-icon-color') || '#ffffff';
                    var iconBg = this.getColorValue('#novawanimpop1-icon-bg') || 'transparent';
                    var iconPosition = $('#novawanimpop1-icon-position').val() || 'top';

                    previewHtml += '<div class="novawanimpop1-popup-icon novawanimpop1-icon-' + iconPosition + '">';
                    previewHtml += '<span class="dashicons dashicons-' + iconName + '" style="font-size: ' + iconSize + 'px; color: ' + iconColor + '; background: ' + iconBg + '; width: ' + iconSize + 'px; height: ' + iconSize + 'px; line-height: ' + iconSize + 'px; padding: 15px; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center;"></span>';
                    previewHtml += '</div>';
                } else if (image) {
                    previewHtml += '<div class="novawanimpop1-popup-image"><img src="' + image + '" alt=""></div>';
                }

                previewHtml += '<h2 class="novawanimpop1-popup-title" style="font-size: ' + headingSize + 'px; color: ' + headingColor + ';">' + this.escapeHtml(title) + '</h2>';
                previewHtml += '<div class="novawanimpop1-popup-description" style="font-size: ' + descriptionSize + 'px; color: ' + descriptionColor + ';">' + this.escapeHtml(description) + '</div>';

                if (showCountdown) {
                    previewHtml += '<div class="novawanimpop1-countdown">';
                    previewHtml += '<div class="novawanimpop1-countdown-item"><span class="days">05</span><span class="label">Days</span></div>';
                    previewHtml += '<div class="novawanimpop1-countdown-item"><span class="hours">12</span><span class="label">Hours</span></div>';
                    previewHtml += '<div class="novawanimpop1-countdown-item"><span class="minutes">30</span><span class="label">Minutes</span></div>';
                    previewHtml += '<div class="novawanimpop1-countdown-item"><span class="seconds">45</span><span class="label">Seconds</span></div>';
                    previewHtml += '</div>';
                }

                if (buttonText) {
                    previewHtml += '<div class="novawanimpop1-popup-button-wrapper">';
                    previewHtml += '<a href="#" class="novawanimpop1-popup-button" style="font-size: ' + buttonSize + 'px; color: ' + buttonColor + '; background: ' + buttonBg + ';">' + this.escapeHtml(buttonText) + '</a>';
                    previewHtml += '</div>';
                }

                previewHtml += '</div>';
                previewHtml += '</div>';

                $('#novawanimpop1-popup-preview').html(previewHtml);

            } catch (error) {
                console.error('Preview update error:', error);
                $('#novawanimpop1-popup-preview').html('<div class="novawanimpop1-preview-error">Preview Error</div>');
            }
        },

        getColorValue: function(selector) {
            var $input = $(selector);
            var value = $input.val();

            var $colorResult = $input.closest('.wp-picker-input-wrap').find('.wp-color-result');
            if ($colorResult.length) {
                var bgColor = $colorResult.css('background-color');
                if (bgColor && bgColor !== 'transparent') {
                    var hex = this.rgbToHex(bgColor);
                    if (hex) return hex;
                }
            }

            return value || '#ffffff';
        },

        rgbToHex: function(rgb) {
            if (!rgb || rgb === 'transparent') return null;

            var result = rgb.match(/\d+/g);
            if (!result || result.length < 3) return null;

            return '#' +
                ('0' + parseInt(result[0]).toString(16)).slice(-2) +
                ('0' + parseInt(result[1]).toString(16)).slice(-2) +
                ('0' + parseInt(result[2]).toString(16)).slice(-2);
        },

        escapeHtml: function(text) {
            if (!text) return '';
            return text.replace(/[&<>"']/g, function(match) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                }[match];
            });
        },

        savePopup: function(form) {
            var self = this;
            var formData = form.serialize();

            var visualType = $('.novawanimpop1-tab-button.novawanimpop1-active').data('tab') || 'image';
            formData += '&visual_type=' + visualType;

            if (!$('#novawanimpop1-popup-countdown').is(':checked')) {
                formData += '&countdown=0';
            }
            if (!form.find('[name="enabled"]').is(':checked')) {
                formData += '&enabled=0';
            }
            if (!form.find('[name="button_target"]').is(':checked')) {
                formData += '&button_target=0';
            }

            $.ajax({
                url: novawanimpop1_admin.ajax_url,
                type: 'POST',
                data: formData + '&action=novawanimpop1_save_popup&nonce=' + novawanimpop1_admin.nonce,
                beforeSend: function() {
                    form.find('[type="submit"]').prop('disabled', true).text('Saving...');
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotice('success', response.data.message);
                        if (!$('#novawanimpop1-popup-id').val()) {
                            $('#novawanimpop1-popup-id').val(response.data.popup_id);
                        }
                        setTimeout(function() {
                            window.location.href = novawanimpop1_admin.list_url;
                        }, 1500);
                    } else {
                        self.showNotice('error', response.data.message || novawanimpop1_admin.strings.save_error);
                    }
                },
                error: function() {
                    self.showNotice('error', novawanimpop1_admin.strings.save_error);
                },
                complete: function() {
                    form.find('[type="submit"]').prop('disabled', false).html('<span class="dashicons dashicons-saved"></span> Save Popup');
                }
            });
        },

        deletePopup: function(popupId) {
            var self = this;

            $.ajax({
                url: novawanimpop1_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'novawanimpop1_delete_popup',
                    popup_id: popupId,
                    nonce: novawanimpop1_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotice('success', response.data.message);
                        $('tr').has('[data-popup-id="' + popupId + '"]').fadeOut(400, function() {
                            $(this).remove();
                            if ($('.novawanimpop1-popups-table tbody tr').length === 0) {
                                location.reload();
                            }
                        });
                    } else {
                        self.showNotice('error', response.data.message || novawanimpop1_admin.strings.delete_error);
                    }
                },
                error: function() {
                    self.showNotice('error', novawanimpop1_admin.strings.delete_error);
                }
            });
        },

        copyToClipboard: function(text) {
            var self = this;
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(function() {
                    self.showNotice('info', novawanimpop1_admin.strings.copied);
                });
            } else {
                var tempInput = $('<input>');
                $('body').append(tempInput);
                tempInput.val(text).select();
                document.execCommand('copy');
                tempInput.remove();
                self.showNotice('info', novawanimpop1_admin.strings.copied);
            }
        },

        showNotice: function(type, message) {
            var notice = $('<div class="novawanimpop1-notice ' + type + '">');
            notice.html('<span class="dashicons dashicons-' + (type === 'success' ? 'yes' : type === 'error' ? 'warning' : 'info') + '"></span>' + message);
            $('.novawanimpop1-page-title').after(notice);

            setTimeout(function() {
                notice.fadeOut(400, function() {
                    $(this).remove();
                });
            }, 3000);
        },

        loadPopupData: function(popupId) {
            var self = this;

            $.ajax({
                url: novawanimpop1_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'novawanimpop1_get_popup',
                    popup_id: popupId,
                    nonce: novawanimpop1_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        $('#novawanimpop1-popup-id').val(popupId);
                        $('#novawanimpop1-popup-title').val(data.title);
                        $('#novawanimpop1-popup-template').val(data.template);
                        $('#novawanimpop1-popup-trigger').val(data.trigger).trigger('change');
                        $('#novawanimpop1-popup-delay').val(data.delay);
                        $('#novawanimpop1-popup-display').val(data.display_on);
                        $('#novawanimpop1-popup-heading').val(data.heading);
                        $('#novawanimpop1-popup-description').val(data.description);
                        $('#novawanimpop1-popup-button-text').val(data.button_text);
                        $('#novawanimpop1-popup-button-link').val(data.button_link);

                        if (data.heading_size) $('#novawanimpop1-popup-heading-size').val(data.heading_size);
                        if (data.heading_color) $('#novawanimpop1-popup-heading-color').val(data.heading_color);
                        if (data.description_size) $('#novawanimpop1-popup-description-size').val(data.description_size);
                        if (data.description_color) $('#novawanimpop1-popup-description-color').val(data.description_color);
                        if (data.button_size) $('#novawanimpop1-popup-button-size').val(data.button_size);
                        if (data.button_color) $('#novawanimpop1-popup-button-color').val(data.button_color);
                        if (data.button_bg) $('#novawanimpop1-popup-button-bg').val(data.button_bg);

                        if (data.popup_width) $('#novawanimpop1-popup-width').val(data.popup_width);
                        if (data.popup_width_unit) $('[name="popup_width_unit"]').val(data.popup_width_unit);
                        if (data.popup_height) $('#novawanimpop1-popup-height').val(data.popup_height);
                        if (data.popup_height_unit) $('[name="popup_height_unit"]').val(data.popup_height_unit);


                        var visualType = data.visual_type || 'image';
                        $('.novawanimpop1-tab-button').removeClass('novawanimpop1-active');
                        $('.novawanimpop1-tab-button[data-tab="' + visualType + '"]').addClass('novawanimpop1-active');
                        $('.novawanimpop1-tab-content').hide();
                        $('#novawanimpop1-' + visualType + '-tab').show();
                        $('#novawanimpop1-visual-type').val(visualType);

                        if (data.image) {
                            $('#novawanimpop1-popup-image').val(data.image);
                            self.displayImage(data.image);
                        }

                        if (data.icon) {
                            $('#novawanimpop1-popup-icon').val(data.icon);
                            $('#novawanimpop1-selected-icon').attr('class', 'dashicons dashicons-' + data.icon);
                        }
                        if (data.icon_size) $('#novawanimpop1-icon-size').val(data.icon_size);
                        if (data.icon_color) $('#novawanimpop1-icon-color').val(data.icon_color);
                        if (data.icon_bg) $('#novawanimpop1-icon-bg').val(data.icon_bg);
                        if (data.icon_position) $('#novawanimpop1-icon-position').val(data.icon_position);

                        if (data.countdown) {
                            $('#novawanimpop1-popup-countdown').prop('checked', true).trigger('change');
                            $('#novawanimpop1-popup-countdown-end').val(data.countdown_end);
                        }

                        if (data.enabled) {
                            $('[name="enabled"]').prop('checked', true);
                        }

                        if (data.button_target) {
                            $('[name="button_target"]').prop('checked', true);
                        }

                        if (data.frequency) {
                            $('#novawanimpop1-popup-frequency').val(data.frequency).trigger('change');
                        }
                        if (data.frequency_hours) {
                            $('#novawanimpop1-popup-frequency-hours').val(data.frequency_hours);
                        }

                        $('input[type="range"]').each(function() {
                            $(this).siblings('.novawanimpop1-range-value').text($(this).val() + 'px');
                        });

                        setTimeout(function() {
                            self.initColorPickers();
                            self.updatePreview();
                        }, 100);
                    }
                },
                error: function() {
                    self.showNotice('error', 'Error loading popup data');
                }
            });
        }
    };

    $(document).ready(function() {
        NOVAWANIMPOP1_Admin.init();

        var urlParams = new URLSearchParams(window.location.search);
        var popupId = urlParams.get('popup_id');
        if (popupId) {
            NOVAWANIMPOP1_Admin.loadPopupData(popupId);
        }
    });

})(jQuery);