(function($) {
    'use strict';

    var NOVAWANIMPOP1_Frontend = {
        popups: {},
        settings: {},
        shownPopups: [],
        exitIntentTriggered: false,

        init: function() {
            if (typeof novawanimpop1_frontend === 'undefined') {
                return;
            }

            this.popups = novawanimpop1_frontend.popups || {};
            this.settings = novawanimpop1_frontend.settings || {};

            if (Object.keys(this.popups).length === 0) {
                return;
            }

            this.bindEvents();
            this.initPopups();
        },

        bindEvents: function() {
            var self = this;

            $(document).on('click', '.novawanimpop1-popup-close', function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.closePopup($(this).closest('.novawanimpop1-popup-overlay'));
            });

            $(document).on('click', '.novawanimpop1-popup-overlay', function(e) {
                if (e.target === this && self.settings.close_on_overlay !== false) {
                    self.closePopup($(this));
                }
            });

            $(document).on('click', '.novawanimpop1-popup-button', function(e) {
                var $popup = $(this).closest('.novawanimpop1-popup-overlay');
                setTimeout(function() {
                    self.closePopup($popup);
                }, 300);
            });

            if (this.settings.close_on_esc !== false) {
                $(document).on('keydown', function(e) {
                    if (e.key === 'Escape') {
                        self.closeAllPopups();
                    }
                });
            }

            $(window).on('beforeunload', function() {
                if (!self.exitIntentTriggered) {
                    self.triggerExitIntentPopups();
                }
            });

            $(document).on('mouseleave', function(e) {
                if (e.clientY <= 0 && !self.exitIntentTriggered) {
                    self.exitIntentTriggered = true;
                    self.triggerExitIntentPopups();
                }
            });

            $(window).on('scroll', function() {
                self.handleScrollTrigger();
            });
        },

        initPopups: function() {
            var self = this;

            $.each(this.popups, function(popupId, popup) {
                var trigger = popup.trigger || 'time';
                var delay = parseInt(popup.delay) || 3000;

                switch (trigger) {
                    case 'time':
                        setTimeout(function() {
                            self.showPopup(popupId);
                        }, delay);
                        break;

                    case 'click':
                        var selector = popup.click_selector || '';
                        if (selector) {
                            $(document).on('click', selector, function(e) {
                                e.preventDefault();
                                self.showPopup(popupId);
                            });
                        }
                        break;

                    case 'scroll':
                        self.initScrollTrigger(popupId);
                        break;

                    case 'exit':
                        break;
                }

                self.initCountdown(popupId, popup);
            });
        },

        showPopup: function(popupId) {
            if (this.shownPopups.indexOf(popupId) !== -1) {
                return;
            }

            if (!this.isMobileEnabled() && this.isMobile()) {
                return;
            }

            var $popup = $('#novawanimpop1-popup-' + popupId);
            if ($popup.length === 0) {
                return;
            }

            var frequency = $popup.attr('data-frequency') || 'always';
            var frequencyHours = $popup.attr('data-frequency-hours') || '24';

            if (!this.canShowPopup(popupId, frequency, frequencyHours)) {
                return;
            }

            this.shownPopups.push(popupId);

            $popup.fadeIn(this.settings.animation_speed || 400, function() {
                $popup.addClass('novawanimpop1-show');
            });

            this.savePopupShown(popupId, frequency, frequencyHours);
            this.trackPopupView(popupId);
        },

        closePopup: function($popup) {
            var self = this;
            $popup.removeClass('novawanimpop1-show');

            setTimeout(function() {
                $popup.fadeOut(self.settings.animation_speed || 400);
            }, 100);
        },

        closeAllPopups: function() {
            var self = this;
            $('.novawanimpop1-popup-overlay').each(function() {
                self.closePopup($(this));
            });
        },

        initScrollTrigger: function(popupId) {
            this.scrollPopups = this.scrollPopups || [];
            this.scrollPopups.push(popupId);
        },

        handleScrollTrigger: function() {
            if (!this.scrollPopups || this.scrollPopups.length === 0) {
                return;
            }

            var scrollPercent = ($(window).scrollTop() / ($(document).height() - $(window).height())) * 100;

            if (scrollPercent >= 50) {
                var self = this;
                $.each(this.scrollPopups, function(index, popupId) {
                    if (self.shownPopups.indexOf(popupId) === -1) {
                        self.showPopup(popupId);
                    }
                });
                this.scrollPopups = [];
            }
        },

        triggerExitIntentPopups: function() {
            var self = this;
            $.each(this.popups, function(popupId, popup) {
                if (popup.trigger === 'exit' && self.shownPopups.indexOf(popupId) === -1) {
                    self.showPopup(popupId);
                }
            });
        },

        initCountdown: function(popupId, popup) {
            if (!popup.countdown || !popup.countdown_end) {
                return;
            }

            var endDate = new Date(popup.countdown_end).getTime();
            var $countdown = $('#novawanimpop1-popup-' + popupId).find('.novawanimpop1-countdown');

            if ($countdown.length === 0) {
                return;
            }

            var timer = setInterval(function() {
                var now = new Date().getTime();
                var distance = endDate - now;

                if (distance < 0) {
                    clearInterval(timer);
                    $countdown.html('<div class="novawanimpop1-countdown-expired">Offer Expired</div>');
                    return;
                }

                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                $countdown.find('.novawanimpop1-days').text(String(days).padStart(2, '0'));
                $countdown.find('.novawanimpop1-hours').text(String(hours).padStart(2, '0'));
                $countdown.find('.novawanimpop1-minutes').text(String(minutes).padStart(2, '0'));
                $countdown.find('.novawanimpop1-seconds').text(String(seconds).padStart(2, '0'));
            }, 1000);
        },

        isMobile: function() {
            return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
                   window.innerWidth <= 768;
        },

        isMobileEnabled: function() {
            return this.settings.mobile_enabled !== false;
        },

        setCookie: function(name, value, hours) {
            var expires = "";
            if (hours) {
                var date = new Date();
                date.setTime(date.getTime() + (hours * 60 * 60 * 1000));
                expires = "; expires=" + date.toUTCString();
            }
            document.cookie = name + "=" + (value || "") + expires + "; path=/; SameSite=Lax";
        },

        getCookie: function(name) {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) === ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        },

        canShowPopup: function(popupId, frequency, frequencyHours) {
            if (!frequency || frequency === 'always') {
                return true;
            }

            var cookieName = 'novawanimpop1_popup_' + popupId;
            var lastShown = this.getCookie(cookieName);

            if (!lastShown) {
                return true;
            }

            if (frequency === 'once') {
                return false;
            }

            var lastShownTime = parseInt(lastShown);
            var currentTime = new Date().getTime();
            var hoursPassed = (currentTime - lastShownTime) / (1000 * 60 * 60);

            if (frequency === 'daily') {
                return hoursPassed >= 24;
            }

            if (frequency === 'custom') {
                var hours = parseInt(frequencyHours) || 24;
                return hoursPassed >= hours;
            }

            return true;
        },

        savePopupShown: function(popupId, frequency, frequencyHours) {
            if (!frequency || frequency === 'always') {
                return;
            }

            var cookieName = 'novawanimpop1_popup_' + popupId;
            var currentTime = new Date().getTime();
            var hours = 8760;

            if (frequency === 'daily') {
                hours = 24;
            } else if (frequency === 'custom') {
                hours = parseInt(frequencyHours) || 24;
            }

            this.setCookie(cookieName, currentTime, hours);
        },

        trackPopupView: function(popupId) {
            if (typeof novawanimpop1_frontend.ajax_url === 'undefined') {
                return;
            }

            $.ajax({
                url: novawanimpop1_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'novawanimpop1_track_view',
                    popup_id: popupId,
                    nonce: novawanimpop1_frontend.nonce
                },
                success: function(response) {
                    // Tracking completed
                }
            });
        }
    };

    var NOVAWANIMPOP1_ShortcodePopups = {
        init: function() {
            var self = this;
            $('[data-novawanimpop1-popup]').on('click', function(e) {
                e.preventDefault();
                var popupId = $(this).data('novawanimpop1-popup');
                if (popupId && $('#novawanimpop1-popup-' + popupId).length) {
                    NOVAWANIMPOP1_Frontend.showPopup(popupId);
                }
            });
        }
    };

    $(document).ready(function() {
        NOVAWANIMPOP1_Frontend.init();
        NOVAWANIMPOP1_ShortcodePopups.init();
    });

    window.NOVAWANIMPOP1_Frontend = NOVAWANIMPOP1_Frontend;

})(jQuery);