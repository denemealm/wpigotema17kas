<?php
if (!defined('ABSPATH')) {
    exit;
}

function novawanimpop1_popup_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => '',
        'trigger' => 'auto',
        'delay' => 0
    ), $atts, 'novawanimpop1_popup');

    if (empty($atts['id'])) {
        return '';
    }

    $popup_id = sanitize_text_field($atts['id']);
    $trigger = sanitize_text_field($atts['trigger']);
    $delay = absint($atts['delay']);

    $popups = get_option('novawanimpop1_popups', array());

    if (!isset($popups[$popup_id])) {
        return '';
    }

    $popup = $popups[$popup_id];

    if (!isset($popup['enabled']) || !$popup['enabled']) {
        return '';
    }

    if ($trigger === 'auto') {
        novawanimpop1_render_single_popup($popup_id, $popup);
        return '';
    }

    $unique_id = 'novawanimpop1-shortcode-' . $popup_id . '-' . wp_rand(1000, 9999);

    ob_start();
    ?>
    <button class="novawanimpop1-popup-trigger"
            data-popup-id="<?php echo esc_attr($popup_id); ?>"
            data-trigger="<?php echo esc_attr($trigger); ?>"
            data-delay="<?php echo esc_attr($delay); ?>"
            id="<?php echo esc_attr($unique_id); ?>">
        <?php echo isset($popup['button_text']) ? esc_html($popup['button_text']) : __('Open Popup', 'novawanimpop1'); ?>
    </button>

    <script>
    jQuery(document).ready(function($) {
        $('#<?php echo esc_js($unique_id); ?>').on('click', function(e) {
            e.preventDefault();
            var popupId = $(this).data('popup-id');
            var delay = $(this).data('delay') || 0;

            setTimeout(function() {
                if (typeof window.NOVAWANIMPOP1_Frontend !== 'undefined') {
                    window.NOVAWANIMPOP1_Frontend.showPopup(popupId);
                }
            }, delay);
        });
    });
    </script>
    <?php

    novawanimpop1_render_single_popup($popup_id, $popup);

    return ob_get_clean();
}

function novawanimpop1_trigger_shortcode($atts, $content = '') {
    $atts = shortcode_atts(array(
        'popup_id' => '',
        'class' => 'novawanimpop1-trigger-link',
        'style' => '',
        'delay' => 0
    ), $atts, 'novawanimpop1_trigger');

    if (empty($atts['popup_id'])) {
        return $content;
    }

    $popup_id = sanitize_text_field($atts['popup_id']);
    $class = sanitize_text_field($atts['class']);
    $style = sanitize_text_field($atts['style']);
    $delay = absint($atts['delay']);

    $popups = get_option('novawanimpop1_popups', array());

    if (!isset($popups[$popup_id])) {
        return $content;
    }

    $popup = $popups[$popup_id];

    if (!isset($popup['enabled']) || !$popup['enabled']) {
        return $content;
    }

    $unique_id = 'novawanimpop1-trigger-' . $popup_id . '-' . wp_rand(1000, 9999);

    ob_start();
    ?>
    <span class="<?php echo esc_attr($class); ?> novawanimpop1-popup-trigger"
          style="<?php echo esc_attr($style); ?> cursor: pointer;"
          data-popup-id="<?php echo esc_attr($popup_id); ?>"
          data-delay="<?php echo esc_attr($delay); ?>"
          id="<?php echo esc_attr($unique_id); ?>">
        <?php echo do_shortcode($content); ?>
    </span>

    <script>
    jQuery(document).ready(function($) {
        $('#<?php echo esc_js($unique_id); ?>').on('click', function(e) {
            e.preventDefault();
            var popupId = $(this).data('popup-id');
            var delay = $(this).data('delay') || 0;

            setTimeout(function() {
                if (typeof window.NOVAWANIMPOP1_Frontend !== 'undefined') {
                    window.NOVAWANIMPOP1_Frontend.showPopup(popupId);
                }
            }, delay);
        });
    });
    </script>
    <?php

    novawanimpop1_render_single_popup($popup_id, $popup);

    return ob_get_clean();
}

function novawanimpop1_popup_list_shortcode($atts) {
    $atts = shortcode_atts(array(
        'template' => '',
        'display_on' => '',
        'enabled_only' => 'true',
        'limit' => -1,
        'show_title' => 'true',
        'show_description' => 'true',
        'show_button' => 'true'
    ), $atts, 'novawanimpop1_popup_list');

    $template = sanitize_text_field($atts['template']);
    $display_on = sanitize_text_field($atts['display_on']);
    $enabled_only = $atts['enabled_only'] === 'true';
    $limit = intval($atts['limit']);
    $show_title = $atts['show_title'] === 'true';
    $show_description = $atts['show_description'] === 'true';
    $show_button = $atts['show_button'] === 'true';

    $popups = get_option('novawanimpop1_popups', array());

    if (empty($popups)) {
        return '<p>' . __('No popups found.', 'novawanimpop1') . '</p>';
    }

    $filtered_popups = array();

    foreach ($popups as $popup_id => $popup) {
        if ($enabled_only && (!isset($popup['enabled']) || !$popup['enabled'])) {
            continue;
        }

        if (!empty($template) && isset($popup['template']) && $popup['template'] !== $template) {
            continue;
        }

        if (!empty($display_on) && isset($popup['display_on']) && $popup['display_on'] !== $display_on) {
            continue;
        }

        $filtered_popups[$popup_id] = $popup;
    }

    if ($limit > 0) {
        $filtered_popups = array_slice($filtered_popups, 0, $limit, true);
    }

    ob_start();
    ?>
    <div class="novawanimpop1-popup-list">
        <?php foreach ($filtered_popups as $popup_id => $popup): ?>
            <div class="novawanimpop1-popup-item" data-popup-id="<?php echo esc_attr($popup_id); ?>">
                <?php if ($show_title && !empty($popup['heading'])): ?>
                    <h3 class="novawanimpop1-popup-item-title"><?php echo esc_html($popup['heading']); ?></h3>
                <?php endif; ?>

                <?php if ($show_description && !empty($popup['description'])): ?>
                    <div class="novawanimpop1-popup-item-description">
                        <?php echo wp_kses_post($popup['description']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($show_button): ?>
                    <button class="novawanimpop1-popup-trigger novawanimpop1-list-trigger"
                            data-popup-id="<?php echo esc_attr($popup_id); ?>">
                        <?php echo !empty($popup['button_text']) ? esc_html($popup['button_text']) : __('View Popup', 'novawanimpop1'); ?>
                    </button>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <style>
    .novawanimpop1-popup-list {
        display: grid;
        gap: 20px;
        margin: 20px 0;
    }

    .novawanimpop1-popup-item {
        padding: 20px;
        border: 1px solid #e1e5e9;
        border-radius: 8px;
        background: #fff;
        transition: all 0.3s ease;
    }

    .novawanimpop1-popup-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
    }

    .novawanimpop1-popup-item-title {
        margin: 0 0 10px 0;
        font-size: 18px;
        font-weight: 600;
        color: #333;
    }

    .novawanimpop1-popup-item-description {
        margin: 0 0 15px 0;
        color: #666;
        line-height: 1.5;
    }

    .novawanimpop1-list-trigger {
        background: #667eea;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .novawanimpop1-list-trigger:hover {
        background: #5a67d8;
        transform: translateY(-1px);
    }
    </style>

    <script>
    jQuery(document).ready(function($) {
        $('.novawanimpop1-list-trigger').on('click', function(e) {
            e.preventDefault();
            var popupId = $(this).data('popup-id');

            if (typeof window.NOVAWANIMPOP1_Frontend !== 'undefined') {
                window.NOVAWANIMPOP1_Frontend.showPopup(popupId);
            }
        });
    });
    </script>
    <?php

    foreach ($filtered_popups as $popup_id => $popup) {
        novawanimpop1_render_single_popup($popup_id, $popup);
    }

    return ob_get_clean();
}

add_shortcode('novawanimpop1_popup_list', 'novawanimpop1_popup_list_shortcode');

function novawanimpop1_register_gutenberg_blocks() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'novawanimpop1-gutenberg-block',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/js/novawanimpop1-gutenberg.js',
        array('wp-blocks', 'wp-element', 'wp-editor'),
        NOVAWANIMPOP1_VERSION
    );

    wp_localize_script('novawanimpop1-gutenberg-block', 'novawanimpop1_gutenberg', array(
        'popups' => novawanimpop1_get_popup_options_for_gutenberg()
    ));

    register_block_type('novawanimpop1/popup-trigger', array(
        'editor_script' => 'novawanimpop1-gutenberg-block',
        'render_callback' => 'novawanimpop1_render_gutenberg_popup_block'
    ));
}

function novawanimpop1_get_popup_options_for_gutenberg() {
    $popups = get_option('novawanimpop1_popups', array());
    $options = array();

    foreach ($popups as $popup_id => $popup) {
        if (isset($popup['enabled']) && $popup['enabled']) {
            $options[] = array(
                'value' => $popup_id,
                'label' => isset($popup['title']) ? $popup['title'] : $popup_id
            );
        }
    }

    return $options;
}

function novawanimpop1_render_gutenberg_popup_block($attributes) {
    $popup_id = isset($attributes['popupId']) ? $attributes['popupId'] : '';
    $button_text = isset($attributes['buttonText']) ? $attributes['buttonText'] : '';
    $delay = isset($attributes['delay']) ? intval($attributes['delay']) : 0;

    if (empty($popup_id)) {
        return '';
    }

    $shortcode = '[novawanimpop1_popup id="' . esc_attr($popup_id) . '" trigger="manual" delay="' . esc_attr($delay) . '"]';

    if (!empty($button_text)) {
        $shortcode = '[novawanimpop1_trigger popup_id="' . esc_attr($popup_id) . '" delay="' . esc_attr($delay) . '"]' . esc_html($button_text) . '[/novawanimpop1_trigger]';
    }

    return do_shortcode($shortcode);
}

add_action('init', 'novawanimpop1_register_gutenberg_blocks');