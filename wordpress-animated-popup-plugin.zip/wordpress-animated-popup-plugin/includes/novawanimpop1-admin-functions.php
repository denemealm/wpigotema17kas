<?php
if (!defined('ABSPATH')) {
    exit;
}

function novawanimpop1_admin_menu() {
    add_menu_page(
        __('WordPress Animated Popup Plugin', 'novawanimpop1'),
        __('Animated Popup Plugin', 'novawanimpop1'),
        'manage_options',
        'animated-popup-plugin',
        'novawanimpop1_render_admin_page',
        'dashicons-megaphone',
        30
    );

    add_submenu_page(
        'animated-popup-plugin',
        __('All Popups', 'novawanimpop1'),
        __('All Popups', 'novawanimpop1'),
        'manage_options',
        'animated-popup-plugin',
        'novawanimpop1_render_admin_page'
    );

    add_submenu_page(
        'animated-popup-plugin',
        __('Add New Popup', 'novawanimpop1'),
        __('Add New', 'novawanimpop1'),
        'manage_options',
        'animated-popup-add-new',
        'novawanimpop1_render_add_new_page'
    );

    add_submenu_page(
        'animated-popup-plugin',
        __('Settings', 'novawanimpop1'),
        __('Settings', 'novawanimpop1'),
        'manage_options',
        'animated-popup-settings',
        'novawanimpop1_render_settings_page'
    );
}

function novawanimpop1_admin_assets($hook) {
    if (strpos($hook, 'animated-popup-') === false) {
        return;
    }

    $version = time();

    wp_enqueue_media();
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');

    wp_enqueue_style(
        'novawanimpop1-admin',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/css/novawanimpop1-admin.css',
        array('dashicons'),
        $version
    );

    wp_enqueue_style(
        'novawanimpop1-frontend-preview',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/css/novawanimpop1-frontend.css',
        array(),
        $version
    );

    wp_enqueue_script(
        'novawanimpop1-admin',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/js/novawanimpop1-admin.js',
        array('jquery', 'wp-color-picker'),
        $version,
        true
    );

    wp_localize_script('novawanimpop1-admin', 'novawanimpop1_admin', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('novawanimpop1_admin_nonce'),
        'list_url' => esc_url(admin_url('admin.php?page=animated-popup-plugin')),
        'edit_url' => admin_url('admin.php?page=animated-popup-add-new'),
        'strings' => array(
            'confirm_delete' => __('Are you sure you want to delete this popup?', 'novawanimpop1'),
            'save_success' => __('Popup saved successfully!', 'novawanimpop1'),
            'save_error' => __('Error saving popup. Please try again.', 'novawanimpop1'),
            'delete_success' => __('Popup deleted successfully!', 'novawanimpop1'),
            'delete_error' => __('Error deleting popup. Please try again.', 'novawanimpop1'),
            'copied' => __('Shortcode copied to clipboard!', 'novawanimpop1')
        )
    ));
}

function novawanimpop1_render_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'novawanimpop1'));
    }

    $popups = get_option('novawanimpop1_popups', array());
    ?>
    <div class="novawanimpop1-admin-wrap">
        <div class="novawanimpop1-page-header">
            <div class="novawanimpop1-header-content">
                <div class="novawanimpop1-header-left">
                    <div class="novawanimpop1-logo">
                        <div class="novawanimpop1-logo-icon">
                            <span class="dashicons dashicons-megaphone"></span>
                        </div>
                        <div class="novawanimpop1-logo-text">WPIGO</div>
                    </div>
                    <div class="novawanimpop1-header-text">
                        <h1 class="novawanimpop1-page-title"><?php _e('WordPress Animated Popup Plugin', 'novawanimpop1'); ?></h1>
                        <p class="novawanimpop1-page-subtitle"><?php _e('Manage your popups and boost conversions', 'novawanimpop1'); ?></p>
                    </div>
                </div>
                <div class="novawanimpop1-header-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=animated-popup-add-new')); ?>" class="novawanimpop1-header-button primary">
                        <span class="dashicons dashicons-plus-alt2"></span>
                        <?php _e('Add New Popup', 'novawanimpop1'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="novawanimpop1-dashboard">
            <div class="novawanimpop1-stats">
                <div class="novawanimpop1-stat-card novawanimpop1-stat-primary">
                    <div class="novawanimpop1-stat-icon">
                        <span class="dashicons dashicons-visibility"></span>
                    </div>
                    <div class="novawanimpop1-stat-content">
                        <h3><?php echo esc_html(count($popups)); ?></h3>
                        <p><?php _e('Total Popups', 'novawanimpop1'); ?></p>
                    </div>
                </div>
                <div class="novawanimpop1-stat-card novawanimpop1-stat-success">
                    <div class="novawanimpop1-stat-icon">
                        <span class="dashicons dashicons-yes-alt"></span>
                    </div>
                    <div class="novawanimpop1-stat-content">
                        <h3><?php echo esc_html(count(array_filter($popups, function($p) { return isset($p['enabled']) && $p['enabled']; }))); ?></h3>
                        <p><?php _e('Active Popups', 'novawanimpop1'); ?></p>
                    </div>
                </div>
            </div>

            <div class="novawanimpop1-popups-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Title', 'novawanimpop1'); ?></th>
                            <th><?php _e('Template', 'novawanimpop1'); ?></th>
                            <th><?php _e('Display On', 'novawanimpop1'); ?></th>
                            <th><?php _e('Shortcode', 'novawanimpop1'); ?></th>
                            <th><?php _e('Status', 'novawanimpop1'); ?></th>
                            <th><?php _e('Actions', 'novawanimpop1'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($popups)) : ?>
                            <tr>
                                <td colspan="6" class="novawanimpop1-no-popups">
                                    <p><?php _e('No popups created yet.', 'novawanimpop1'); ?></p>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=animated-popup-add-new')); ?>" class="button button-primary">
                                        <?php _e('Create Your First Popup', 'novawanimpop1'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($popups as $popup_id => $popup) : ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($popup['title']); ?></strong>
                                    </td>
                                    <td>
                                        <span class="novawanimpop1-template-badge novawanimpop1-<?php echo esc_attr($popup['template']); ?>">
                                            <?php echo esc_html(novawanimpop1_get_template_name($popup['template'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html(novawanimpop1_get_display_location($popup['display_on'])); ?></td>
                                    <td>
                                        <code>[novawanimpop1_popup id="<?php echo esc_attr($popup_id); ?>"]</code>
                                        <button class="button-link novawanimpop1-copy-shortcode" data-shortcode='[novawanimpop1_popup id="<?php echo esc_attr($popup_id); ?>"]'>
                                            <span class="dashicons dashicons-clipboard"></span>
                                        </button>
                                    </td>
                                    <td>
                                        <?php if (isset($popup['enabled']) && $popup['enabled']) : ?>
                                            <span class="novawanimpop1-status-badge novawanimpop1-active"><?php _e('Active', 'novawanimpop1'); ?></span>
                                        <?php else : ?>
                                            <span class="novawanimpop1-status-badge novawanimpop1-inactive"><?php _e('Inactive', 'novawanimpop1'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="button novawanimpop1-edit-popup" data-popup-id="<?php echo esc_attr($popup_id); ?>">
                                            <span class="dashicons dashicons-edit"></span> <?php _e('Edit', 'novawanimpop1'); ?>
                                        </button>
                                        <button class="button novawanimpop1-delete-popup" data-popup-id="<?php echo esc_attr($popup_id); ?>">
                                            <span class="dashicons dashicons-trash"></span> <?php _e('Delete', 'novawanimpop1'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

function novawanimpop1_render_add_new_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'novawanimpop1'));
    }
    ?>
    <div class="novawanimpop1-admin-wrap">
        <div class="novawanimpop1-page-header">
            <div class="novawanimpop1-header-content">
                <div class="novawanimpop1-header-left">
                    <div class="novawanimpop1-logo">
                        <div class="novawanimpop1-logo-icon">
                            <span class="dashicons dashicons-plus-alt2"></span>
                        </div>
                        <div class="novawanimpop1-logo-text">WPIGO</div>
                    </div>
                    <div class="novawanimpop1-header-text">
                        <h1 class="novawanimpop1-page-title"><?php _e('Add New Popup', 'novawanimpop1'); ?></h1>
                        <p class="novawanimpop1-page-subtitle"><?php _e('Create beautiful popups to engage your visitors', 'novawanimpop1'); ?></p>
                    </div>
                </div>
                <div class="novawanimpop1-header-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=animated-popup-plugin')); ?>" class="novawanimpop1-header-button">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                        <?php _e('Back to Popups', 'novawanimpop1'); ?>
                    </a>
                </div>
            </div>
        </div>

        <div class="novawanimpop1-popup-editor">
            <form id="novawanimpop1-popup-form" class="novawanimpop1-form">
                <input type="hidden" id="novawanimpop1-popup-id" name="popup_id" value="">

                <div class="novawanimpop1-form-row novawanimpop1-two-cols">
                    <div class="novawanimpop1-form-col">
                        <h2><?php _e('General Settings', 'novawanimpop1'); ?></h2>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-title"><?php _e('Popup Title', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-title" name="title" required>
                            <p class="description"><?php _e('Internal title to identify this popup', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-template"><?php _e('Template', 'novawanimpop1'); ?></label>
                            <select id="novawanimpop1-popup-template" name="template">
                                <?php echo novawanimpop1_get_template_options(); ?>
                            </select>
                            <p class="description"><?php _e('Choose from 22 stunning animated templates', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label>
                                <input type="checkbox" name="enabled" value="1" checked>
                                <?php _e('Enable this popup', 'novawanimpop1'); ?>
                            </label>
                        </div>

                        <h3><?php _e('Trigger Settings', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-trigger"><?php _e('Trigger Type', 'novawanimpop1'); ?></label>
                            <select id="novawanimpop1-popup-trigger" name="trigger">
                                <option value="time"><?php _e('Time Delay', 'novawanimpop1'); ?></option>
                                <option value="scroll"><?php _e('On Scroll', 'novawanimpop1'); ?></option>
                                <option value="exit"><?php _e('Exit Intent', 'novawanimpop1'); ?></option>
                                <option value="click"><?php _e('On Click', 'novawanimpop1'); ?></option>
                            </select>
                        </div>

                        <div class="novawanimpop1-field-group" id="novawanimpop1-delay-field">
                            <label for="novawanimpop1-popup-delay"><?php _e('Delay (milliseconds)', 'novawanimpop1'); ?></label>
                            <input type="number" id="novawanimpop1-popup-delay" name="delay" value="3000" min="0">
                            <p class="description"><?php _e('1000ms = 1 second', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group" id="novawanimpop1-click-selector-field" style="display:none;">
                            <label for="novawanimpop1-popup-click-selector"><?php _e('Click Element Selector', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-click-selector" name="click_selector" placeholder=".my-button, #special-link">
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-display"><?php _e('Display On', 'novawanimpop1'); ?></label>
                            <select id="novawanimpop1-popup-display" name="display_on">
                                <option value="all"><?php _e('All Pages', 'novawanimpop1'); ?></option>
                                <option value="homepage"><?php _e('Homepage Only', 'novawanimpop1'); ?></option>
                                <option value="shop"><?php _e('Shop Pages', 'novawanimpop1'); ?></option>
                                <option value="product"><?php _e('Product Pages', 'novawanimpop1'); ?></option>
                                <option value="cart"><?php _e('Cart Page', 'novawanimpop1'); ?></option>
                                <option value="checkout"><?php _e('Checkout Page', 'novawanimpop1'); ?></option>
                                <option value="specific"><?php _e('Specific Pages', 'novawanimpop1'); ?></option>
                            </select>
                        </div>

                        <h3><?php _e('Frequency Settings', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-frequency"><?php _e('Show Frequency', 'novawanimpop1'); ?></label>
                            <select id="novawanimpop1-popup-frequency" name="frequency">
                                <option value="always"><?php _e('Every Page Load', 'novawanimpop1'); ?></option>
                                <option value="once"><?php _e('Once Per Session', 'novawanimpop1'); ?></option>
                                <option value="daily"><?php _e('Once Per Day', 'novawanimpop1'); ?></option>
                                <option value="custom"><?php _e('Custom Interval', 'novawanimpop1'); ?></option>
                            </select>
                            <p class="description"><?php _e('Control how often the popup appears to the same visitor', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group" id="novawanimpop1-frequency-hours-field" style="display:none;">
                            <label for="novawanimpop1-popup-frequency-hours"><?php _e('Custom Interval (hours)', 'novawanimpop1'); ?></label>
                            <input type="number" id="novawanimpop1-popup-frequency-hours" name="frequency_hours" value="24" min="1" max="720">
                            <p class="description"><?php _e('Number of hours to wait before showing popup again', 'novawanimpop1'); ?></p>
                        </div>

                        <h3><?php _e('Content Settings', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-heading"><?php _e('Heading Text', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-heading" name="heading">
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-description"><?php _e('Description', 'novawanimpop1'); ?></label>
                            <textarea id="novawanimpop1-popup-description" name="description" rows="4"></textarea>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-button-text"><?php _e('Button Text', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-button-text" name="button_text">
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-button-link"><?php _e('Button Link', 'novawanimpop1'); ?></label>
                            <input type="url" id="novawanimpop1-popup-button-link" name="button_link">
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label>
                                <input type="checkbox" name="button_target" value="1">
                                <?php _e('Open link in new tab', 'novawanimpop1'); ?>
                            </label>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label>
                                <input type="checkbox" id="novawanimpop1-popup-countdown" name="countdown" value="1">
                                <?php _e('Show Countdown Timer', 'novawanimpop1'); ?>
                            </label>
                        </div>

                        <div class="novawanimpop1-field-group" id="novawanimpop1-countdown-end-field" style="display:none;">
                            <label for="novawanimpop1-popup-countdown-end"><?php _e('Countdown End Date/Time', 'novawanimpop1'); ?></label>
                            <input type="datetime-local" id="novawanimpop1-popup-countdown-end" name="countdown_end">
                        </div>
                    </div>

                    <div class="novawanimpop1-form-col">
                        <h2><?php _e('Visual & Style Settings', 'novawanimpop1'); ?></h2>

                        <h3><?php _e('Popup Size', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-width"><?php _e('Width', 'novawanimpop1'); ?></label>
                            <div class="novawanimpop1-size-input">
                                <input type="number" id="novawanimpop1-popup-width" name="popup_width" min="0" placeholder="500">
                                <select name="popup_width_unit">
                                    <option value="px">px</option>
                                    <option value="%">%</option>
                                </select>
                            </div>
                            <p class="description"><?php _e('Leave blank to use default. Set a width for the popup.', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-height"><?php _e('Height', 'novawanimpop1'); ?></label>
                            <div class="novawanimpop1-size-input">
                                <input type="number" id="novawanimpop1-popup-height" name="popup_height" min="0" placeholder="">
                                <select name="popup_height_unit">
                                    <option value="px">px</option>
                                    <option value="%">%</option>
                                </select>
                            </div>
                            <p class="description"><?php _e('Leave blank for auto height.', 'novawanimpop1'); ?></p>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label><?php _e('Visual Element', 'novawanimpop1'); ?></label>
                            <div class="novawanimpop1-visual-tabs">
                                <button type="button" class="novawanimpop1-tab-button novawanimpop1-active" data-tab="image">
                                    <span class="dashicons dashicons-format-image"></span>
                                    <?php _e('Image', 'novawanimpop1'); ?>
                                </button>
                                <button type="button" class="novawanimpop1-tab-button" data-tab="icon">
                                    <span class="dashicons dashicons-star-filled"></span>
                                    <?php _e('Icon', 'novawanimpop1'); ?>
                                </button>
                            </div>

                            <div class="novawanimpop1-tab-content" id="novawanimpop1-image-tab" style="display:block;">
                                <div class="novawanimpop1-image-upload">
                                    <input type="hidden" id="novawanimpop1-popup-image" name="image">
                                    <div id="novawanimpop1-image-preview"></div>
                                    <button type="button" class="button" id="novawanimpop1-upload-image">
                                        <span class="dashicons dashicons-upload"></span>
                                        <?php _e('Upload Image', 'novawanimpop1'); ?>
                                    </button>
                                    <button type="button" class="button" id="novawanimpop1-remove-image" style="display:none;">
                                        <span class="dashicons dashicons-trash"></span>
                                        <?php _e('Remove', 'novawanimpop1'); ?>
                                    </button>
                                </div>
                            </div>

                            <div class="novawanimpop1-tab-content" id="novawanimpop1-icon-tab" style="display:none;">
                                <div class="novawanimpop1-icon-selector">
                                    <input type="hidden" id="novawanimpop1-popup-icon" name="icon_name" value="">

                                    <div class="novawanimpop1-icon-preview">
                                        <span id="novawanimpop1-selected-icon" class="dashicons dashicons-star-filled"></span>
                                    </div>

                                    <button type="button" class="button" id="novawanimpop1-choose-icon">
                                        <span class="dashicons dashicons-admin-customizer"></span>
                                        <?php _e('Choose Icon', 'novawanimpop1'); ?>
                                    </button>

                                    <div class="novawanimpop1-icon-grid" style="display:none;">
                                        <?php
                                        $icons = array(
                                            'star-filled', 'star-empty', 'heart', 'cart', 'tag', 'tickets-alt',
                                            'megaphone', 'awards', 'gift', 'store', 'products', 'yes-alt',
                                            'info', 'warning', 'dismiss', 'bell', 'clock', 'calendar-alt',
                                            'location', 'location-alt', 'phone', 'email', 'share', 'money-alt'
                                        );
                                        foreach ($icons as $icon) {
                                            echo '<span class="novawanimpop1-icon-option dashicons dashicons-' . esc_attr($icon) . '" data-icon="' . esc_attr($icon) . '"></span>';
                                        }
                                        ?>
                                    </div>

                                    <div class="novawanimpop1-icon-controls">
                                        <div class="novawanimpop1-field-group">
                                            <label for="novawanimpop1-icon-size"><?php _e('Icon Size', 'novawanimpop1'); ?></label>
                                            <input type="range" id="novawanimpop1-icon-size" name="icon_size" min="30" max="120" value="60" step="5">
                                            <span class="novawanimpop1-range-value">60px</span>
                                        </div>

                                        <div class="novawanimpop1-field-group">
                                            <label for="novawanimpop1-icon-color"><?php _e('Icon Color', 'novawanimpop1'); ?></label>
                                            <input type="text" id="novawanimpop1-icon-color" name="icon_color" class="novawanimpop1-color-picker" value="#ffffff">
                                        </div>

                                        <div class="novawanimpop1-field-group">
                                            <label for="novawanimpop1-icon-bg"><?php _e('Icon Background', 'novawanimpop1'); ?></label>
                                            <input type="text" id="novawanimpop1-icon-bg" name="icon_bg" class="novawanimpop1-color-picker" value="transparent">
                                        </div>

                                        <div class="novawanimpop1-field-group">
                                            <label for="novawanimpop1-icon-position"><?php _e('Icon Position', 'novawanimpop1'); ?></label>
                                            <select id="novawanimpop1-icon-position" name="icon_position">
                                                <option value="top"><?php _e('Top', 'novawanimpop1'); ?></option>
                                                <option value="bottom"><?php _e('Bottom', 'novawanimpop1'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" id="novawanimpop1-visual-type" name="visual_type" value="image">

                        <h3><?php _e('Heading Style', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-heading-size"><?php _e('Font Size', 'novawanimpop1'); ?></label>
                            <input type="range" id="novawanimpop1-popup-heading-size" name="heading_size" min="16" max="48" value="32" step="2">
                            <span class="novawanimpop1-range-value">32px</span>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-heading-color"><?php _e('Text Color', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-heading-color" name="heading_color" class="novawanimpop1-color-picker" value="#ffffff">
                        </div>

                        <h3><?php _e('Description Style', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-description-size"><?php _e('Font Size', 'novawanimpop1'); ?></label>
                            <input type="range" id="novawanimpop1-popup-description-size" name="description_size" min="12" max="24" value="16" step="1">
                            <span class="novawanimpop1-range-value">16px</span>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-description-color"><?php _e('Text Color', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-description-color" name="description_color" class="novawanimpop1-color-picker" value="#ffffff">
                        </div>

                        <h3><?php _e('Button Style', 'novawanimpop1'); ?></h3>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-button-size"><?php _e('Font Size', 'novawanimpop1'); ?></label>
                            <input type="range" id="novawanimpop1-popup-button-size" name="button_size" min="14" max="24" value="18" step="1">
                            <span class="novawanimpop1-range-value">18px</span>
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-button-color"><?php _e('Text Color', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-button-color" name="button_color" class="novawanimpop1-color-picker" value="#764ba2">
                        </div>

                        <div class="novawanimpop1-field-group">
                            <label for="novawanimpop1-popup-button-bg"><?php _e('Background Color', 'novawanimpop1'); ?></label>
                            <input type="text" id="novawanimpop1-popup-button-bg" name="button_bg" class="novawanimpop1-color-picker" value="#ffffff">
                        </div>
                    </div>
                </div>

                <div class="novawanimpop1-form-actions">
                    <button type="submit" class="button button-primary button-large">
                        <span class="dashicons dashicons-saved"></span>
                        <?php _e('Save Popup', 'novawanimpop1'); ?>
                    </button>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=animated-popup-plugin')); ?>" class="button button-large">
                        <?php _e('Cancel', 'novawanimpop1'); ?>
                    </a>
                </div>
            </form>

            <div class="novawanimpop1-preview-section">
                <h2><?php _e('Live Preview', 'novawanimpop1'); ?></h2>
                <div id="novawanimpop1-popup-preview" class="novawanimpop1-popup-preview">
                    <div class="novawanimpop1-preview-placeholder">
                        <?php _e('Popup preview will appear here', 'novawanimpop1'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function novawanimpop1_render_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'novawanimpop1'));
    }

    $settings = get_option('novawanimpop1_settings', array());
    ?>
    <div class="novawanimpop1-admin-wrap">
        <div class="novawanimpop1-page-header">
            <div class="novawanimpop1-header-content">
                <div class="novawanimpop1-header-left">
                    <div class="novawanimpop1-logo">
                        <div class="novawanimpop1-logo-icon">
                            <span class="dashicons dashicons-admin-settings"></span>
                        </div>
                        <div class="novawanimpop1-logo-text">WPIGO</div>
                    </div>
                    <div class="novawanimpop1-header-text">
                        <h1 class="novawanimpop1-page-title"><?php _e('Plugin Settings', 'novawanimpop1'); ?></h1>
                        <p class="novawanimpop1-page-subtitle"><?php _e('Configure global popup settings and behavior', 'novawanimpop1'); ?></p>
                    </div>
                </div>
                <div class="novawanimpop1-header-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=animated-popup-plugin')); ?>" class="novawanimpop1-header-button">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                        <?php _e('Back to Popups', 'novawanimpop1'); ?>
                    </a>
                </div>
            </div>
        </div>

        <form method="post" action="options.php" class="novawanimpop1-settings-form">
            <?php settings_fields('novawanimpop1_settings_group'); ?>

            <div class="novawanimpop1-settings-section">
                <h2><?php _e('General Settings', 'novawanimpop1'); ?></h2>

                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Enable Popups', 'novawanimpop1'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="novawanimpop1_settings[enable_popups]" value="1"
                                       <?php checked(isset($settings['enable_popups']) ? $settings['enable_popups'] : true, true); ?>>
                                <?php _e('Enable popup functionality globally', 'novawanimpop1'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Default Delay', 'novawanimpop1'); ?></th>
                        <td>
                            <input type="number" name="novawanimpop1_settings[default_delay]"
                                   value="<?php echo isset($settings['default_delay']) ? esc_attr($settings['default_delay']) : 3000; ?>"
                                   min="0" step="100">
                            <p class="description"><?php _e('Default delay in milliseconds', 'novawanimpop1'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Animation Speed', 'novawanimpop1'); ?></th>
                        <td>
                            <input type="number" name="novawanimpop1_settings[animation_speed]"
                                   value="<?php echo isset($settings['animation_speed']) ? esc_attr($settings['animation_speed']) : 400; ?>"
                                   min="0" step="50">
                            <p class="description"><?php _e('Animation duration in milliseconds', 'novawanimpop1'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Close Options', 'novawanimpop1'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="novawanimpop1_settings[close_on_overlay]" value="1"
                                       <?php checked(isset($settings['close_on_overlay']) ? $settings['close_on_overlay'] : true, true); ?>>
                                <?php _e('Close popup when clicking overlay', 'novawanimpop1'); ?>
                            </label>
                            <br>
                            <label>
                                <input type="checkbox" name="novawanimpop1_settings[close_on_esc]" value="1"
                                       <?php checked(isset($settings['close_on_esc']) ? $settings['close_on_esc'] : true, true); ?>>
                                <?php _e('Close popup with ESC key', 'novawanimpop1'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Mobile Settings', 'novawanimpop1'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="novawanimpop1_settings[mobile_enabled]" value="1"
                                       <?php checked(isset($settings['mobile_enabled']) ? $settings['mobile_enabled'] : true, true); ?>>
                                <?php _e('Enable popups on mobile devices', 'novawanimpop1'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
            </div>

            <?php submit_button(__('Save Settings', 'novawanimpop1')); ?>
        </form>
    </div>
    <?php
}

function novawanimpop1_get_template_name($template_id) {
    $templates = array(
        'template1' => __('Gradient Splash', 'novawanimpop1'),
        'template2' => __('Modern Card', 'novawanimpop1'),
        'template3' => __('Elegant Banner', 'novawanimpop1'),
        'template4' => __('Minimal Box', 'novawanimpop1'),
        'template5' => __('Bold Statement', 'novawanimpop1'),
        'template6' => __('Neon Glow', 'novawanimpop1'),
        'template7' => __('Pastel Dream', 'novawanimpop1'),
        'template8' => __('Dark Mode', 'novawanimpop1'),
        'template9' => __('Rainbow Edge', 'novawanimpop1'),
        'template10' => __('Glass Effect', 'novawanimpop1')
    );
    return isset($templates[$template_id]) ? $templates[$template_id] : $template_id;
}

function novawanimpop1_get_template_options() {
    $templates = array(
        'template1' => __('Gradient Splash - Purple to Pink', 'novawanimpop1'),
        'template2' => __('Modern Card - Blue Gradient', 'novawanimpop1'),
        'template3' => __('Elegant Banner - Gold Accent', 'novawanimpop1'),
        'template4' => __('Minimal Box - Clean White', 'novawanimpop1'),
        'template5' => __('Bold Statement - Red Energy', 'novawanimpop1'),
        'template6' => __('Neon Glow - Cyan Electric', 'novawanimpop1'),
        'template7' => __('Pastel Dream - Soft Colors', 'novawanimpop1'),
        'template8' => __('Dark Mode - Midnight Blue', 'novawanimpop1'),
        'template9' => __('Rainbow Edge - Vibrant Mix', 'novawanimpop1'),
        'template10' => __('Glass Effect - Frosted Style', 'novawanimpop1'),
        'template11' => __('Rainbow Storm - Animated Colors', 'novawanimpop1'),
        'template12' => __('Neon Cyber - Glowing Borders', 'novawanimpop1'),
        'template13' => __('Deep Shadow - Floating Effect', 'novawanimpop1'),
        'template14' => __('3D Depth - Perspective View', 'novawanimpop1'),
        'template15' => __('Diagonal Stripes - Pattern Style', 'novawanimpop1'),
        'template16' => __('Wave Pattern - Flowing Lights', 'novawanimpop1'),
        'template17' => __('Matrix Effect - Digital Rain', 'novawanimpop1'),
        'template18' => __('Pulse Wave - Breathing Animation', 'novawanimpop1'),
        'template19' => __('Rotating Border - Spinning Lights', 'novawanimpop1'),
        'template20' => __('Bounce In - Elastic Entry', 'novawanimpop1'),
        'template21' => __('Glowing Neon - Electric Pulse', 'novawanimpop1'),
        'template22' => __('Shake Effect - Attention Grabber', 'novawanimpop1')
    );
    $options = '';
    foreach ($templates as $id => $name) {
        $options .= sprintf('<option value="%s">%s</option>', esc_attr($id), esc_html($name));
    }
    return $options;
}

function novawanimpop1_get_display_location($location) {
    $locations = array(
        'all' => __('All Pages', 'novawanimpop1'),
        'homepage' => __('Homepage', 'novawanimpop1'),
        'shop' => __('Shop Pages', 'novawanimpop1'),
        'product' => __('Product Pages', 'novawanimpop1'),
        'cart' => __('Cart Page', 'novawanimpop1'),
        'checkout' => __('Checkout Page', 'novawanimpop1'),
        'specific' => __('Specific Pages', 'novawanimpop1')
    );
    return isset($locations[$location]) ? $locations[$location] : $location;
}