<?php
if (!defined('ABSPATH')) {
    exit;
}

function novawanimpop1_ajax_save_popup() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popup_data = array();

    $popup_data['title'] = sanitize_text_field($_POST['title']);
    $popup_data['template'] = sanitize_text_field($_POST['template']);
    $popup_data['trigger'] = sanitize_text_field($_POST['trigger']);
    $popup_data['delay'] = absint($_POST['delay']);
    $popup_data['display_on'] = sanitize_text_field($_POST['display_on']);
    $popup_data['enabled'] = isset($_POST['enabled']) ? (bool)$_POST['enabled'] : false;
    $popup_data['heading'] = sanitize_text_field($_POST['heading']);
    $popup_data['description'] = wp_kses_post($_POST['description']);
    $popup_data['image'] = esc_url_raw($_POST['image']);
    $popup_data['countdown'] = isset($_POST['countdown']) ? (bool)$_POST['countdown'] : false;
    $popup_data['countdown_end'] = sanitize_text_field($_POST['countdown_end']);
    $popup_data['button_text'] = sanitize_text_field($_POST['button_text']);
    $popup_data['button_link'] = esc_url_raw($_POST['button_link']);
    $popup_data['button_target'] = isset($_POST['button_target']) ? (bool)$_POST['button_target'] : false;
    $popup_data['click_selector'] = isset($_POST['click_selector']) ? sanitize_text_field($_POST['click_selector']) : '';

    $popup_data['popup_width'] = isset($_POST['popup_width']) ? sanitize_text_field($_POST['popup_width']) : '';
    $popup_data['popup_width_unit'] = isset($_POST['popup_width_unit']) ? sanitize_text_field($_POST['popup_width_unit']) : 'px';
    $popup_data['popup_height'] = isset($_POST['popup_height']) ? sanitize_text_field($_POST['popup_height']) : '';
    $popup_data['popup_height_unit'] = isset($_POST['popup_height_unit']) ? sanitize_text_field($_POST['popup_height_unit']) : 'px';

    $popup_data['heading_size'] = isset($_POST['heading_size']) ? absint($_POST['heading_size']) : 32;
    $popup_data['heading_color'] = isset($_POST['heading_color']) ? sanitize_hex_color($_POST['heading_color']) : '#ffffff';
    $popup_data['description_size'] = isset($_POST['description_size']) ? absint($_POST['description_size']) : 16;
    $popup_data['description_color'] = isset($_POST['description_color']) ? sanitize_hex_color($_POST['description_color']) : '#ffffff';
    $popup_data['button_size'] = isset($_POST['button_size']) ? absint($_POST['button_size']) : 18;
    $popup_data['button_color'] = isset($_POST['button_color']) ? sanitize_hex_color($_POST['button_color']) : '#764ba2';
    $popup_data['button_bg'] = isset($_POST['button_bg']) ? sanitize_hex_color($_POST['button_bg']) : '#ffffff';

    $popup_data['visual_type'] = isset($_POST['visual_type']) ? sanitize_text_field($_POST['visual_type']) : 'image';
    $popup_data['icon'] = isset($_POST['icon_name']) ? sanitize_text_field($_POST['icon_name']) : '';
    $popup_data['icon_size'] = isset($_POST['icon_size']) ? absint($_POST['icon_size']) : 60;
    $popup_data['icon_color'] = isset($_POST['icon_color']) ? sanitize_hex_color($_POST['icon_color']) : '#ffffff';
    $popup_data['icon_bg'] = isset($_POST['icon_bg']) ? sanitize_text_field($_POST['icon_bg']) : 'transparent';
    $popup_data['icon_position'] = isset($_POST['icon_position']) ? sanitize_text_field($_POST['icon_position']) : 'top';

    $popup_data['frequency'] = isset($_POST['frequency']) ? sanitize_text_field($_POST['frequency']) : 'always';
    $popup_data['frequency_hours'] = isset($_POST['frequency_hours']) ? absint($_POST['frequency_hours']) : 24;

    $popups = get_option('novawanimpop1_popups', array());

    if (!empty($_POST['popup_id'])) {
        $popup_id = sanitize_text_field($_POST['popup_id']);
    } else {
        $popup_id = 'popup_' . time() . '_' . wp_rand(1000, 9999);
    }

    $popups[$popup_id] = $popup_data;
    update_option('novawanimpop1_popups', $popups);

    wp_send_json_success(array(
        'message' => __('Popup saved successfully!', 'novawanimpop1'),
        'popup_id' => $popup_id
    ));
}

function novawanimpop1_ajax_delete_popup() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popup_id = sanitize_text_field($_POST['popup_id']);
    $popups = get_option('novawanimpop1_popups', array());

    if (isset($popups[$popup_id])) {
        unset($popups[$popup_id]);
        update_option('novawanimpop1_popups', $popups);

        wp_send_json_success(array(
            'message' => __('Popup deleted successfully!', 'novawanimpop1')
        ));
    } else {
        wp_send_json_error(array(
            'message' => __('Popup not found.', 'novawanimpop1')
        ));
    }
}

function novawanimpop1_ajax_get_popup() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popup_id = sanitize_text_field($_POST['popup_id']);
    $popups = get_option('novawanimpop1_popups', array());

    if (isset($popups[$popup_id])) {
        wp_send_json_success($popups[$popup_id]);
    } else {
        wp_send_json_error(array(
            'message' => __('Popup not found.', 'novawanimpop1')
        ));
    }
}

function novawanimpop1_ajax_toggle_status() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popup_id = sanitize_text_field($_POST['popup_id']);
    $popups = get_option('novawanimpop1_popups', array());

    if (isset($popups[$popup_id])) {
        $popups[$popup_id]['enabled'] = !$popups[$popup_id]['enabled'];
        update_option('novawanimpop1_popups', $popups);

        $status = $popups[$popup_id]['enabled'] ? __('Active', 'novawanimpop1') : __('Inactive', 'novawanimpop1');

        wp_send_json_success(array(
            'message' => sprintf(__('Popup status changed to %s', 'novawanimpop1'), $status),
            'status' => $popups[$popup_id]['enabled']
        ));
    } else {
        wp_send_json_error(array(
            'message' => __('Popup not found.', 'novawanimpop1')
        ));
    }
}

add_action('wp_ajax_novawanimpop1_track_view', 'novawanimpop1_ajax_track_view');
add_action('wp_ajax_nopriv_novawanimpop1_track_view', 'novawanimpop1_ajax_track_view');

function novawanimpop1_ajax_track_view() {
    check_ajax_referer('novawanimpop1_frontend_nonce', 'nonce');

    $popup_id = sanitize_text_field($_POST['popup_id']);

    if (empty($popup_id)) {
        wp_send_json_error(array('message' => 'Invalid popup ID'));
    }

    $views = get_option('novawanimpop1_popup_views', array());

    if (!isset($views[$popup_id])) {
        $views[$popup_id] = 0;
    }

    $views[$popup_id]++;
    update_option('novawanimpop1_popup_views', $views);

    $session_key = 'novawanimpop1_viewed_' . $popup_id;
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION[$session_key] = true;

    wp_send_json_success(array(
        'message' => 'View tracked',
        'views' => $views[$popup_id]
    ));
}

add_action('wp_ajax_novawanimpop1_get_analytics', 'novawanimpop1_ajax_get_analytics');

function novawanimpop1_ajax_get_analytics() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $views = get_option('novawanimpop1_popup_views', array());
    $popups = get_option('novawanimpop1_popups', array());

    $analytics = array();
    foreach ($popups as $popup_id => $popup) {
        $analytics[$popup_id] = array(
            'title' => $popup['title'],
            'views' => isset($views[$popup_id]) ? $views[$popup_id] : 0,
            'enabled' => isset($popup['enabled']) ? $popup['enabled'] : false
        );
    }

    wp_send_json_success($analytics);
}

add_action('wp_ajax_novawanimpop1_duplicate_popup', 'novawanimpop1_ajax_duplicate_popup');

function novawanimpop1_ajax_duplicate_popup() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popup_id = sanitize_text_field($_POST['popup_id']);
    $popups = get_option('novawanimpop1_popups', array());

    if (isset($popups[$popup_id])) {
        $new_popup_id = 'popup_' . time() . '_' . wp_rand(1000, 9999);
        $new_popup = $popups[$popup_id];
        $new_popup['title'] = $new_popup['title'] . ' (Copy)';
        $new_popup['enabled'] = false;

        $popups[$new_popup_id] = $new_popup;
        update_option('novawanimpop1_popups', $popups);

        wp_send_json_success(array(
            'message' => __('Popup duplicated successfully!', 'novawanimpop1'),
            'popup_id' => $new_popup_id
        ));
    } else {
        wp_send_json_error(array(
            'message' => __('Popup not found.', 'novawanimpop1')
        ));
    }
}

add_action('wp_ajax_novawanimpop1_export_popups', 'novawanimpop1_ajax_export_popups');

function novawanimpop1_ajax_export_popups() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    $popups = get_option('novawanimpop1_popups', array());
    $settings = get_option('novawanimpop1_settings', array());

    $export_data = array(
        'popups' => $popups,
        'settings' => $settings,
        'version' => NOVAWANIMPOP1_VERSION,
        'exported_at' => current_time('mysql')
    );

    wp_send_json_success(array(
        'data' => base64_encode(json_encode($export_data)),
        'filename' => 'novawanimpop1-popups-export-' . date('Y-m-d-H-i-s') . '.json'
    ));
}

add_action('wp_ajax_novawanimpop1_import_popups', 'novawanimpop1_ajax_import_popups');

function novawanimpop1_ajax_import_popups() {
    check_ajax_referer('novawanimpop1_admin_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized', 'novawanimpop1'));
    }

    if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => __('No file uploaded or upload error.', 'novawanimpop1')));
    }

    $file_content = file_get_contents($_FILES['import_file']['tmp_name']);
    $import_data = json_decode($file_content, true);

    if (!$import_data || !isset($import_data['popups'])) {
        wp_send_json_error(array('message' => __('Invalid import file format.', 'novawanimpop1')));
    }

    $current_popups = get_option('novawanimpop1_popups', array());
    $imported_count = 0;

    foreach ($import_data['popups'] as $popup_id => $popup_data) {
        $new_popup_id = 'popup_' . time() . '_' . wp_rand(1000, 9999) . '_imported';
        $current_popups[$new_popup_id] = $popup_data;
        $imported_count++;
    }

    update_option('novawanimpop1_popups', $current_popups);

    if (isset($import_data['settings'])) {
        $current_settings = get_option('novawanimpop1_settings', array());
        $merged_settings = array_merge($current_settings, $import_data['settings']);
        update_option('novawanimpop1_settings', $merged_settings);
    }

    wp_send_json_success(array(
        'message' => sprintf(__('%d popups imported successfully!', 'novawanimpop1'), $imported_count)
    ));
}