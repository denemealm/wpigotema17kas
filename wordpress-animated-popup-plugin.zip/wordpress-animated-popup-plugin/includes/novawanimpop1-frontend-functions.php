<?php
if (!defined('ABSPATH')) {
    exit;
}

function novawanimpop1_frontend_assets() {
    $settings = get_option('novawanimpop1_settings', array());

    if (!isset($settings['enable_popups']) || !$settings['enable_popups']) {
        return;
    }

    $version = time();

    wp_enqueue_style(
        'novawanimpop1-frontend',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/css/novawanimpop1-frontend.css',
        array('dashicons'),
        $version
    );

    wp_enqueue_script(
        'novawanimpop1-frontend',
        NOVAWANIMPOP1_PLUGIN_URL . 'assets/js/novawanimpop1-frontend.js',
        array('jquery'),
        $version,
        true
    );

    $popups = get_option('novawanimpop1_popups', array());
    $active_popups = array();

    foreach ($popups as $popup_id => $popup) {
        if (isset($popup['enabled']) && $popup['enabled'] && novawanimpop1_should_display_popup($popup)) {
            $active_popups[$popup_id] = $popup;
        }
    }

    wp_localize_script('novawanimpop1-frontend', 'novawanimpop1_frontend', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('novawanimpop1_frontend_nonce'),
        'popups' => $active_popups,
        'settings' => $settings
    ));
}

function novawanimpop1_should_display_popup($popup) {
    $display_on = isset($popup['display_on']) ? $popup['display_on'] : 'all';

    switch ($display_on) {
        case 'all':
            return true;
        case 'homepage':
            return is_front_page();
        case 'shop':
            return function_exists('is_shop') && is_shop();
        case 'product':
            return function_exists('is_product') && is_product();
        case 'cart':
            return function_exists('is_cart') && is_cart();
        case 'checkout':
            return function_exists('is_checkout') && is_checkout();
        case 'specific':
            return false;
        default:
            return false;
    }
}

function novawanimpop1_render_popups() {
    $settings = get_option('novawanimpop1_settings', array());

    if (!isset($settings['enable_popups']) || !$settings['enable_popups']) {
        return;
    }

    $popups = get_option('novawanimpop1_popups', array());

    foreach ($popups as $popup_id => $popup) {
        if (isset($popup['enabled']) && $popup['enabled'] && novawanimpop1_should_display_popup($popup)) {
            novawanimpop1_render_single_popup($popup_id, $popup);
        }
    }
}

function novawanimpop1_render_single_popup($popup_id, $popup) {
    $template = isset($popup['template']) ? $popup['template'] : 'template1';
    $heading = isset($popup['heading']) ? $popup['heading'] : '';
    $description = isset($popup['description']) ? $popup['description'] : '';
    $button_text = isset($popup['button_text']) ? $popup['button_text'] : '';
    $button_link = isset($popup['button_link']) ? $popup['button_link'] : '';
    $button_target = isset($popup['button_target']) && $popup['button_target'] ? '_blank' : '_self';
    $visual_type = isset($popup['visual_type']) ? $popup['visual_type'] : 'image';
    $image = isset($popup['image']) ? $popup['image'] : '';
    $countdown = isset($popup['countdown']) && $popup['countdown'];
    $countdown_end = isset($popup['countdown_end']) ? $popup['countdown_end'] : '';

    $heading_size = isset($popup['heading_size']) ? $popup['heading_size'] : 32;
    $heading_color = isset($popup['heading_color']) ? $popup['heading_color'] : '#ffffff';
    $description_size = isset($popup['description_size']) ? $popup['description_size'] : 16;
    $description_color = isset($popup['description_color']) ? $popup['description_color'] : '#ffffff';
    $button_size = isset($popup['button_size']) ? $popup['button_size'] : 18;
    $button_color = isset($popup['button_color']) ? $popup['button_color'] : '#764ba2';
    $button_bg = isset($popup['button_bg']) ? $popup['button_bg'] : '#ffffff';

    $icon_name = isset($popup['icon']) ? $popup['icon'] : 'star-filled';
    $icon_size = isset($popup['icon_size']) ? $popup['icon_size'] : 60;
    $icon_color = isset($popup['icon_color']) ? $popup['icon_color'] : '#ffffff';
    $icon_bg = isset($popup['icon_bg']) ? $popup['icon_bg'] : 'transparent';
    $icon_position = isset($popup['icon_position']) ? $popup['icon_position'] : 'top';

    $trigger = isset($popup['trigger']) ? $popup['trigger'] : 'time';
    $delay = isset($popup['delay']) ? $popup['delay'] : 3000;
    $click_selector = isset($popup['click_selector']) ? $popup['click_selector'] : '';
    $frequency = isset($popup['frequency']) ? $popup['frequency'] : 'always';
    $frequency_hours = isset($popup['frequency_hours']) ? $popup['frequency_hours'] : 24;

    $popup_width = isset($popup['popup_width']) && !empty($popup['popup_width']) ? $popup['popup_width'] : null;
    $popup_width_unit = isset($popup['popup_width_unit']) ? $popup['popup_width_unit'] : 'px';
    $popup_height = isset($popup['popup_height']) && !empty($popup['popup_height']) ? $popup['popup_height'] : null;
    $popup_height_unit = isset($popup['popup_height_unit']) ? $popup['popup_height_unit'] : 'px';

    $popup_styles = '';
    if ($popup_width) {
        $popup_styles .= 'width: ' . esc_attr($popup_width) . esc_attr($popup_width_unit) . ';';
        $popup_styles .= 'max-width: ' . esc_attr($popup_width) . esc_attr($popup_width_unit) . ';';
    }
    if ($popup_height) {
        $popup_styles .= 'height: ' . esc_attr($popup_height) . esc_attr($popup_height_unit) . ';';
    }

    ?>
    <div id="novawanimpop1-popup-<?php echo esc_attr($popup_id); ?>"
         class="novawanimpop1-popup-overlay"
         style="display: none;"
         data-trigger="<?php echo esc_attr($trigger); ?>"
         data-delay="<?php echo esc_attr($delay); ?>"
         data-click-selector="<?php echo esc_attr($click_selector); ?>"
         data-frequency="<?php echo esc_attr($frequency); ?>"
         data-frequency-hours="<?php echo esc_attr($frequency_hours); ?>">

        <div class="novawanimpop1-popup-wrapper">
            <div class="novawanimpop1-popup-inner novawanimpop1-<?php echo esc_attr($template); ?>" style="<?php echo $popup_styles; ?>">
                <button class="novawanimpop1-popup-close">
                    <span class="dashicons dashicons-no-alt"></span>
                </button>

                <div class="novawanimpop1-popup-content">
                    <?php if ($visual_type === 'icon' && $icon_name): ?>
                        <div class="novawanimpop1-popup-icon novawanimpop1-icon-<?php echo esc_attr($icon_position); ?>">
                            <span class="dashicons dashicons-<?php echo esc_attr($icon_name); ?>"
                                  style="font-size: <?php echo esc_attr($icon_size); ?>px;
                                         color: <?php echo esc_attr($icon_color); ?>;
                                         background: <?php echo esc_attr($icon_bg); ?>;
                                         width: <?php echo esc_attr($icon_size); ?>px;
                                         height: <?php echo esc_attr($icon_size); ?>px;
                                         line-height: <?php echo esc_attr($icon_size); ?>px;
                                         padding: 15px;
                                         border-radius: 12px;
                                         display: inline-flex;
                                         align-items: center;
                                         justify-content: center;"></span>
                        </div>
                    <?php elseif ($visual_type === 'image' && $image): ?>
                        <div class="novawanimpop1-popup-image">
                            <img src="<?php echo esc_url($image); ?>" alt="">
                        </div>
                    <?php endif; ?>

                    <?php if ($heading): ?>
                        <h2 class="novawanimpop1-popup-title"
                            style="font-size: <?php echo esc_attr($heading_size); ?>px;
                                   color: <?php echo esc_attr($heading_color); ?>;">
                            <?php echo esc_html($heading); ?>
                        </h2>
                    <?php endif; ?>

                    <?php if ($description): ?>
                        <div class="novawanimpop1-popup-description"
                             style="font-size: <?php echo esc_attr($description_size); ?>px;
                                    color: <?php echo esc_attr($description_color); ?>;">
                            <?php echo wp_kses_post($description); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($countdown && $countdown_end): ?>
                        <div class="novawanimpop1-countdown" data-end="<?php echo esc_attr($countdown_end); ?>">
                            <div class="novawanimpop1-countdown-item">
                                <span class="novawanimpop1-days">00</span>
                                <span class="novawanimpop1-label"><?php _e('Days', 'novawanimpop1'); ?></span>
                            </div>
                            <div class="novawanimpop1-countdown-item">
                                <span class="novawanimpop1-hours">00</span>
                                <span class="novawanimpop1-label"><?php _e('Hours', 'novawanimpop1'); ?></span>
                            </div>
                            <div class="novawanimpop1-countdown-item">
                                <span class="novawanimpop1-minutes">00</span>
                                <span class="novawanimpop1-label"><?php _e('Minutes', 'novawanimpop1'); ?></span>
                            </div>
                            <div class="novawanimpop1-countdown-item">
                                <span class="novawanimpop1-seconds">00</span>
                                <span class="novawanimpop1-label"><?php _e('Seconds', 'novawanimpop1'); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($button_text): ?>
                        <div class="novawanimpop1-popup-button-wrapper">
                            <a href="<?php echo esc_url($button_link); ?>"
                               class="novawanimpop1-popup-button"
                               target="<?php echo esc_attr($button_target); ?>"
                               style="font-size: <?php echo esc_attr($button_size); ?>px;
                                      color: <?php echo esc_attr($button_color); ?>;
                                      background: <?php echo esc_attr($button_bg); ?>;">
                                <?php echo esc_html($button_text); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function novawanimpop1_generate_popup_styles($popup) {
    $styles = '';

    if (isset($popup['heading_size']) || isset($popup['heading_color'])) {
        $styles .= '.novawanimpop1-popup-title {';
        if (isset($popup['heading_size'])) {
            $styles .= 'font-size: ' . intval($popup['heading_size']) . 'px;';
        }
        if (isset($popup['heading_color'])) {
            $styles .= 'color: ' . sanitize_hex_color($popup['heading_color']) . ';';
        }
        $styles .= '}';
    }

    if (isset($popup['description_size']) || isset($popup['description_color'])) {
        $styles .= '.novawanimpop1-popup-description {';
        if (isset($popup['description_size'])) {
            $styles .= 'font-size: ' . intval($popup['description_size']) . 'px;';
        }
        if (isset($popup['description_color'])) {
            $styles .= 'color: ' . sanitize_hex_color($popup['description_color']) . ';';
        }
        $styles .= '}';
    }

    if (isset($popup['button_size']) || isset($popup['button_color']) || isset($popup['button_bg'])) {
        $styles .= '.novawanimpop1-popup-button {';
        if (isset($popup['button_size'])) {
            $styles .= 'font-size: ' . intval($popup['button_size']) . 'px;';
        }
        if (isset($popup['button_color'])) {
            $styles .= 'color: ' . sanitize_hex_color($popup['button_color']) . ';';
        }
        if (isset($popup['button_bg'])) {
            $styles .= 'background: ' . sanitize_hex_color($popup['button_bg']) . ';';
        }
        $styles .= '}';
    }

    return $styles;
}