<?php
/**
 * Security file to prevent direct access to includes directory
 *
 * @package WordPress Animated Popup Plugin
 * @version 1.0
 * @author wpigo
 * @copyright Copyright (c) wpigo
 * @license Proprietary - https://wpigo.com/license
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

// Security headers
header('HTTP/1.0 403 Forbidden');
exit('Directory access is forbidden.');