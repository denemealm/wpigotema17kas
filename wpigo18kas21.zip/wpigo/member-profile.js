jQuery(document).ready(function($) {
    'use strict';

    // Toggle license keys expand/collapse
    $('.wpigo-toggle-license-btn').on('click', function() {
        var $btn = $(this);
        var targetId = $btn.data('target');
        var $target = $('#' + targetId);

        console.log('Button clicked!', targetId); // Debug

        if ($target.length === 0) {
            console.error('Target element not found:', targetId);
            return;
        }

        if ($target.is(':visible')) {
            $target.slideUp(300);
            $btn.text('🔑 Show License Keys');
        } else {
            // Hide all other expanded license sections first
            $('.wpigo-license-keys-expandable').slideUp(300);
            $('.wpigo-toggle-license-btn').text('🔑 Show License Keys');

            // Show this one
            $target.slideDown(300);
            $btn.text('🔑 Hide License Keys');
        }
    });

    // Copy to clipboard
    $('.wpigo-license-copy-btn').on('click', function() {
        var $btn = $(this);
        var targetSelector = $btn.data('copy-target');
        var $input = $(targetSelector);
        var originalType = $input.attr('type');

        // Temporarily change to text to copy
        $input.attr('type', 'text');
        $input.select();
        document.execCommand('copy');
        $input.attr('type', originalType);

        // Visual feedback
        var originalText = $btn.text();
        $btn.text('✓ Copied!').css('background', '#27ae60');

        setTimeout(function() {
            $btn.text(originalText).css('background', '');
        }, 2000);
    });

    // Toggle show/hide for password fields
    $('.wpigo-license-toggle-btn').on('click', function() {
        var $btn = $(this);
        var targetSelector = $btn.data('toggle-target');
        var $input = $(targetSelector);

        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $btn.text('👁 Hide');
        } else {
            $input.attr('type', 'password');
            $btn.text('👁 Show');
        }
    });

    // Debug: Log if elements exist
    console.log('Toggle buttons found:', $('.wpigo-toggle-license-btn').length);
    console.log('Expandable sections found:', $('.wpigo-license-keys-expandable').length);
});
