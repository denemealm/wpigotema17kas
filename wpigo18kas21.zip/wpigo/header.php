<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
     <meta name="copyright" content="© <?php echo date('Y'); ?> WPiGo. All rights reserved.">
    <meta name="publisher" content="WPiGo">
    <meta name="reply-to" content="contact@wpigo.com">
    <meta name="web_author" content="WPiGo Team">
    <meta name="designer" content="WPiGo Team">
    <meta name="category" content="E-commerce, Digital Marketplace">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
        <meta name="author" content="WPiGo Team">
    <?php
    // Dinamik meta veriler için değişkenleri hazırla
    $meta_title = '';
    $meta_description = '';
    $meta_date = date('Y-m-d');
    $meta_type = 'WebPage';
    $meta_subjects = array();

    if (is_front_page() || is_home()) {
        // Ana sayfa
        $meta_title = get_bloginfo('name') . ' - ' . get_bloginfo('description');
        $meta_description = get_bloginfo('description') ?: 'WPiGo - Premium WordPress Plugins, Themes & Digital Products Marketplace. Find high-quality WordPress products at wpigo.com';
        $meta_subjects = array('WordPress', 'Plugins', 'Themes', 'Digital Products', 'Marketplace');
    } elseif (is_single()) {
        // Tekil post/ürün sayfası
        $meta_title = get_the_title();
        $meta_description = get_the_excerpt() ?: wp_trim_words(get_the_content(), 30);
        $meta_date = get_the_date('Y-m-d');
        $meta_type = 'Product';

        $cats = get_the_category();
        $tags = get_the_tags();
        if ($cats) {
            foreach($cats as $cat) {
                $meta_subjects[] = $cat->name;
            }
        }
        if ($tags) {
            foreach($tags as $tag) {
                $meta_subjects[] = $tag->name;
            }
        }
    } elseif (is_page()) {
        // Normal sayfa
        $meta_title = get_the_title();
        $meta_description = get_the_excerpt() ?: wp_trim_words(get_the_content(), 30);
        $meta_date = get_the_date('Y-m-d');
        $meta_type = 'WebPage';
    } elseif (is_category()) {
        // Kategori arşivi
        $category = get_queried_object();
        $meta_title = single_cat_title('', false);
        $meta_description = strip_tags(category_description()) ?: 'Browse ' . single_cat_title('', false) . ' products on WPiGo';
        $meta_subjects = array(single_cat_title('', false), 'WordPress', 'Products');
        $meta_type = 'CollectionPage';
    } elseif (is_tag()) {
        // Etiket arşivi
        $meta_title = single_tag_title('', false);
        $meta_description = strip_tags(tag_description()) ?: 'Products tagged with ' . single_tag_title('', false);
        $meta_subjects = array(single_tag_title('', false), 'WordPress');
        $meta_type = 'CollectionPage';
    } elseif (is_search()) {
        // Arama sonuçları
        $meta_title = 'Search Results for: ' . get_search_query();
        $meta_description = 'Search results for "' . get_search_query() . '" on WPiGo';
        $meta_subjects = array('Search', get_search_query());
        $meta_type = 'SearchResultsPage';
    } elseif (is_404()) {
        // 404 sayfası
        $meta_title = 'Page Not Found';
        $meta_description = 'The page you are looking for could not be found.';
        $meta_subjects = array('Error', '404');
    } elseif (is_archive()) {
        // Diğer arşivler
        $meta_title = get_the_archive_title();
        $meta_description = get_the_archive_description() ?: 'Archive page on WPiGo';
        $meta_type = 'CollectionPage';
    } else {
        // Fallback
        $meta_title = get_bloginfo('name');
        $meta_description = get_bloginfo('description');
        $meta_subjects = array('WordPress', 'Plugins', 'Themes');
    }

    // Subjects boşsa varsayılan değerleri kullan
    if (empty($meta_subjects)) {
        $meta_subjects = array('WordPress', 'Plugins', 'Themes', 'Digital Products');
    }
    ?>

    <meta name="abstract" content="<?php echo esc_attr($meta_description); ?>">

    <link rel="schema.DC" href="http://purl.org/dc/elements/1.1/">
    <link rel="schema.DCTERMS" href="http://purl.org/dc/terms/">
    <meta name="DC.Title" content="<?php echo esc_attr($meta_title); ?>">
    <meta name="DC.Creator" content="WPiGo Team">
    <meta name="DC.Subject" content="<?php echo esc_attr(implode(', ', $meta_subjects)); ?>">
    <meta name="DC.Description" content="<?php echo esc_attr($meta_description); ?>">
    <meta name="DC.Publisher" content="WPiGo">
    <meta name="DC.Contributor" content="WPiGo Team">
    <meta name="DC.Date" content="<?php echo esc_attr($meta_date); ?>">
    <meta name="DC.Type" content="<?php echo esc_attr($meta_type); ?>">
    <meta name="DC.Format" content="text/html">
    <meta name="DC.Identifier" content="<?php echo esc_url(is_front_page() ? home_url('/') : (is_category() ? get_category_link(get_queried_object_id()) : (is_tag() ? get_tag_link(get_queried_object_id()) : get_permalink()))); ?>">
    <meta name="DC.Source" content="https://wpigo.com">
    <meta name="DC.Language" content="<?php echo esc_attr(get_bloginfo('language')); ?>">
    <meta name="DC.Coverage" content="Worldwide">
    <meta name="DC.Rights" content="Copyright © <?php echo date('Y'); ?> WPiGo. All rights reserved.">
    
    <?php
    // Breadcrumb schema (Organization and WebSite schemas are auto-loaded via WPiGo_Schema class)
    echo wpigo_get_breadcrumb_schema();
    ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="wpigo-header">
    <div class="wpigo-header-container">
        <div class="wpigo-header-inner">
            <div class="wpigo-site-branding">
                <?php
                if (has_custom_logo()) {
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    
                    if ($logo && isset($logo[0], $logo[1], $logo[2])) :
                    ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" 
                           class="custom-logo-link" 
                           rel="home"
                           aria-label="<?php echo esc_attr(get_bloginfo('name')); ?> - Home">
                            <img src="<?php echo esc_url($logo[0]); ?>" 
                                 alt="<?php echo esc_attr(get_bloginfo('name')); ?>" 
                                 fetchpriority="high"
                                 width="<?php echo esc_attr($logo[1]); ?>"
                                 height="<?php echo esc_attr($logo[2]); ?>">
                        </a>
                    <?php
                    endif;
                } else {
                    ?>
                    <h1 class="wpigo-site-title">
                        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                            <?php bloginfo('name'); ?>
                        </a>
                    </h1>
                    <?php
                }
                ?>
            </div>

            <nav class="wpigo-nav" aria-label="Primary Navigation">
                <input type="checkbox" 
                       id="wpigo-mobile-menu-toggle" 
                       class="wpigo-mobile-menu-toggle" 
                       aria-label="Toggle mobile menu">
                
                <label for="wpigo-mobile-menu-toggle"
                       class="wpigo-hamburger"
                       aria-label="Menu">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </label>

                <div class="wpigo-nav-content">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'wpigo-menu',
                        'fallback_cb' => false,
                    ));
                    ?>

                    <div class="wpigo-nav-actions">
                        <?php if (is_user_logged_in()) : ?>
                            <?php 
                            $current_user = wp_get_current_user();
                            $user_profile_url = home_url('/member/' . urlencode($current_user->user_login) . '/');
                            $logout_url = wp_logout_url(home_url('/'));
                            ?>
                            <a href="<?php echo esc_url($user_profile_url); ?>" 
                               class="wpigo-btn wpigo-btn-sell">
                                My Account
                            </a>
                            <a href="<?php echo esc_url($logout_url); ?>" 
                               class="wpigo-btn wpigo-btn-secondary">
                                Logout
                            </a>
                        <?php else : ?>
                            <a href="<?php echo esc_url(wp_login_url()); ?>" 
                               class="wpigo-btn wpigo-btn-secondary">
                                Login
                            </a>
                            <a href="<?php echo esc_url(wp_registration_url()); ?>" 
                               class="wpigo-btn wpigo-btn-primary">
                                Register
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>