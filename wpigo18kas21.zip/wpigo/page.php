<?php
/**
 * Template for displaying pages (Privacy Policy, Terms of Service, etc.)
 * Full-width layout without sidebar
 */
?>
<?php get_header(); ?>

<div class="wpigo-wrapper">

    <main class="wpigo-content-container" role="main">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

        <!-- Page Title Section -->
        <header class="wpigo-page-title-section">
            <h1 class="wpigo-page-title" itemprop="headline" id="page-title"><?php the_title(); ?></h1>
        </header>

        <!-- Page Content (Full Width) -->
        <article id="post-<?php the_ID(); ?>" <?php post_class('wpigo-page-article'); ?> itemscope itemtype="https://schema.org/WebPage" role="article" aria-labelledby="page-title">

            <div class="wpigo-page-content">

                <?php if (has_post_thumbnail()) : ?>
                    <div class="wpigo-page-featured-image">
                        <?php the_post_thumbnail('large', array(
                            'class' => 'wpigo-page-thumbnail',
                            'loading' => 'eager',
                            'fetchpriority' => 'high',
                            'alt' => esc_attr(get_the_title())
                        )); ?>
                    </div>
                <?php endif; ?>

                <div class="wpigo-page-body" itemprop="text">
                    <?php the_content(); ?>
                </div>

                <?php
                // Pagination for multi-page content
                wp_link_pages(array(
                    'before' => '<nav class="wpigo-page-pagination" role="navigation" aria-label="Page navigation"><span class="wpigo-page-pagination-label">' . __('Pages:', 'wpigo') . '</span>',
                    'after'  => '</nav>',
                    'link_before' => '<span class="wpigo-page-number">',
                    'link_after'  => '</span>',
                ));
                ?>

            </div>

        </article>

        <?php
        // Display last modified date for all pages
        $modified_date = get_the_modified_date('F j, Y');
        ?>
        <aside class="wpigo-page-meta" role="complementary">
            <p class="wpigo-page-last-updated">
                <strong>Last Updated:</strong> <time datetime="<?php echo get_the_modified_date('c'); ?>" itemprop="dateModified"><?php echo $modified_date; ?></time>
            </p>
        </aside>

        <?php endwhile; else : ?>

        <!-- No Content Found -->
        <section class="wpigo-no-content">
            <h1><?php _e('Page Not Found', 'wpigo'); ?></h1>
            <p><?php _e('Sorry, the page you are looking for does not exist.', 'wpigo'); ?></p>
            <a href="<?php echo esc_url(home_url()); ?>" class="wpigo-btn wpigo-btn-primary"><?php _e('Return to Homepage', 'wpigo'); ?></a>
        </section>

        <?php endif; ?>

    </main>

</div>

<!-- WebPage schema is now automatically generated via WPiGo_Schema class in wp_head -->

<?php get_footer(); ?>
