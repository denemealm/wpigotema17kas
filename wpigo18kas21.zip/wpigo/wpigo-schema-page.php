<?php
/**
 * Page Schemas
 *
 * Generates Schema.org markup for various page types
 * Includes WebPage, ContactPage, CollectionPage
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate WebPage Schema (regular pages)
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_webpage() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "WebPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "dateModified" => get_the_modified_date('c'),
        "datePublished" => get_the_date('c'),
        "inLanguage" => get_bloginfo('language')
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate ContactPage Schema
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_contact_page() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "ContactPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => "Contact WPiGo for support, sales inquiries, or other questions.",
        "mainEntity" => [
            "@type" => "ContactPoint",
            "contactType" => "Customer Service",
            "availableLanguage" => ["en", "tr"]
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate CollectionPage Schema for sitemap
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_sitemap_page() {
    $sitemap_description = "Complete sitemap of all WordPress plugins, themes, and resources available on WPiGo.";

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "CollectionPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => $sitemap_description,
        "dateModified" => get_the_modified_date('c'),
        "inLanguage" => get_bloginfo('language')
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate CollectionPage Schema for homepage/archive with product list
 *
 * @param array $schema_items Array of product ListItem schemas
 * @return string JSON-LD schema markup
 */
function wpigo_schema_collection_page($schema_items = array()) {
    if (empty($schema_items)) {
        return '';
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "CollectionPage",
        "name" => is_category() ? single_cat_title('', false) : get_bloginfo('name'),
        "description" => is_category() ? strip_tags(category_description()) : get_bloginfo('description'),
        "url" => is_category() ? get_category_link(get_query_var('cat')) : home_url(),
        "mainEntity" => [
            "@type" => "ItemList",
            "itemListElement" => $schema_items
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}
