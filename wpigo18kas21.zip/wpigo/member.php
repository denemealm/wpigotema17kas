<?php
/**
 * Member Profile Template
 * Combined profile view and edit page
 * - For own profile: Shows tabs (Edit Profile + My Purchases)
 * - For other profiles: Shows public information only
 */

// Get member info from query - DO THIS BEFORE get_header() for form processing
global $wp_query;
$member_username = get_query_var('member_username');

if (empty($member_username)) {
    // Fallback: try to get from URL, ensuring it's sanitized
    $request_uri = esc_url_raw(wp_unslash($_SERVER['REQUEST_URI']));
    if (preg_match('#/member/([^/]+)/?#', $request_uri, $matches)) {
        $member_username = sanitize_user($matches[1]);
    }
}

// Get user by username after ensuring the username is clean
$member_username = sanitize_user($member_username);
$member = get_user_by('login', $member_username);

if (!$member) {
    get_header();
    ?>
    <div class="wpigo-wrapper">
        <main class="wpigo-content-container">
            <div class="wpigo-member-not-found">
                <h1>Member Not Found</h1>
                <p>Sorry, we couldn't find a member with this username.</p>
                <a href="<?php echo home_url(); ?>" class="wpigo-member-btn wpigo-member-btn-primary">← Back to Home</a>
            </div>
        </main>
    </div>
    <?php
    get_footer();
    exit;
}

$member_id = $member->ID;
$is_own_profile = is_user_logged_in() && get_current_user_id() == $member_id;

// Handle form submission BEFORE get_header() to allow redirects
if ($is_own_profile && isset($_POST['wpigo_update_member_profile'])) {

    // Security: Add rate limiting to prevent brute-force attacks.
    $user_ip = $_SERVER['REMOTE_ADDR'];
    $rate_key = 'profile_update_rate_' . md5($user_ip . '_' . $member_id);
    $attempts = get_transient($rate_key) ?: 0;

    if ($attempts > 10) { // Max 10 attempts per 15 minutes
        $redirect_url = home_url('/member/' . $member->user_login . '/');
        wp_redirect(add_query_arg(array(
            'status' => 'error',
            'msg' => urlencode('Too many attempts. Please try again in 15 minutes.')
        ), $redirect_url));
        exit;
    }
    set_transient($rate_key, $attempts + 1, 900); // 900 seconds = 15 minutes

    // Verify nonce - use manual check to avoid wp_die()
    if (!isset($_POST['wpigo_member_profile_nonce']) ||
        !wp_verify_nonce($_POST['wpigo_member_profile_nonce'], 'wpigo_update_member_profile_action')) {
        $redirect_url = home_url('/member/' . $member->user_login . '/');
        wp_redirect(add_query_arg(array(
            'status' => 'error',
            'msg' => urlencode('Security check failed. Please try again.')
        ), $redirect_url));
        exit;
    }

    // Backend validation
    $validation_errors = array();

    // Validate email
    $new_email = sanitize_email($_POST['user_email']);
    if (empty($new_email) || !is_email($new_email)) {
        $validation_errors[] = 'Please enter a valid email address.';
    } elseif ($new_email !== $member->user_email && email_exists($new_email)) {
        $validation_errors[] = 'This email address is already in use.';
    }

    // Validate password change
    $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
        if (empty($current_password)) {
            $validation_errors[] = 'Please enter your current password.';
        } elseif (!wp_check_password($current_password, $member->user_pass, $member->ID)) {
            $validation_errors[] = 'Current password is incorrect.';
        }

        if (empty($new_password)) {
            $validation_errors[] = 'Please enter a new password.';
        } else {
            // Security: Check for common passwords
            $common_passwords = ['password', '123456', '12345678', 'qwerty', 'password123', '111111'];
            if (in_array(strtolower($new_password), $common_passwords, true)) {
                $validation_errors[] = 'This password is too common. Please choose a stronger one.';
            }

            // Security: Enforce password complexity
            if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $new_password)) {
                $validation_errors[] = 'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&).';
            }
        }

        if ($new_password !== $confirm_password) {
            $validation_errors[] = 'New passwords do not match.';
        }
    }

    // Validate display name
    $display_name = sanitize_text_field($_POST['display_name']);
    if (empty($display_name)) {
        $validation_errors[] = 'Display name is required.';
    } elseif (strlen($display_name) > 50) {
        $validation_errors[] = 'Display name must be 50 characters or less.';
    }

    // If validation errors exist, redirect with error message
    if (!empty($validation_errors)) {
        // Use member profile URL for redirect
        $redirect_url = home_url('/member/' . $member->user_login . '/');
        wp_redirect(add_query_arg(array(
            'status' => 'error',
            'msg' => urlencode(implode(' ', $validation_errors))
        ), $redirect_url));
        exit;
    } else {
        // Update user data
        $user_data = array(
            'ID' => $member_id,
            'display_name' => $display_name,
            'user_email' => $new_email
        );

        // Add password to update if changed
        if (!empty($new_password) && !empty($current_password)) {
            $user_data['user_pass'] = $new_password;
        }

        $updated = wp_update_user($user_data);

        if (!is_wp_error($updated)) {

            // Build redirect URL with success parameters
            $redirect_args = array('status' => 'success');

            if ($new_email !== $member->user_email) {
                $redirect_args['email_updated'] = '1';
            }

            if (!empty($new_password)) {
                $redirect_args['password_changed'] = '1';

                // Security: Log out all other sessions to prevent session fixation attacks.
                $sessions = WP_Session_Tokens::get_instance($member_id);
                $sessions->destroy_all();

                // Re-authenticate the current session with a new cookie.
                wp_set_auth_cookie($member_id, true);
            }

            // Use member profile URL for redirect
            $redirect_url = home_url('/member/' . $member->user_login . '/');
            wp_redirect(add_query_arg($redirect_args, $redirect_url));
            exit;
        } else {
            // Use member profile URL for redirect
            $redirect_url = home_url('/member/' . $member->user_login . '/');
            wp_redirect(add_query_arg(array(
                'status' => 'error',
                'msg' => urlencode('Error updating profile: ' . $updated->get_error_message())
            ), $redirect_url));
            exit;
        }
    }
}

// Now it's safe to call get_header() - form submissions have already redirected
get_header();

// Check for status messages
$message = '';
$message_type = '';

if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        $message = 'Profile updated successfully!';
        if (isset($_GET['email_updated'])) {
            $message .= ' Email address updated.';
        }
        if (isset($_GET['password_changed'])) {
            $message .= ' Password changed successfully.';
        }
        $message_type = 'success';
    } elseif ($_GET['status'] == 'error' && isset($_GET['msg'])) {
        $message = urldecode($_GET['msg']);
        $message_type = 'error';
    }
}
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container">

        <?php if ($is_own_profile) : ?>
            <!-- OWN PROFILE: Tabbed Interface -->

            <div class="wpigo-member-profile-page">

                <!-- Profile Header -->
                <div class="wpigo-profile-edit-header">
                    <div class="wpigo-profile-edit-header-content">
                        <h1 class="wpigo-profile-edit-title"><?php echo esc_html($member->display_name); ?></h1>
                        <p class="wpigo-profile-edit-subtitle">@<?php echo esc_html($member->user_login); ?> • Member since <?php echo date('F Y', strtotime($member->user_registered)); ?></p>
                    </div>
                </div>

                <?php if ($message) : ?>
                <div class="wpigo-profile-alert wpigo-profile-alert-<?php echo esc_attr($message_type); ?>" role="alert" aria-live="polite" aria-atomic="true">
                    <span class="wpigo-profile-alert-icon" aria-hidden="true"><?php echo $message_type == 'success' ? '✓' : '⚠'; ?></span>
                    <span class="wpigo-profile-alert-text"><?php echo wp_kses_post($message); ?></span>
                </div>
                <?php endif; ?>

                <!-- Tab Navigation -->
                <div class="wpigo-member-tabs" role="tablist" aria-label="Member profile sections">
                    <button type="button" class="wpigo-member-tab-btn active" id="tab-button-edit-profile" role="tab" aria-selected="true" aria-controls="tab-edit-profile" data-tab="edit-profile">
                        ✏️ Edit Profile
                    </button>
                    <button type="button" class="wpigo-member-tab-btn" id="tab-button-my-purchases" role="tab" aria-selected="false" aria-controls="tab-my-purchases" data-tab="my-purchases">
                        📦 My Purchases
                    </button>
                </div>

                <!-- TAB 1: Edit Profile -->
                <div class="wpigo-member-tab-content active" id="tab-edit-profile" role="tabpanel" aria-labelledby="tab-button-edit-profile">
                    <form method="post" action="<?php echo esc_url(home_url('/member/' . $member->user_login . '/')); ?>" class="wpigo-profile-edit-form">
                        <?php wp_nonce_field('wpigo_update_member_profile_action', 'wpigo_member_profile_nonce'); ?>

                        <!-- Account Settings Section -->
                        <div class="wpigo-profile-section">
                            <div class="wpigo-profile-section-body">
                                <div class="wpigo-profile-form-grid">
                                    <div class="wpigo-profile-field">
                                        <label for="display_name" class="wpigo-profile-label">Display Name <span class="wpigo-profile-required">*</span></label>
                                        <input type="text" id="display_name" name="display_name" value="<?php echo esc_attr($member->display_name); ?>" required maxlength="50" class="wpigo-profile-input" aria-required="true">
                                        <small class="wpigo-profile-help">How your name appears publicly</small>
                                    </div>

                                    <div class="wpigo-profile-field">
                                        <label for="user_email" class="wpigo-profile-label">Email Address <span class="wpigo-profile-required">*</span></label>
                                        <input type="email" id="user_email" name="user_email" value="<?php echo esc_attr($member->user_email); ?>" required maxlength="100" class="wpigo-profile-input" aria-required="true">
                                        <small class="wpigo-profile-help">Your email for notifications and login</small>
                                    </div>

                                    <div class="wpigo-profile-field">
                                        <label class="wpigo-profile-label">Username</label>
                                        <input type="text" value="<?php echo esc_attr($member->user_login); ?>" disabled class="wpigo-profile-input wpigo-profile-input-disabled">
                                        <small class="wpigo-profile-help">Username cannot be changed</small>
                                    </div>
                                </div>

                                <div class="wpigo-profile-divider"></div>

                                <h3 class="wpigo-profile-subsection-title">Change Password</h3>
                                <p class="wpigo-profile-subsection-desc">Leave blank if you don't want to change your password</p>

                                <div class="wpigo-profile-form-grid">
                                    <div class="wpigo-profile-field">
                                        <label for="current_password" class="wpigo-profile-label">Current Password</label>
                                        <input type="password" id="current_password" name="current_password" autocomplete="current-password" class="wpigo-profile-input">
                                    </div>

                                    <div class="wpigo-profile-field">
                                        <label for="new_password" class="wpigo-profile-label">New Password</label>
                                        <input type="password" name="new_password" id="new_password" autocomplete="new-password" minlength="8" class="wpigo-profile-input">
                                        <small class="wpigo-profile-help">Minimum 8 characters</small>
                                    </div>

                                    <div class="wpigo-profile-field">
                                        <label for="confirm_password" class="wpigo-profile-label">Confirm New Password</label>
                                        <input type="password" name="confirm_password" id="confirm_password" autocomplete="new-password" minlength="8" class="wpigo-profile-input">
                                    </div>

                                    <div class="wpigo-profile-field">
                                        <div id="password-strength" style="display: none;" role="status" aria-live="polite" aria-atomic="true">
                                            <div class="wpigo-profile-password-strength">
                                                <div id="password-strength-fill"></div>
                                            </div>
                                            <small id="password-strength-text" class="wpigo-profile-help"></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="wpigo-profile-actions">
                            <button type="submit" name="wpigo_update_member_profile" class="wpigo-profile-btn wpigo-profile-btn-primary">
                                💾 Save Changes
                            </button>
                        </div>
                    </form>
                </div>

                <!-- TAB 2: My Purchases -->
                <div class="wpigo-member-tab-content" id="tab-my-purchases" role="tabpanel" aria-labelledby="tab-button-my-purchases">
                    <?php
                    // Get user's detailed purchase history
                    $purchases = wpigo_get_user_purchases_detailed($member_id);

                    // Performance optimization: Prime post and meta caches for all purchased products.
                    if (!empty($purchases)) {
                        $product_ids = array_column($purchases, 'product_id');
                        if (!empty($product_ids)) {
                            update_post_caches($product_ids, array('post'));
                            update_meta_cache('post', $product_ids);
                        }
                    }

                    if (!empty($purchases)) :
                    ?>
                    <div class="wpigo-member-card">
                        <div class="wpigo-member-card-header wpigo-purchases-header">
                            <h3 class="wpigo-member-card-title">📦 My Purchased Products</h3>
                        </div>
                        <div class="wpigo-member-card-body">
                            <div class="wpigo-member-purchases-list">
                                <?php foreach ($purchases as $purchase) : ?>
                                    <div class="wpigo-member-purchase-card-wrapper">
                                        <div class="wpigo-member-purchase-card">
                                            <div class="wpigo-purchase-product-info">
                                                <?php if ($purchase['product_thumbnail']) : ?>
                                                    <img src="<?php echo esc_url($purchase['product_thumbnail']); ?>"
                                                         alt="<?php echo esc_attr($purchase['product_title']); ?>"
                                                         class="wpigo-purchase-thumbnail">
                                                <?php else : ?>
                                                    <div class="wpigo-purchase-thumbnail-placeholder">
                                                        <span>📦</span>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="wpigo-purchase-details">
                                                    <h4 class="wpigo-purchase-product-title">
                                                        <a href="<?php echo esc_url($purchase['product_url']); ?>">
                                                            <?php echo esc_html($purchase['product_title']); ?>
                                                        </a>
                                                    </h4>

                                                    <div class="wpigo-purchase-meta">
                                                        <span class="wpigo-purchase-meta-item">
                                                            <strong>Order:</strong> <?php echo esc_html($purchase['order_number']); ?>
                                                        </span>
                                                        <span class="wpigo-purchase-meta-item">
                                                            <strong>Date:</strong> <?php echo date('M j, Y', strtotime($purchase['purchase_date'])); ?>
                                                        </span>
                                                        <span class="wpigo-purchase-meta-item">
                                                            <strong>Price:</strong> $<?php echo number_format($purchase['price_paid'], 2); ?>
                                                        </span>
                                                        <span class="wpigo-purchase-meta-item wpigo-purchase-status-<?php echo $purchase['order_status']; ?>">
                                                            <strong>Status:</strong>
                                                            <?php
                                                            if ($purchase['order_status'] === 'wc-completed') {
                                                                echo '✓ Completed';
                                                            } elseif ($purchase['order_status'] === 'wc-pending') {
                                                                echo '⏳ Pending';
                                                            } elseif ($purchase['order_status'] === 'wc-cancelled') {
                                                                echo '✗ Cancelled';
                                                            } else {
                                                                echo esc_html($purchase['order_status']);
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>

                                                    <?php if ($purchase['support_period'] || $purchase['updates_period'] || $purchase['response_time']) : ?>
                                                    <div class="wpigo-purchase-support-info">
                                                        <strong>🛠️ Support & Maintenance:</strong>
                                                        <ul>
                                                            <?php if ($purchase['support_period']) : ?>
                                                                <li>Free Support: <?php echo esc_html($purchase['support_period']); ?> <?php echo $purchase['support_period'] == 1 ? 'month' : 'months'; ?></li>
                                                            <?php endif; ?>
                                                            <?php if ($purchase['updates_period']) : ?>
                                                                <li>Updates: <?php echo $purchase['updates_period'] === 'lifetime' ? 'Lifetime' : esc_html($purchase['updates_period']) . ' ' . ($purchase['updates_period'] == 1 ? 'year' : 'years'); ?></li>
                                                            <?php endif; ?>
                                                            <?php if ($purchase['updates_period'] !== 'lifetime' && !empty($purchase['update_extension_price']) && $purchase['update_extension_price'] > 0) : ?>
                                                                <li>Update Extension: $<?php echo number_format($purchase['update_extension_price'], 2); ?></li>
                                                            <?php endif; ?>
                                                            <?php if ($purchase['response_time']) : ?>
                                                                <li>Response Time: &lt; <?php echo esc_html($purchase['response_time']); ?> hours</li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="wpigo-purchase-actions">
                                                <?php if ($purchase['order_status'] === 'wc-completed') : ?>
                                                    <a href="<?php echo home_url('/download/' . $purchase['license_keys']['purchase_code']); ?>"
                                                       class="wpigo-member-btn wpigo-member-btn-success wpigo-btn-sm">
                                                        ⬇️ Download
                                                    </a>
                                                    <button type="button"
                                                            class="wpigo-member-btn wpigo-member-btn-primary wpigo-btn-sm wpigo-toggle-license-btn"
                                                            data-target="license-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                        🔑 Show License Keys
                                                    </button>
                                                <?php endif; ?>
                                                <a href="<?php echo esc_url($purchase['product_url']); ?>"
                                                   class="wpigo-member-btn wpigo-member-btn-secondary wpigo-btn-sm">
                                                    👁 View Product
                                                </a>
                                            </div>
                                        </div>

                                        <!-- Expandable License Keys Section -->
                                        <?php if ($purchase['order_status'] === 'wc-completed' && isset($purchase['license_keys'])) : ?>
                                        <div class="wpigo-license-keys-expandable" id="license-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>" style="display: none;">
                                            <div class="wpigo-license-keys-header">
                                                <h4>🔑 License Keys for <?php echo esc_html($purchase['product_title']); ?></h4>
                                                <p class="wpigo-license-warning">
                                                    <strong>⚠️ Important:</strong> Keep these keys secure. Use them for product activation and API access.
                                                </p>
                                            </div>

                                            <div class="wpigo-license-keys-grid">
                                                <!-- Purchase Code -->
                                                <div class="wpigo-license-key-item">
                                                    <label class="wpigo-license-key-label">Purchase Code</label>
                                                    <div class="wpigo-license-key-input-group">
                                                        <input type="text"
                                                               class="wpigo-license-key-input"
                                                               value="<?php echo esc_attr($purchase['license_keys']['purchase_code']); ?>"
                                                               readonly
                                                               id="purchase-code-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                        <button type="button"
                                                                class="wpigo-license-copy-btn"
                                                                data-copy-target="#purchase-code-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                            📋 Copy
                                                        </button>
                                                    </div>
                                                    <small class="wpigo-license-key-help">Use this code for product activation and license verification</small>
                                                </div>

                                                <!-- API Key -->
                                                <div class="wpigo-license-key-item">
                                                    <label class="wpigo-license-key-label">API Key</label>
                                                    <div class="wpigo-license-key-input-group">
                                                        <input type="password"
                                                               class="wpigo-license-key-input wpigo-toggleable-key"
                                                               value="<?php echo esc_attr($purchase['license_keys']['api_key']); ?>"
                                                               readonly
                                                               id="api-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                        <button type="button"
                                                                class="wpigo-license-toggle-btn"
                                                                data-toggle-target="#api-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                            👁 Show
                                                        </button>
                                                        <button type="button"
                                                                class="wpigo-license-copy-btn"
                                                                data-copy-target="#api-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                            📋 Copy
                                                        </button>
                                                    </div>
                                                    <small class="wpigo-license-key-help">Use this for public API requests and plugin updates</small>
                                                </div>

                                                <!-- Secret Key -->
                                                <div class="wpigo-license-key-item">
                                                    <label class="wpigo-license-key-label">Secret Key</label>
                                                    <div class="wpigo-license-key-input-group">
                                                        <input type="password"
                                                               class="wpigo-license-key-input wpigo-toggleable-key"
                                                               value="<?php echo esc_attr($purchase['license_keys']['secret_key']); ?>"
                                                               readonly
                                                               id="secret-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                        <button type="button"
                                                                class="wpigo-license-toggle-btn"
                                                                data-toggle-target="#secret-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                            👁 Show
                                                        </button>
                                                        <button type="button"
                                                                class="wpigo-license-copy-btn"
                                                                data-copy-target="#secret-key-<?php echo $purchase['order_id']; ?>-<?php echo $purchase['product_id']; ?>">
                                                            📋 Copy
                                                        </button>
                                                    </div>
                                                    <small class="wpigo-license-key-help">Use this for webhook verification and secure API calls</small>
                                                </div>
                                            </div>

                                            <!-- License Activation Status -->
                                            <div class="wpigo-license-activation-section" style="margin-top: 30px; padding-top: 30px; border-top: 2px solid #e0e0e0;">
                                                <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #333;">
                                                    🌐 License Activation Status
                                                </h4>

                                                <?php
                                                $activations = isset($purchase['license_keys']['activations']) ? $purchase['license_keys']['activations'] : array();
                                                $has_active = false;

                                                // Check if there's any active activation
                                                foreach ($activations as $activation) {
                                                    if (isset($activation['status']) && $activation['status'] === 'active') {
                                                        $has_active = true;
                                                        break;
                                                    }
                                                }
                                                ?>

                                                <?php if (!empty($activations)) : ?>
                                                    <div style="background: <?php echo $has_active ? '#d4edda' : '#fff3cd'; ?>; border: 1px solid <?php echo $has_active ? '#c3e6cb' : '#ffeaa7'; ?>; border-radius: 6px; padding: 15px; margin-bottom: 15px;">
                                                        <p style="margin: 0; font-size: 14px; color: <?php echo $has_active ? '#155724' : '#856404'; ?>;">
                                                            <strong><?php echo $has_active ? '✅ License Activated' : '⚠️ License Not Active'; ?></strong>
                                                        </p>
                                                    </div>

                                                    <table style="width: 100%; border-collapse: collapse; background: #f9f9f9; border-radius: 6px; overflow: hidden;">
                                                        <thead>
                                                            <tr style="background: #2c3e50; color: white;">
                                                                <th style="padding: 12px; text-align: left; font-size: 13px;">Domain</th>
                                                                <th style="padding: 12px; text-align: left; font-size: 13px;">Status</th>
                                                                <th style="padding: 12px; text-align: left; font-size: 13px;">Activated At</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($activations as $activation) : ?>
                                                                <?php
                                                                $status = isset($activation['status']) ? $activation['status'] : 'unknown';
                                                                $status_color = $status === 'active' ? '#28a745' : '#dc3545';
                                                                $status_bg = $status === 'active' ? '#d4edda' : '#f8d7da';
                                                                $status_text = $status === 'active' ? 'Active' : 'Deactivated';
                                                                ?>
                                                                <tr style="border-bottom: 1px solid #e0e0e0;">
                                                                    <td style="padding: 12px; font-size: 13px;">
                                                                        <strong><?php echo esc_html($activation['domain']); ?></strong>
                                                                    </td>
                                                                    <td style="padding: 12px;">
                                                                        <span style="display: inline-block; padding: 4px 10px; background: <?php echo $status_bg; ?>; color: <?php echo $status_color; ?>; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                                                            <?php echo $status_text; ?>
                                                                        </span>
                                                                    </td>
                                                                    <td style="padding: 12px; font-size: 13px; color: #666;">
                                                                        <?php echo date('M j, Y - g:i A', strtotime($activation['activated_at'])); ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>

                                                <?php else : ?>
                                                    <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 6px; padding: 20px; text-align: center;">
                                                        <p style="margin: 0; font-size: 14px; color: #856404;">
                                                            <strong>⚠️ Not Activated Yet</strong>
                                                        </p>
                                                        <p style="margin: 10px 0 0 0; font-size: 13px; color: #666;">
                                                            You haven't activated this license on any domain yet.<br>
                                                            Install the plugin and enter your purchase code to activate.
                                                        </p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                        <?php endif; ?>
                                    </div><!-- .wpigo-member-purchase-card-wrapper -->
                                <?php endforeach; ?>
                            </div>

                            <div class="wpigo-purchase-summary">
                                <p>
                                    <strong>Total Purchases:</strong> <?php echo count($purchases); ?> item(s)
                                    <span class="wpigo-purchase-summary-divider">|</span>
                                    <strong>Total Spent:</strong> $<?php
                                    $total_spent = get_user_meta($member_id, 'wpigo_total_spent', true);
                                    echo number_format($total_spent ?: 0, 2);
                                    ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php else : ?>
                    <div class="wpigo-member-card">
                        <div class="wpigo-member-card-body">
                            <div class="wpigo-member-no-activity" style="text-align: center; padding: 3rem 1rem;">
                                <div style="font-size: 4rem; margin-bottom: 1rem;">🛒</div>
                                <h3 style="margin-bottom: 0.5rem;">No Purchases Yet</h3>
                                <p style="color: var(--wpigo-color-text-muted); margin-bottom: 1.5rem;">You haven't purchased any products yet. Start shopping!</p>
                                <a href="<?php echo home_url(); ?>" class="wpigo-member-btn wpigo-member-btn-primary">
                                    Browse Products
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

            </div>

        <?php else : ?>
            <!-- OTHER'S PROFILE: Public View Only -->

            <div class="wpigo-member-profile-public-header">
                <div class="wpigo-member-public-info">
                    <h1 class="wpigo-member-public-name"><?php echo esc_html($member->display_name); ?></h1>

                    <div class="wpigo-member-public-meta">
                        <span class="wpigo-member-public-badge">
                            👤 Member since <?php echo date('F Y', strtotime($member->user_registered)); ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="wpigo-member-public-content">

                <!-- Recent Comments -->
                <div class="wpigo-member-public-card">
                    <div class="wpigo-member-card-header">
                        <h3 class="wpigo-member-card-title">Recent Activity</h3>
                    </div>
                    <div class="wpigo-member-card-body">
                        <?php
                        $member_comments = get_comments(array(
                            'user_id' => $member_id,
                            'status' => 'approve',
                            'number' => 5,
                            'orderby' => 'comment_date',
                            'order' => 'DESC'
                        ));

                        // Performance optimization: Prime post cache for all commented-on posts.
                        if (!empty($member_comments)) {
                            $post_ids = array_unique(wp_list_pluck($member_comments, 'comment_post_ID'));
                            if (!empty($post_ids)) {
                                update_post_caches($post_ids, array('post'));
                            }
                        }

                        if (!empty($member_comments)) :
                        ?>
                            <div class="wpigo-member-comments-list">
                                <?php foreach ($member_comments as $comment) : ?>
                                    <div class="wpigo-member-comment-item">
                                        <div class="wpigo-member-comment-meta">
                                            <a href="<?php echo get_permalink($comment->comment_post_ID); ?>#comment-<?php echo $comment->comment_ID; ?>" class="wpigo-member-comment-post-link">
                                                Commented on: <strong><?php echo get_the_title($comment->comment_post_ID); ?></strong>
                                            </a>
                                            <span class="wpigo-member-comment-date">
                                                <?php echo human_time_diff(strtotime($comment->comment_date), current_time('timestamp')) . ' ago'; ?>
                                            </span>
                                        </div>
                                        <div class="wpigo-member-comment-excerpt">
                                            <?php echo wp_trim_words($comment->comment_content, 20, '...'); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else : ?>
                            <div class="wpigo-member-no-activity">
                                <p>No recent activity yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        <?php endif; ?>

    </main>
</div>

<style>
/* Tab Navigation */
.wpigo-member-tabs {
    display: flex;
    gap: 0.5rem;
    border-bottom: 2px solid var(--wpigo-color-border);
    margin-bottom: 2rem;
    margin-top: 1.5rem;
}

.wpigo-member-tab-btn {
    padding: 0.875rem 1.75rem;
    background: none;
    border: none;
    border-bottom: 3px solid transparent;
    font-size: 1rem;
    font-weight: 600;
    color: var(--wpigo-color-text-muted);
    cursor: pointer;
    transition: all 0.2s ease;
    margin-bottom: -2px;
}

.wpigo-member-tab-btn:hover {
    color: var(--wpigo-color-primary);
    background: rgba(52, 152, 219, 0.05);
}

.wpigo-member-tab-btn.active {
    color: var(--wpigo-color-primary);
    border-bottom-color: var(--wpigo-color-primary);
}

.wpigo-member-tab-content {
    display: none;
}

.wpigo-member-tab-content.active {
    display: block;
}

/* Profile Header */
.wpigo-profile-edit-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 0.9rem 2rem;
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
    border-radius: var(--wpigo-radius-md);
    color: white;
    margin-bottom: 1.5rem;
}

.wpigo-profile-edit-title {
    font-size: 1.75rem;
    font-weight: 700;
    margin: 0 0 0.25rem 0;
    color: white;
}

.wpigo-profile-edit-subtitle {
    font-size: 0.95rem;
    margin: 0;
    opacity: 0.95;
    color: white;
}

/* Alert Messages */
.wpigo-profile-alert {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 1.25rem;
    border-radius: var(--wpigo-radius-sm);
    margin-bottom: 1.5rem;
    font-size: 0.9375rem;
}

.wpigo-profile-alert-success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
}

.wpigo-profile-alert-error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
}

.wpigo-profile-alert-icon {
    font-size: 1.25rem;
    font-weight: 700;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab Switching
    const tabBtns = document.querySelectorAll('.wpigo-member-tab-btn');
    const tabContents = document.querySelectorAll('.wpigo-member-tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const targetTab = this.dataset.tab;

            // Deactivate all tabs and panels
            tabBtns.forEach(b => {
                b.classList.remove('active');
                b.setAttribute('aria-selected', 'false');
            });
            tabContents.forEach(c => c.classList.remove('active'));

            // Activate the clicked tab and its corresponding panel
            this.classList.add('active');
            this.setAttribute('aria-selected', 'true');
            document.getElementById('tab-' + targetTab).classList.add('active');
        });
    });

    // Password strength checker
    const newPasswordInput = document.getElementById('new_password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const strengthIndicator = document.getElementById('password-strength');
    const strengthFill = document.getElementById('password-strength-fill');
    const strengthText = document.getElementById('password-strength-text');

    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', function() {
            const password = this.value;

            if (password.length === 0) {
                strengthIndicator.style.display = 'none';
                return;
            }

            strengthIndicator.style.display = 'block';

            let strength = 0;
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;

            let strengthLabel = '';
            let color = '';

            if (strength <= 2) {
                strengthLabel = 'Weak';
                color = '#e74c3c';
                strengthFill.style.width = '33%';
            } else if (strength <= 4) {
                strengthLabel = 'Medium';
                color = '#f39c12';
                strengthFill.style.width = '66%';
            } else {
                strengthLabel = 'Strong';
                color = '#2ecc71';
                strengthFill.style.width = '100%';
            }

            strengthFill.style.backgroundColor = color;
            strengthText.textContent = 'Password strength: ' + strengthLabel;
            strengthText.style.color = color;
        });

        // Password confirmation validation
        confirmPasswordInput.addEventListener('input', function() {
            if (this.value !== newPasswordInput.value && this.value.length > 0) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
    }

    // File upload button text update
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'Choose Photo';
            const label = this.nextElementSibling;
            if (label) {
                label.textContent = this.files[0] ? '✓ ' + fileName : 'Choose Photo';
            }
        });
    }
});
</script>

<?php
// Load member-profile.js for license key functionality
wp_enqueue_script('wpigo-member-profile', get_template_directory_uri() . '/js/member-profile.js', array('jquery'), '1.0', true);
?>

<?php get_footer(); ?>
