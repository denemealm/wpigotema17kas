jQuery(document).ready(function($) {
    'use strict';

    // Add to Cart button handler
    $(document).on('click', '.wpigo-btn-cart', function(e) {
        e.preventDefault();

        var $btn = $(this);
        var productId = $btn.data('product-id');
        var originalText = $btn.text();

        // Disable button during request
        $btn.prop('disabled', true).text('Adding...');

        $.ajax({
            url: wpigoCart.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_add_to_cart',
                product_id: productId,
                nonce: wpigoCart.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Set cart token cookie for guests (if provided)
                    if (response.data.cart_token) {
                        document.cookie = 'wpigo_cart_token=' + response.data.cart_token + '; path=/; max-age=' + (86400 * 30);
                    }

                    // Show success message
                    $btn.text('Added!').css('background', '#27ae60');

                    // Redirect to cart after 1 second
                    setTimeout(function() {
                        window.location.href = wpigoCart.cart_url;
                    }, 1000);
                } else {
                    alert(response.data.message || 'Failed to add to cart');
                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Remove from Cart button handler
    $(document).on('click', '.wpigo-cart-remove-btn', function(e) {
        e.preventDefault();

        var $btn = $(this);
        var productId = $btn.data('product-id');
        var $cartItem = $btn.closest('.wpigo-cart-item');

        if (!confirm('Remove this item from cart?')) {
            return;
        }

        $btn.prop('disabled', true).text('Removing...');

        $.ajax({
            url: wpigoCart.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_remove_from_cart',
                product_id: productId,
                nonce: wpigoCart.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Fade out and remove item
                    $cartItem.fadeOut(300, function() {
                        $(this).remove();

                        // Update totals
                        var cartTotal = response.data.cart_total;
                        var cartCount = response.data.cart_count;

                        $('#wpigo-cart-subtotal').text('$' + cartTotal.toFixed(2));
                        $('#wpigo-cart-total').text('$' + cartTotal.toFixed(2));

                        // If cart is empty, reload page to show empty cart message
                        if (cartCount === 0) {
                            location.reload();
                        }
                    });
                } else {
                    alert(response.data.message || 'Failed to remove item');
                    $btn.prop('disabled', false).text('Remove');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                $btn.prop('disabled', false).text('Remove');
            }
        });
    });

    // Checkout button - Redirect to checkout page
    $(document).on('click', '.wpigo-btn-checkout', function(e) {
        e.preventDefault();
        window.location.href = wpigoCart.checkout_url;
    });

    // Purchase Now button - Direct checkout for single product
    $(document).on('click', '.wpigo-btn-purchase', function(e) {
        e.preventDefault();

        // Find the product ID from the same card
        var $card = $(this).closest('.wpigo-card-purchase');
        var $addToCartBtn = $card.find('.wpigo-btn-cart');
        var productId = $addToCartBtn.data('product-id');

        if (!productId) {
            alert('Product ID not found');
            return;
        }

        // Redirect to checkout with product ID
        window.location.href = wpigoCart.checkout_url + '?product_id=' + productId;
    });
});
