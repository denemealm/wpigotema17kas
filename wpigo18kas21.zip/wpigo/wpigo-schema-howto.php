<?php
/**
 * HowTo Schema
 *
 * Generates Schema.org markup for HowTo guides
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate HowTo Schema for product
 *
 * @param int $post_id Post ID
 * @return string JSON-LD schema markup
 */
function wpigo_schema_howto($post_id) {
    if (!$post_id) {
        return '';
    }

    $howto_data_raw = get_post_meta($post_id, 'product_howto', true);

    if (empty($howto_data_raw)) {
        return '';
    }

    $howto_data = json_decode($howto_data_raw, true);

    if (empty($howto_data) || empty($howto_data['title']) || empty($howto_data['steps'])) {
        return '';
    }

    // Calculate estimated time (10 minutes per step)
    $step_count = count($howto_data['steps']);
    $total_minutes = $step_count * 10;

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "HowTo",
        "name" => $howto_data['title'],
        "description" => wp_trim_words(get_the_excerpt($post_id), 30),
        "image" => [
            "@type" => "ImageObject",
            "url" => get_the_post_thumbnail_url($post_id, 'full'),
            "height" => 800,
            "width" => 1200
        ],
        "totalTime" => "PT{$total_minutes}M",
        "estimatedCost" => [
            "@type" => "MonetaryAmount",
            "currency" => "USD",
            "value" => "0"
        ],
        "tool" => [
            [
                "@type" => "HowToTool",
                "name" => "WordPress Admin Panel"
            ]
        ],
        "step" => []
    ];

    $step_counter = 1;
    foreach ($howto_data['steps'] as $step) {
        $schema["step"][] = [
            "@type" => "HowToStep",
            "url" => get_permalink($post_id) . "#step-" . $step_counter,
            "name" => $step['name'],
            "text" => $step['text'],
            "image" => get_the_post_thumbnail_url($post_id, 'detail-image')
        ];
        $step_counter++;
    }

    return WPiGo_Schema::output_json_ld($schema);
}
