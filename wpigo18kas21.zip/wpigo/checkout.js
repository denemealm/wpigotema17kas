jQuery(document).ready(function($) {
    'use strict';

    // Format card number with spaces
    $('#card_number').on('input', function() {
        var value = $(this).val().replace(/\s/g, '');
        var formatted = value.match(/.{1,4}/g);
        $(this).val(formatted ? formatted.join(' ') : '');
    });

    // Format expiry date
    $('#card_expiry').on('input', function() {
        var value = $(this).val().replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        $(this).val(value);
    });

    // Only allow numbers in CVC
    $('#card_cvc').on('input', function() {
        $(this).val($(this).val().replace(/\D/g, ''));
    });

    // Form submission
    $('#wpigo-checkout-form').on('submit', function(e) {
        e.preventDefault();

        var $form = $(this);
        var $submitBtn = $('#wpigo-checkout-submit');
        var $message = $('#wpigo-checkout-message');
        var originalText = $submitBtn.text();

        // Clear previous messages
        $message.html('').removeClass('wpigo-member-message-success wpigo-member-message-error');

        // Basic validation
        var cardNumber = $('#card_number').val().replace(/\s/g, '');
        var cardName = $('#card_name').val().trim();
        var cardExpiry = $('#card_expiry').val();
        var cardCvc = $('#card_cvc').val();

        // Guest billing validation
        var billingEmail = $('#billing_email').val() ? $('#billing_email').val().trim() : '';
        var billingName = $('#billing_name').val() ? $('#billing_name').val().trim() : '';

        // If billing fields exist (guest checkout), validate them
        if ($('#billing_email').length > 0) {
            if (!billingEmail) {
                showMessage('Please enter your email address', 'error');
                return;
            }

            // Basic email validation
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(billingEmail)) {
                showMessage('Please enter a valid email address', 'error');
                return;
            }

            if (!billingName) {
                showMessage('Please enter your full name', 'error');
                return;
            }
        }

        if (!cardName) {
            showMessage('Please enter cardholder name', 'error');
            return;
        }

        if (cardNumber.length < 13 || cardNumber.length > 19) {
            showMessage('Please enter a valid card number', 'error');
            return;
        }

        if (!cardExpiry.match(/^\d{2}\/\d{2}$/)) {
            showMessage('Please enter expiry in MM/YY format', 'error');
            return;
        }

        if (cardCvc.length < 3 || cardCvc.length > 4) {
            showMessage('Please enter a valid CVC', 'error');
            return;
        }

        // Disable submit button
        $submitBtn.prop('disabled', true).text('Processing...');

        // Prepare data
        var formData = {
            action: 'wpigo_create_order',
            nonce: wpigoCheckout.nonce,
            card_number: cardNumber,
            card_name: cardName,
            card_expiry: cardExpiry,
            card_cvc: cardCvc,
            product_ids: []
        };

        // Add guest billing data if exists
        if (billingEmail) {
            formData.billing_email = billingEmail;
            formData.billing_name = billingName;
            formData.create_account = $('#create_account').is(':checked') ? 1 : 0;
        }

        // Get product IDs
        $form.find('input[name="product_ids[]"]').each(function() {
            formData.product_ids.push($(this).val());
        });

        // Send AJAX request
        $.ajax({
            url: wpigoCheckout.ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    showMessage(response.data.message, 'success');

                    // Redirect to order confirmation
                    setTimeout(function() {
                        window.location.href = response.data.redirect_url;
                    }, 1000);
                } else {
                    showMessage(response.data.message || 'Order failed. Please try again.', 'error');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            },
            error: function(xhr, status, error) {
                showMessage('An error occurred. Please try again.', 'error');
                $submitBtn.prop('disabled', false).text(originalText);
                console.error('Checkout error:', error);
            }
        });
    });

    function showMessage(message, type) {
        var $message = $('#wpigo-checkout-message');
        var className = type === 'success' ? 'wpigo-member-message-success' : 'wpigo-member-message-error';

        $message
            .html(message)
            .removeClass('wpigo-member-message-success wpigo-member-message-error')
            .addClass('wpigo-member-message ' + className)
            .fadeIn();

        // Scroll to message
        $('html, body').animate({
            scrollTop: $message.offset().top - 100
        }, 300);
    }
});
