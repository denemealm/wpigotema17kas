<?php
/**
 * Checkout & Order Schema
 *
 * Generates Schema.org markup for checkout and order confirmation pages
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate CheckoutPage Schema
 *
 * @param array $checkout_items Array of checkout items
 * @return string JSON-LD schema markup
 */
function wpigo_schema_checkout($checkout_items = array()) {
    if (empty($checkout_items)) {
        // Try to get from session/cart
        $checkout_items = isset($_SESSION['checkout_items']) ? $_SESSION['checkout_items'] : array();
    }

    $list_items = array();
    foreach ($checkout_items as $index => $item) {
        $list_items[] = [
            "@type" => "ListItem",
            "position" => ($index + 1),
            "item" => [
                "@type" => "Product",
                "name" => $item['title'],
                "url" => get_permalink($item['product_id']),
                "offers" => [
                    "@type" => "Offer",
                    "price" => $item['price'],
                    "priceCurrency" => "USD"
                ]
            ]
        ];
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "CheckoutPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "provider" => [
            "@type" => "Organization",
            "name" => get_bloginfo('name'),
            "url" => home_url('/')
        ],
        "paymentAccepted" => ["Credit Card", "Debit Card"],
        "mainEntity" => [
            "@type" => "ItemList",
            "itemListElement" => $list_items
        ],
        "potentialAction" => [
            "@type" => "ConfirmAction",
            "name" => "Complete Order",
            "target" => [
                "@type" => "EntryPoint",
                "urlTemplate" => get_permalink(),
                "actionPlatform" => [
                    "http://schema.org/DesktopWebPlatform",
                    "http://schema.org/MobileWebPlatform"
                ]
            ]
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate Order Schema
 *
 * @param string $order_number Order number
 * @param int $order_id Order post ID
 * @return string JSON-LD schema markup
 */
function wpigo_schema_order($order_number = '', $order_id = 0) {
    if (empty($order_number) || !$order_id) {
        return '';
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "Order",
        "orderNumber" => $order_number,
        "orderDate" => get_the_date('c', $order_id),
        "orderStatus" => "https://schema.org/OrderDelivered"
    ];

    return WPiGo_Schema::output_json_ld($schema);
}
