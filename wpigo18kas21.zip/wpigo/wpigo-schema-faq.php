<?php
/**
 * FAQPage Schema
 *
 * Generates Schema.org markup for FAQ sections
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate FAQPage Schema for product
 *
 * @param int $post_id Post ID
 * @return string JSON-LD schema markup
 */
function wpigo_schema_faq($post_id) {
    if (!$post_id) {
        return '';
    }

    $faq_data = get_post_meta($post_id, 'product_faq', true);

    if (empty($faq_data)) {
        return '';
    }

    $faq_items = json_decode($faq_data, true);

    if (empty($faq_items)) {
        return '';
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "FAQPage",
        "mainEntity" => []
    ];

    foreach ($faq_items as $item) {
        $schema["mainEntity"][] = [
            "@type" => "Question",
            "name" => $item['question'],
            "acceptedAnswer" => [
                "@type" => "Answer",
                "text" => $item['answer']
            ]
        ];
    }

    return WPiGo_Schema::output_json_ld($schema);
}
