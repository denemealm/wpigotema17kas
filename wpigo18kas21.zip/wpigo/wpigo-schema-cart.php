<?php
/**
 * Shopping Cart Schema
 *
 * Generates Schema.org markup for shopping cart page
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate ShoppingCart Schema
 *
 * @param array $cart_items Array of cart items (product_id => item data)
 * @param float $cart_total Total cart price
 * @return string JSON-LD schema markup
 */
function wpigo_schema_cart($cart_items = array(), $cart_total = 0) {
    if (empty($cart_items)) {
        return '';
    }

    // Build ItemList for cart products
    $list_items = array();
    $position = 1;

    foreach ($cart_items as $product_id => $item) {
        $product = get_post($product_id);
        if (!$product) {
            continue;
        }

        $price = get_post_meta($product_id, 'product_price', true);
        $quantity = isset($item['quantity']) ? intval($item['quantity']) : 1;

        $list_items[] = [
            "@type" => "ListItem",
            "position" => $position,
            "item" => [
                "@type" => "Product",
                "name" => $product->post_title,
                "url" => get_permalink($product_id),
                "offers" => [
                    "@type" => "Offer",
                    "price" => $price,
                    "priceCurrency" => "USD",
                    "availability" => "https://schema.org/InStock"
                ]
            ]
        ];

        $position++;
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "ShoppingCart",
        "name" => "Shopping Cart",
        "url" => get_permalink(),
        "provider" => [
            "@type" => "Organization",
            "name" => get_bloginfo('name'),
            "url" => home_url('/')
        ],
        "mainEntity" => [
            "@type" => "ItemList",
            "numberOfItems" => count($cart_items),
            "itemListElement" => $list_items
        ],
        "totalPrice" => [
            "@type" => "PriceSpecification",
            "price" => number_format($cart_total, 2, '.', ''),
            "priceCurrency" => "USD"
        ],
        "potentialAction" => [
            "@type" => "CheckoutAction",
            "target" => [
                "@type" => "EntryPoint",
                "urlTemplate" => home_url('/checkout/'),
                "actionPlatform" => [
                    "http://schema.org/DesktopWebPlatform",
                    "http://schema.org/MobileWebPlatform"
                ]
            ]
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}
