<?php
/**
 * Detay Sayfasi - Dar Duzen, Bilgi Yogun
 */
?>
<?php get_header(); ?>

    <main class="wpigo-content-container">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="wpigo-page-title-section">
            <h1 class="wpigo-page-title"><?php the_title(); ?></h1>
        </div>
        <?php endwhile; endif; rewind_posts(); ?>

        <?php
        // Sayfa basinda tum meta verilerini tek seferde al
        $post_id = get_the_ID();
        $all_meta = get_post_meta($post_id);

        // Yeni rating fonksiyonunu cagir
        $ratings = wpigo_get_ratings($post_id);

        // Diger meta verilerini all_meta dizisinden al
        $price = isset($all_meta['product_price'][0]) ? floatval($all_meta['product_price'][0]) : 29;
        $version = isset($all_meta['product_version'][0]) ? $all_meta['product_version'][0] : '1.0';
        $sales = isset($all_meta['_product_sales_count'][0]) ? intval($all_meta['_product_sales_count'][0]) : 0;
        $live_demo_url = isset($all_meta['product_live_demo_url'][0]) ? $all_meta['product_live_demo_url'][0] : '';
        $features = isset($all_meta['product_features'][0]) ? $all_meta['product_features'][0] : '';

        // Support & Updates
        $support_period = isset($all_meta['_support_period'][0]) ? $all_meta['_support_period'][0] : '';
        $updates_period = isset($all_meta['_updates_period'][0]) ? $all_meta['_updates_period'][0] : '';
        $update_extension_price = isset($all_meta['_update_extension_price'][0]) ? floatval($all_meta['_update_extension_price'][0]) : 0;
        $response_time = isset($all_meta['_response_time'][0]) ? $all_meta['_response_time'][0] : '';

        // Included Files
        $file_php = isset($all_meta['_files_php'][0]) ? $all_meta['_files_php'][0] : '0';
        $file_css = isset($all_meta['_files_css'][0]) ? $all_meta['_files_css'][0] : '0';
        $file_js = isset($all_meta['_files_js'][0]) ? $all_meta['_files_js'][0] : '0';
        $file_docs = isset($all_meta['_files_docs'][0]) ? $all_meta['_files_docs'][0] : '0';
        $file_sql = isset($all_meta['_files_sql'][0]) ? $all_meta['_files_sql'][0] : '0';
        ?>

        <div class="wpigo-single-layout">

            <div class="wpigo-main-content">

                <?php if (have_posts()) : ?>
                    <?php while (have_posts()) : the_post(); ?>

                        <article <?php post_class(); ?> >

                            <!-- Hidden radio inputs for CSS-only tabs -->
                            <input type="radio" name="product-tab" id="tab-radio-details" class="wpigo-tab-radio" checked>
                            <input type="radio" name="product-tab" id="tab-radio-reviews" class="wpigo-tab-radio">

                            <div class="wpigo-product-tabs">
                                <div class="wpigo-tab-nav">
                                    <label for="tab-radio-details" class="wpigo-tab-btn">
                                        Item Details
                                    </label>
                                    <label for="tab-radio-reviews" class="wpigo-tab-btn">
                                        Reviews & Comments
                                    </label>
                                </div>
                                <div class="wpigo-tab-actions">
                                    <?php
                                    if (!empty($live_demo_url)) :
                                    ?>
                                    <a href="<?php echo esc_url($live_demo_url); ?>" target="_blank" rel="noopener noreferrer" class="wpigo-action-btn wpigo-action-demo">
                                        <span class="wpigo-action-icon">▶️</span>
                                        <span>Live Demo</span>
                                    </a>
                                    <?php endif; ?>
                                    <a href="#" class="wpigo-action-btn wpigo-action-screenshots">
                                        <span class="wpigo-action-icon">🖼️</span>
                                        <span>Screenshots</span>
                                    </a>
                                </div>
                            </div>

                            <!-- Tab Content: Details -->
                            <div class="wpigo-tab-content" id="tab-details">
                                <div class="wpigo-product-image">
                                    <?php
                                    $thumbnail_id = get_post_thumbnail_id();
                                    if ($thumbnail_id) :
                                        // Responsive gorseller - mobil retina icin ara boyut ekle
                                        $image_small = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail');       // 450x300
                                        $image_medium = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail-2x');   // 900x600 (mobil retina)
                                        $image_large = wp_get_attachment_image_src($thumbnail_id, 'detail-image');         // 720x480
                                        $image_xlarge = wp_get_attachment_image_src($thumbnail_id, 'detail-image-2x');     // 1440x960 (desktop retina)

                                        if ($image_large) :
                                            // srcset: 4 boyut ile optimal secim
                                            $srcset_array = array();
                                            if ($image_small) $srcset_array[] = esc_url($image_small[0]) . ' 450w';
                                            if ($image_medium) $srcset_array[] = esc_url($image_medium[0]) . ' 900w';
                                            if ($image_large) $srcset_array[] = esc_url($image_large[0]) . ' 720w';
                                            if ($image_xlarge) $srcset_array[] = esc_url($image_xlarge[0]) . ' 1440w';
                                            $srcset = implode(', ', $srcset_array);
                                    ?>
                                        <img src="<?php echo esc_url($image_large[0]); ?>"
                                             srcset="<?php echo esc_attr($srcset); ?>"
                                             sizes="(max-width: 480px) 450px, (max-width: 768px) 720px, 720px"
                                             width="<?php echo esc_attr($image_large[1]); ?>"
                                             height="<?php echo esc_attr($image_large[2]); ?>"
                                                                                      alt="<?php the_title_attribute(); ?>"
                                                                                      fetchpriority="high">                                    <?php
                                        endif;
                                    else :
                                    ?>
                                        <img src="https://via.placeholder.com/720x480/e8e8e8/999?text=Product"
                                             alt="<?php the_title_attribute(); ?>" width="720" height="480">
                                    <?php endif; ?>
                                </div>

                                <div class="wpigo-product-description">
                                    <?php the_content(); ?>
                                </div>

                                <?php
                                if ($features) :
                                ?>
                                    <div class="wpigo-product-features">
                                        <h2>Features</h2>
                                        <ul>
                                            <?php
                                            $features_array = explode("\n", $features);
                                            foreach ($features_array as $feature) {
                                                if (trim($feature)) {
                                                    echo '<li>' . esc_html(trim($feature)) . '</li>';
                                                }
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <!-- Social Share Buttons -->
                                <div class="wpigo-social-share">
                                    <h2 class="wpigo-social-share-title">Share this product</h2>
                                    <div class="wpigo-social-share-buttons">
                                        <?php
                                        $product_url = urlencode(get_permalink());
                                        $product_title = urlencode(get_the_title());
                                        $product_image = urlencode(get_the_post_thumbnail_url(get_the_ID(), 'full'));
                                        $product_excerpt = urlencode(wp_trim_words(get_the_excerpt(), 20));

                                        $share_links = array(
                                            'facebook' => array(
                                                'url' => 'https://www.facebook.com/sharer/sharer.php?u=' . $product_url,
                                                'label' => 'Facebook',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
                                                'color' => '#1877f2'
                                            ),
                                            'twitter' => array(
                                                'url' => 'https://twitter.com/intent/tweet?url=' . $product_url . '&text=' . $product_title,
                                                'label' => 'Twitter',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
                                                'color' => '#000000'
                                            ),
                                            'linkedin' => array(
                                                'url' => 'https://www.linkedin.com/shareArticle?mini=true&url=' . $product_url . '&title=' . $product_title,
                                                'label' => 'LinkedIn',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
                                                'color' => '#0077b5'
                                            ),
                                            'pinterest' => array(
                                                'url' => 'https://pinterest.com/pin/create/button/?url=' . $product_url . '&media=' . $product_image . '&description=' . $product_title,
                                                'label' => 'Pinterest',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>',
                                                'color' => '#e60023'
                                            ),
                                            'reddit' => array(
                                                'url' => 'https://reddit.com/submit?url=' . $product_url . '&title=' . $product_title,
                                                'label' => 'Reddit',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/></svg>',
                                                'color' => '#ff4500'
                                            ),
                                            'whatsapp' => array(
                                                'url' => 'https://api.whatsapp.com/send?text=' . $product_title . ' ' . $product_url,
                                                'label' => 'WhatsApp',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
                                                'color' => '#25d366'
                                            ),
                                            'telegram' => array(
                                                'url' => 'https://t.me/share/url?url=' . $product_url . '&text=' . $product_title,
                                                'label' => 'Telegram',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',
                                                'color' => '#0088cc'
                                            ),
                                            'email' => array(
                                                'url' => 'mailto:?subject=' . $product_title . '&body=' . $product_excerpt . ' ' . $product_url,
                                                'label' => 'Email',
                                                'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>',
                                                'color' => '#7f7f7f'
                                            ),
                                        );

                                        foreach ($share_links as $network => $data) :
                                        ?>
                                            <a href="<?php echo esc_url($data['url']); ?>"
                                               class="wpigo-share-btn wpigo-share-<?php echo esc_attr($network); ?>"
                                               target="_blank"
                                               rel="noopener noreferrer"
                                               aria-label="Share on <?php echo esc_attr($data['label']); ?>"
                                               data-color="<?php echo esc_attr($data['color']); ?>">
                                                <?php echo $data['icon']; ?>
                                            </a>
                                        <?php endforeach; ?>

                                        <!-- Copy Link Button -->
                                        <button type="button"
                                                class="wpigo-share-btn wpigo-share-copy"
                                                data-url="<?php echo esc_url(get_permalink()); ?>"
                                                aria-label="Copy link"
                                                data-color="#555555">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Tab Content: Reviews & Comments -->
                            <div class="wpigo-tab-content" id="tab-reviews" hidden>
                                <?php
                                $review_count = get_comments_number();
                                ?>

                                <!-- Rating Section -->
                                <div class="wpigo-rating-section">
                                    <div class="wpigo-rating-overview">
                                        <div class="wpigo-overall-rating">
                                            <div class="wpigo-rating-score"><?php echo number_format($ratings['overall'], 1); ?></div>
                                            <div class="wpigo-rating-stars">
                                                <?php echo wpigo_generate_stars($ratings['overall']); ?>
                                            </div>
                                            <div class="wpigo-rating-count"><?php echo $ratings['total_rating_count']; ?> ratings</div>
                                        </div>

                                        <div class="wpigo-rating-categories">
                                            <div class="wpigo-rating-item">
                                                <span class="wpigo-rating-label">Code Quality</span>
                                                <div class="wpigo-rating-bar-container">
                                                    <div class="wpigo-rating-bar" style="width: <?php echo ($ratings['avg_code'] / 5) * 100; ?>%"></div>
                                                </div>
                                                <span class="wpigo-rating-value"><?php echo number_format($ratings['avg_code'], 1); ?></span>
                                            </div>

                                            <div class="wpigo-rating-item">
                                                <span class="wpigo-rating-label">Documentation</span>
                                                <div class="wpigo-rating-bar-container">
                                                    <div class="wpigo-rating-bar" style="width: <?php echo ($ratings['avg_doc'] / 5) * 100; ?>%"></div>
                                                </div>
                                                <span class="wpigo-rating-value"><?php echo number_format($ratings['avg_doc'], 1); ?></span>
                                            </div>

                                            <div class="wpigo-rating-item">
                                                <span class="wpigo-rating-label">Support Quality</span>
                                                <div class="wpigo-rating-bar-container">
                                                    <div class="wpigo-rating-bar" style="width: <?php echo ($ratings['avg_support'] / 5) * 100; ?>%"></div>
                                                </div>
                                                <span class="wpigo-rating-value"><?php echo number_format($ratings['avg_support'], 1); ?></span>
                                            </div>

                                            <div class="wpigo-rating-item">
                                                <span class="wpigo-rating-label">Features</span>
                                                <div class="wpigo-rating-bar-container">
                                                    <div class="wpigo-rating-bar" style="width: <?php echo ($ratings['avg_features'] / 5) * 100; ?>%"></div>
                                                </div>
                                                <span class="wpigo-rating-value"><?php echo number_format($ratings['avg_features'], 1); ?></span>
                                            </div>

                                            <div class="wpigo-rating-item">
                                                <span class="wpigo-rating-label">Design Quality</span>
                                                <div class="wpigo-rating-bar-container">
                                                    <div class="wpigo-rating-bar" style="width: <?php echo ($ratings['avg_design'] / 5) * 100; ?>%"></div>
                                                </div>
                                                <span class="wpigo-rating-value"><?php echo number_format($ratings['avg_design'], 1); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Rate This Product -->
                                    <?php if (is_user_logged_in() && !wpigo_user_has_rated($post_id, get_current_user_id())) : ?>
                                    <div class="wpigo-rating-form">
                                        <h2>Rate This Product</h2>
                                        <form id="wpigo-rating-form" data-post-id="<?php echo $post_id; ?>">
                                            <div class="wpigo-rating-input-group">
                                                <label>Code Quality</label>
                                                <div class="wpigo-star-input" data-rating="0" data-category="code_quality">
                                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                        <span class="wpigo-star" data-value="<?php echo $i; ?>">☆</span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>

                                            <div class="wpigo-rating-input-group">
                                                <label>Documentation</label>
                                                <div class="wpigo-star-input" data-rating="0" data-category="documentation">
                                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                        <span class="wpigo-star" data-value="<?php echo $i; ?>">☆</span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>

                                            <div class="wpigo-rating-input-group">
                                                <label>Support Quality</label>
                                                <div class="wpigo-star-input" data-rating="0" data-category="support">
                                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                        <span class="wpigo-star" data-value="<?php echo $i; ?>">☆</span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>

                                            <div class="wpigo-rating-input-group">
                                                <label>Features</label>
                                                <div class="wpigo-star-input" data-rating="0" data-category="features">
                                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                        <span class="wpigo-star" data-value="<?php echo $i; ?>">☆</span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>

                                            <div class="wpigo-rating-input-group">
                                                <label>Design Quality</label>
                                                <div class="wpigo-star-input" data-rating="0" data-category="design">
                                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                                        <span class="wpigo-star" data-value="<?php echo $i; ?>">☆</span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>

                                            <button type="submit" class="wpigo-btn-submit-rating">Submit Rating</button>
                                            <div class="wpigo-rating-message"></div>
                                        </form>
                                    </div>
                                    <?php elseif (!is_user_logged_in()) : ?>
                                    <div class="wpigo-rating-login-notice">
                                        <p>Please <a href="<?php echo wp_login_url(get_permalink()); ?>">log in</a> to rate this product.</p>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Comments Section -->
                                <div class="wpigo-comments-section">
                                    <h2 class="wpigo-reviews-title">Customer Reviews (<?php echo $review_count; ?>)</h2>
                                    <?php
                                    if (comments_open() || get_comments_number()) :
                                        comments_template();
                                    else :
                                    ?>
                                        <div class="wpigo-no-comments">
                                            <p>No reviews yet. Be the first to review!</p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- FAQ Section (Frontend) -->
                                <?php
                                $faq_data = get_post_meta($post_id, 'product_faq', true);
                                if (!empty($faq_data)) {
                                    $faq_items = json_decode($faq_data, true);
                                    if (!empty($faq_items)) {
                                ?>
                                <style>
                                .wpigo-faq-frontend {
                                    margin-top: 2rem;
                                    border-top: 1px solid var(--wpigo-color-border);
                                    padding-top: 1.5rem;
                                }
                                .wpigo-faq-header {
                                    display: flex;
                                    align-items: center;
                                    gap: 0.75rem;
                                    margin-bottom: 1.5rem;
                                    padding-bottom: 0.75rem;
                                    border-bottom: 2px solid var(--wpigo-color-primary);
                                }
                                .wpigo-faq-header-icon {
                                    width: 2rem;
                                    height: 2rem;
                                    background: linear-gradient(135deg, #10b981, #059669);
                                    border-radius: 0.5rem;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-size: 1.125rem;
                                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                }
                                .wpigo-faq-header h2 {
                                    font-size: 1.25rem;
                                    font-weight: 700;
                                    margin: 0;
                                    color: var(--wpigo-color-heading);
                                    letter-spacing: -0.01em;
                                }
                                .wpigo-faq-list {
                                    display: flex;
                                    flex-direction: column;
                                    gap: 0.875rem;
                                }
                                .wpigo-faq-item {
                                    background: var(--wpigo-color-bg);
                                    border: 1px solid var(--wpigo-color-border);
                                    border-radius: 0.75rem;
                                    overflow: hidden;
                                    transition: all 0.2s ease;
                                    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                                }
                                .wpigo-faq-item:hover {
                                    border-color: #10b981;
                                    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
                                }
                                .wpigo-faq-item[open] {
                                    border-color: #10b981;
                                    box-shadow: 0 4px 12px rgba(16,185,129,0.15);
                                }
                                .wpigo-faq-item summary {
                                    font-weight: 600;
                                    cursor: pointer;
                                    color: var(--wpigo-color-heading);
                                    list-style: none;
                                    display: flex;
                                    justify-content: space-between;
                                    align-items: center;
                                    padding: 0.875rem 1rem;
                                    gap: 1rem;
                                    user-select: none;
                                    transition: background 0.2s ease;
                                }
                                .wpigo-faq-item summary:hover {
                                    background: rgba(16,185,129,0.03);
                                }
                                .wpigo-faq-item summary::-webkit-details-marker {
                                    display: none;
                                }
                                .wpigo-faq-question {
                                    flex: 1;
                                    display: flex;
                                    align-items: center;
                                    gap: 0.5rem;
                                }
                                .wpigo-faq-question::before {
                                    content: 'Q';
                                    display: inline-flex;
                                    align-items: center;
                                    justify-content: center;
                                    width: 1.5rem;
                                    height: 1.5rem;
                                    background: linear-gradient(135deg, #10b981, #059669);
                                    color: white;
                                    border-radius: 0.375rem;
                                    font-size: 0.75rem;
                                    font-weight: 700;
                                    flex-shrink: 0;
                                }
                                .wpigo-faq-icon {
                                    font-size: 0.875rem;
                                    color: #10b981;
                                    transition: transform 0.2s ease;
                                    flex-shrink: 0;
                                }
                                .wpigo-faq-item[open] .wpigo-faq-icon {
                                    transform: rotate(180deg);
                                }
                                .wpigo-faq-answer {
                                    padding: 0 1rem 0.875rem 1rem;
                                    color: var(--wpigo-color-text);
                                    line-height: 1.7;
                                    font-size: 0.9375rem;
                                    border-top: 1px solid var(--wpigo-color-border);
                                    margin-top: 0.5rem;
                                    padding-top: 0.875rem;
                                    animation: fadeIn 0.3s ease;
                                }
                                .wpigo-faq-answer::before {
                                    content: 'A';
                                    display: inline-flex;
                                    align-items: center;
                                    justify-content: center;
                                    width: 1.5rem;
                                    height: 1.5rem;
                                    background: linear-gradient(135deg, #6366f1, #4f46e5);
                                    color: white;
                                    border-radius: 0.375rem;
                                    font-size: 0.75rem;
                                    font-weight: 700;
                                    margin-right: 0.5rem;
                                    float: left;
                                    margin-top: 0.125rem;
                                }
                                @keyframes fadeIn {
                                    from {
                                        opacity: 0;
                                        transform: translateY(-4px);
                                    }
                                    to {
                                        opacity: 1;
                                        transform: translateY(0);
                                    }
                                }
                                @media (max-width: 768px) {
                                    .wpigo-faq-item summary {
                                        padding: 0.75rem 0.875rem;
                                        font-size: 0.9375rem;
                                    }
                                    .wpigo-faq-answer {
                                        padding: 0 0.875rem 0.75rem 0.875rem;
                                        padding-top: 0.75rem;
                                    }
                                }
                                </style>

                                <div class="wpigo-faq-frontend">
                                    <div class="wpigo-faq-header">
                                        <div class="wpigo-faq-header-icon" style="color: white; font-weight: 700;">?</div>
                                        <h2>Frequently Asked Questions</h2>
                                    </div>
                                    <div class="wpigo-faq-list">
                                        <?php foreach ($faq_items as $index => $item) : ?>
                                        <details class="wpigo-faq-item">
                                            <summary>
                                                <span class="wpigo-faq-question"><?php echo esc_html($item['question']); ?></span>
                                                <span class="wpigo-faq-icon">▼</span>
                                            </summary>
                                            <div class="wpigo-faq-answer">
                                                <?php echo nl2br(esc_html($item['answer'])); ?>
                                            </div>
                                        </details>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php
                                    }
                                }
                                ?>

                                <!-- HowTo Section (Frontend) -->
                                <?php
                                $howto_data_raw = get_post_meta($post_id, 'product_howto', true);
                                if (!empty($howto_data_raw)) {
                                    $howto_data = json_decode($howto_data_raw, true);
                                    if (!empty($howto_data) && !empty($howto_data['title']) && !empty($howto_data['steps'])) {
                                ?>
                                <style>
                                .wpigo-howto-frontend {
                                    margin-top: 2rem;
                                    border-top: 1px solid var(--wpigo-color-border);
                                    padding-top: 1.5rem;
                                }
                                .wpigo-howto-header {
                                    display: flex;
                                    align-items: center;
                                    gap: 0.75rem;
                                    margin-bottom: 1.5rem;
                                    padding-bottom: 0.75rem;
                                    border-bottom: 2px solid var(--wpigo-color-primary);
                                }
                                .wpigo-howto-icon {
                                    width: 2rem;
                                    height: 2rem;
                                    background: linear-gradient(135deg, var(--wpigo-color-primary), #0066cc);
                                    border-radius: 0.5rem;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-size: 1.125rem;
                                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                }
                                .wpigo-howto-header h2 {
                                    font-size: 1.25rem;
                                    font-weight: 700;
                                    margin: 0;
                                    color: var(--wpigo-color-heading);
                                    letter-spacing: -0.01em;
                                }
                                .wpigo-howto-steps {
                                    position: relative;
                                    padding-left: 2.5rem;
                                }
                                .wpigo-howto-steps::before {
                                    content: '';
                                    position: absolute;
                                    left: 1.125rem;
                                    top: 0.5rem;
                                    bottom: 0.5rem;
                                    width: 2px;
                                    background: linear-gradient(180deg, var(--wpigo-color-primary) 0%, transparent 100%);
                                    opacity: 0.2;
                                }
                                .wpigo-howto-step {
                                    position: relative;
                                    margin-bottom: 1.25rem;
                                    background: var(--wpigo-color-bg);
                                    border: 1px solid var(--wpigo-color-border);
                                    border-radius: 0.75rem;
                                    padding: 0.625rem;
                                    transition: all 0.2s ease;
                                    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                                }
                                .wpigo-howto-step:hover {
                                    border-color: var(--wpigo-color-primary);
                                    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
                                }
                                .wpigo-howto-step:last-child {
                                    margin-bottom: 0;
                                }
                                .wpigo-step-header {
                                    display: flex;
                                    align-items: flex-start;
                                    gap: 1rem;
                                    margin-bottom: 0.75rem;
                                }
                                .wpigo-step-number {
                                    position: absolute;
                                    left: -2.5rem;
                                    top: 0.625rem;
                                    width: 2.25rem;
                                    height: 2.25rem;
                                    background: linear-gradient(135deg, var(--wpigo-color-primary), #0066cc);
                                    color: white;
                                    border-radius: 50%;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-weight: 700;
                                    font-size: 0.875rem;
                                    box-shadow: 0 2px 8px rgba(0,114,255,0.3);
                                    z-index: 1;
                                    transition: transform 0.2s ease;
                                }
                                .wpigo-howto-step:hover .wpigo-step-number {
                                    transform: scale(1.1);
                                    box-shadow: 0 4px 12px rgba(0,114,255,0.4);
                                }
                                .wpigo-step-title {
                                    font-size: 1rem;
                                    font-weight: 600;
                                    margin: 0 0 0.5rem 0;
                                    color: var(--wpigo-color-heading);
                                    display: flex;
                                    align-items: center;
                                    gap: 0.5rem;
                                }
                                .wpigo-step-title::before {
                                    content: '▸';
                                    color: var(--wpigo-color-primary);
                                    font-size: 0.875rem;
                                    font-weight: bold;
                                }
                                .wpigo-step-description {
                                    color: var(--wpigo-color-text);
                                    line-height: 1.7;
                                    margin: 0;
                                    font-size: 0.9375rem;
                                }
                                @media (max-width: 768px) {
                                    .wpigo-howto-steps {
                                        padding-left: 2rem;
                                    }
                                    .wpigo-step-number {
                                        left: -2rem;
                                        width: 2rem;
                                        height: 2rem;
                                        font-size: 0.75rem;
                                    }
                                    .wpigo-howto-step {
                                        padding: 0.5rem;
                                    }
                                }
                                </style>

                                <div class="wpigo-howto-frontend">
                                    <div class="wpigo-howto-header">
                                        <div class="wpigo-howto-icon">📋</div>
                                        <h2><?php echo esc_html($howto_data['title']); ?></h2>
                                    </div>
                                    <div class="wpigo-howto-steps">
                                        <?php foreach ($howto_data['steps'] as $index => $step) : ?>
                                        <div class="wpigo-howto-step" id="step-<?php echo ($index + 1); ?>">
                                            <div class="wpigo-step-number"><?php echo ($index + 1); ?></div>
                                            <div class="wpigo-step-content">
                                                <h3 class="wpigo-step-title"><?php echo esc_html($step['name']); ?></h3>
                                                <p class="wpigo-step-description"><?php echo nl2br(esc_html($step['text'])); ?></p>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php
                                    }
                                }
                                ?>

                                <!-- Schema.org markup is now automatically generated via WPiGo_Schema class in wp_head -->
                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php endif; ?>

            </div>

            <aside class="wpigo-sidebar">

                <!-- Purchase Card -->
                <div class="wpigo-card wpigo-card-purchase">
                    <div class="wpigo-price">
                        $<?php echo number_format($price, 2); ?>
                    </div>
                    <a href="#" class="wpigo-btn wpigo-btn-cart wpigo-btn-block" data-product-id="<?php echo get_the_ID(); ?>">Add to Cart</a>
                    <a href="#" class="wpigo-btn wpigo-btn-primary wpigo-btn-block wpigo-btn-purchase">Purchase Now</a>
                </div>

                <!-- Product Info Card -->
                <div class="wpigo-card">
                    <h2 class="wpigo-card-title">Product Info</h2>
                    <ul>
                        <li><strong>Published:</strong> <?php echo get_the_date('M j, Y'); ?></li>
                        <li><strong>Updated:</strong> <?php echo get_the_modified_date('M j, Y'); ?></li>
                        <li><strong>Version:</strong> <?php echo $version; ?></li>
                        <li><strong>Sales:</strong> <?php echo $sales; ?></li>
                    </ul>
                </div>

                <!-- Rating Card -->
                <?php if ($ratings['overall'] > 0) : ?>
                <div class="wpigo-card wpigo-card-rating">
                    <h2 class="wpigo-card-title">⭐ Customer Rating</h2>
                    <div class="wpigo-sidebar-rating-compact">
                        <span class="wpigo-sidebar-rating-stars"><?php echo wpigo_generate_stars($ratings['overall']); ?></span>
                        <span class="wpigo-sidebar-rating-score"><?php echo number_format($ratings['overall'], 1); ?></span>
                        <span class="wpigo-sidebar-rating-count">(<?php echo $ratings['total_rating_count']; ?>)</span>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Author Card -->
                <div class="wpigo-card">
                    <h2 class="wpigo-card-title">Author</h2>
                    <p>
                        <strong>
                            <span class="wpigo-author-link">WPigo Team</span>
                        </strong>
                    </p>
                    <p class="wpigo-text-small">We create high-quality, secure, and affordable WordPress plugins. Our support team responds to customer questions within minutes and resolves support tickets as quickly as possible. We're committed to providing excellent products with outstanding customer service to ensure your complete satisfaction.</p>
                </div>

                <!-- Compatibility Card -->
                <?php
                // Get all compatibility data
                // Categorized compatibility labels
                $compat_categories = array(
                    'Core' => array(
                        'wp_64' => 'WordPress 6.4',
                        'wp_65' => 'WordPress 6.5',
                        'wp_66' => 'WordPress 6.6',
                        'wp_67' => 'WordPress 6.7',
                        'wp_68' => 'WordPress 6.8',
                        'php_74' => 'PHP 7.4',
                        'php_80' => 'PHP 8.0',
                        'php_81' => 'PHP 8.1',
                        'php_82' => 'PHP 8.2',
                        'php_83' => 'PHP 8.3',
                        'php_84' => 'PHP 8.4',
                        'mysql_57' => 'MySQL 5.7+',
                        'mysql_80' => 'MySQL 8.0+',
                        'mariadb_103' => 'MariaDB 10.3+',
                        'mariadb_105' => 'MariaDB 10.5+',
                    ),
                    'Hosting & Server' => array(
                        'host_shared' => 'Shared Hosting',
                        'host_vps' => 'VPS',
                        'host_vds' => 'VDS',
                        'host_dedicated' => 'Dedicated Server',
                        'host_cloud' => 'Cloud Hosting',
                        'host_managed' => 'Managed WordPress',
                        'server_apache' => 'Apache',
                        'server_nginx' => 'Nginx',
                        'server_litespeed' => 'LiteSpeed',
                        'server_openlitespeed' => 'OpenLiteSpeed',
                    ),
                    'Browsers' => array(
                        'browser_chrome' => 'Chrome',
                        'browser_firefox' => 'Firefox',
                        'browser_safari' => 'Safari',
                        'browser_edge' => 'Edge',
                        'browser_opera' => 'Opera',
                    ),
                    'Page Builders' => array(
                        'builder_elementor' => 'Elementor',
                        'builder_wpbakery' => 'WPBakery',
                        'builder_divi' => 'Divi',
                        'builder_beaver' => 'Beaver Builder',
                        'builder_oxygen' => 'Oxygen',
                        'builder_bricks' => 'Bricks',
                        'builder_gutenberg' => 'Gutenberg',
                    ),
                    'Popular Plugins' => array(
                        'plugin_woocommerce' => 'WooCommerce',
                        'plugin_edd' => 'Easy Digital Downloads',
                        'plugin_yoast' => 'Yoast SEO',
                        'plugin_rankmath' => 'Rank Math',
                        'plugin_aioseo' => 'All in One SEO',
                        'plugin_cf7' => 'Contact Form 7',
                        'plugin_wpforms' => 'WPForms',
                        'plugin_gravityforms' => 'Gravity Forms',
                        'plugin_acf' => 'ACF',
                        'plugin_polylang' => 'Polylang',
                        'plugin_wpml' => 'WPML',
                    ),
                    'Performance' => array(
                        'perf_wprocket' => 'WP Rocket',
                        'perf_w3cache' => 'W3 Total Cache',
                        'perf_wpsuper' => 'WP Super Cache',
                        'perf_litespeed' => 'LiteSpeed Cache',
                        'perf_cdn' => 'CDN Ready',
                        'perf_redis' => 'Redis',
                        'perf_memcached' => 'Memcached',
                    ),
                    'Security' => array(
                        'sec_wordfence' => 'Wordfence',
                        'sec_ithemes' => 'iThemes Security',
                        'sec_sucuri' => 'Sucuri',
                        'sec_aio' => 'All In One WP Security',
                    ),
                    'WordPress Features' => array(
                        'wp_multisite' => 'Multisite',
                        'wp_childtheme' => 'Child Theme Ready',
                        'wp_translationready' => 'Translation Ready',
                        'wp_rtl' => 'RTL Support',
                        'wp_restapi' => 'REST API',
                        'wp_wpcli' => 'WP-CLI',
                        'wp_coding_standards' => 'Coding Standards',
                        'wp_fse' => 'Full Site Editing',
                    ),
                    'Community' => array(
                        'comm_buddypress' => 'BuddyPress',
                        'comm_bbpress' => 'bbPress',
                        'comm_ultimatemember' => 'Ultimate Member',
                    ),
                    'Standards' => array(
                        'std_ssl' => 'SSL/HTTPS',
                        'std_gdpr' => 'GDPR Compliant',
                        'std_wcag' => 'WCAG 2.1',
                        'std_schema' => 'Schema.org',
                        'std_html5' => 'HTML5',
                        'std_responsive' => 'Mobile Responsive',
                        'std_amp' => 'AMP Ready',
                    ),
                );

                $has_compat = false;
                $total_compat_count = 0; // Use a different variable name to avoid conflict
                foreach ($compat_categories as $category => $items) {
                    foreach ($items as $key => $label) {
                        if (isset($all_meta['_compat_' . $key][0]) && $all_meta['_compat_' . $key][0] === '1') {
                            $has_compat = true;
                            $total_compat_count++;
                        }
                    }
                }

                if ($has_compat) :
                ?>
                <div class="wpigo-card">
                    <h2 class="wpigo-card-title">✅ Compatibility</h2>
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php
                        $category_index = 0;
                        foreach ($compat_categories as $category_name => $category_items) :
                            $category_has_items = false;
                            $category_output = '';

                            foreach ($category_items as $key => $label) {
                                if (isset($all_meta['_compat_' . $key][0]) && $all_meta['_compat_' . $key][0] === '1') {
                                    $category_has_items = true;
                                    $category_output .= '<li style="margin: 3px 0;">🟢 ' . esc_html($label) . '</li>';
                                }
                            }

                            if ($category_has_items) :
                                if ($category_index > 0) :
                        ?>
                                    <div style="border-top: 1px solid #ddd; margin: 12px 0;"></div>
                        <?php
                                endif;
                        ?>
                                <div style="margin-bottom: 10px;">
                                    <p style="font-weight: 600; font-size: 11px; color: #666; margin: 0 0 5px; text-transform: uppercase; letter-spacing: 0.5px;"><?php echo esc_html($category_name); ?></p>
                                    <ul class="wpigo-compat-list" style="margin: 0; padding-left: 0;">
                                        <?php echo $category_output; ?>
                                    </ul>
                                </div>
                        <?php
                                $category_index++;
                            endif;
                        endforeach;
                        ?>
                    </div>
                    <div style="border-top: 2px solid #e0e0e0; margin-top: 12px; padding-top: 8px;">
                        <p style="font-size: 11px; color: #666; margin: 0; font-style: italic; text-align: center;">
                            <?php echo $total_compat_count . ' compatible ' . ($total_compat_count == 1 ? 'technology' : 'technologies'); ?>
                        </p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Support & Updates Card -->
                <?php
                if ($support_period || $updates_period || $response_time) :
                ?>
                <div class="wpigo-card">
                    <h2 class="wpigo-card-title">🛠️ Support & Maintenance</h2>
                    <ul>
                        <?php if ($support_period) : ?>
                            <li>
                                <strong>Free Support:</strong> <?php echo esc_html($support_period); ?> <?php echo $support_period == 1 ? 'month' : 'months'; ?>
                            </li>
                        <?php endif; ?>

                        <?php if ($updates_period) : ?>
                            <li>
                                <strong>Updates:</strong>
                                <?php
                                if ($updates_period === 'lifetime') {
                                    echo 'Lifetime';
                                } else {
                                    echo esc_html($updates_period) . ' ' . ($updates_period == 1 ? 'year' : 'years');
                                }
                                ?>
                            </li>
                        <?php endif; ?>

                        <?php if ($updates_period !== 'lifetime' && $update_extension_price > 0) : ?>
                            <li>
                                <strong>Update Extension:</strong> $<?php echo number_format($update_extension_price, 2); ?>
                            </li>
                        <?php endif; ?>

                        <?php if ($response_time) : ?>
                            <li>
                                <strong>Response Time:</strong> &lt; <?php echo esc_html($response_time); ?> hours
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Included Files Card -->
                <?php
                if ($file_php === '1' || $file_css === '1' || $file_js === '1' || $file_docs === '1' || $file_sql === '1') :
                ?>
                <div class="wpigo-card">
                    <h2 class="wpigo-card-title">📁 Included Files</h2>
                    <ul class="wpigo-files-list">
                        <?php if ($file_php === '1') : ?><li>- PHP Files</li><?php endif; ?>
                        <?php if ($file_css === '1') : ?><li>- CSS/SCSS</li><?php endif; ?>
                        <?php if ($file_js === '1') : ?><li>- JavaScript/jQuery</li><?php endif; ?>
                        <?php if ($file_docs === '1') : ?><li>- Documentation (PDF)</li><?php endif; ?>
                        <?php if ($file_sql === '1') : ?><li>- SQL Installation File</li><?php endif; ?>
                    </ul>
                </div>
                <?php endif; ?>

            </aside>

        </div>

    </main>

<!-- Screenshot Modal - Always available -->
<div id="wpigo-screenshot-modal" class="wpigo-screenshot-modal">
    <div class="wpigo-screenshot-modal-overlay"></div>
    <div class="wpigo-screenshot-modal-content">
        <button class="wpigo-screenshot-close">&times;</button>
        <button class="wpigo-screenshot-prev">&#10094;</button>
        <button class="wpigo-screenshot-next">&#10095;</button>

        <div class="wpigo-screenshot-image-wrapper">
            <img id="wpigo-screenshot-image" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" alt="">
        </div>

        <div class="wpigo-screenshot-counter">
            <span id="wpigo-screenshot-current">1</span> / <span id="wpigo-screenshot-total">1</span>
        </div>
    </div>
</div>

<?php
// Screenshot Data - Fallback to featured image if no screenshots
$screenshot_ids = isset($all_meta['_screenshot_gallery'][0]) ? unserialize($all_meta['_screenshot_gallery'][0]) : array();
$screenshot_urls = array();

if (!empty($screenshot_ids) && is_array($screenshot_ids)) {
    // Screenshots var, bunlari kullan
    foreach ($screenshot_ids as $screenshot_id) {
        $image_url = wp_get_attachment_image_src($screenshot_id, 'full');
        if ($image_url) {
            $screenshot_urls[] = esc_url($image_url[0]);
        }
    }
}

    // Eger screenshot yoksa, one cikan gorseli kullan
    if (empty($screenshot_urls)) {
    $thumbnail_id = get_post_thumbnail_id();
    if ($thumbnail_id) {
        // En buyuk boyutu kullan (detail-image-2x veya orijinal)
        $featured_image = wp_get_attachment_image_src($thumbnail_id, 'detail-image-2x');
        if (!$featured_image) {
            $featured_image = wp_get_attachment_image_src($thumbnail_id, 'full');
        }
        if ($featured_image) {
            $screenshot_urls[] = esc_url($featured_image[0]);
        }
    }
}
?>
<script type="text/javascript">
var wpigoScreenshots = <?php echo json_encode($screenshot_urls); ?>;
</script>




<?php get_footer(); ?>
