/**
 * WPiGo Product Page Functionality
 * Combines: Ratings, Screenshots Gallery, Social Share
 */

jQuery(document).ready(function($) {
    'use strict';

    // ==============================================
    // TAB CONTROL - HASH BASED NAVIGATION
    // ==============================================

    // Function to switch to reviews tab
    function switchToReviewsTab() {
        $('#tab-radio-reviews').prop('checked', true);
    }

    // Check URL hash on page load
    if (window.location.hash) {
        const hash = window.location.hash;
        // If hash is #respond or starts with #comment, switch to reviews tab
        if (hash === '#respond' || hash.startsWith('#comment')) {
            switchToReviewsTab();
            // Scroll to the hash element after a small delay
            setTimeout(function() {
                const element = document.querySelector(hash);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 100);
        }
    }

    // ==============================================
    // RATING SYSTEM
    // ==============================================

    // Star input hover effect
    $('.wpigo-star-input').each(function() {
        const $container = $(this);
        const $stars = $container.find('.wpigo-star');

        $stars.on('mouseenter', function() {
            const value = $(this).data('value');
            $stars.each(function(index) {
                if (index < value) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        });

        $container.on('mouseleave', function() {
            const currentRating = parseInt($container.attr('data-rating')) || 0;
            $stars.each(function(index) {
                if (index < currentRating) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        });

        $stars.on('click', function() {
            const value = $(this).data('value');
            $container.attr('data-rating', value);

            $stars.each(function(index) {
                if (index < value) {
                    $(this).addClass('active').text('★');
                } else {
                    $(this).removeClass('active').text('☆');
                }
            });
        });
    });

    // Rating form submission
    $('#wpigo-rating-form').on('submit', function(e) {
        e.preventDefault();

        const $form = $(this);
        const $button = $form.find('.wpigo-btn-submit-rating');
        const $message = $form.find('.wpigo-rating-message');
        const postId = $form.data('post-id');

        // Get all ratings
        const ratings = {};
        let allRated = true;

        $form.find('.wpigo-star-input').each(function() {
            const category = $(this).data('category');
            const rating = parseInt($(this).attr('data-rating')) || 0;

            if (rating === 0) {
                allRated = false;
            }

            ratings[category] = rating;
        });

        // Validate
        if (!allRated) {
            $message.removeClass('success').addClass('error').text('Please rate all categories').show();
            return;
        }

        // Disable button
        $button.prop('disabled', true).text('Submitting...');
        $message.hide();

        // Submit via AJAX
        $.ajax({
            url: wpigoRatings.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_submit_rating',
                nonce: wpigoRatings.nonce,
                post_id: postId,
                code_quality: ratings.code_quality,
                documentation: ratings.documentation,
                support: ratings.support,
                features: ratings.features,
                design: ratings.design
            },
            success: function(response) {
                if (response.success) {
                    $message.removeClass('error').addClass('success').text(response.data.message).show();

                    // Hide the entire rating form (including h2 title)
                    setTimeout(function() {
                        $form.closest('.wpigo-rating-form').fadeOut(300, function() {
                            $(this).remove();
                            $('.wpigo-rating-section').append(
                                '<div class="wpigo-rating-thank-you" style="text-align: center; padding: 1rem; background: #d4edda; border-radius: 0.25rem; color: #155724; margin-top: 0.5rem;">' +
                                '<strong>Thank you for rating!</strong> Your ratings have been recorded.' +
                                '</div>'
                            );
                        });
                    }, 1500);
                } else {
                    $message.removeClass('success').addClass('error').text(response.data.message).show();
                    $button.prop('disabled', false).text('Submit Rating');
                }
            },
            error: function() {
                $message.removeClass('success').addClass('error').text('An error occurred. Please try again.').show();
                $button.prop('disabled', false).text('Submit Rating');
            }
        });
    });

    // ==============================================
    // SCREENSHOT GALLERY MODAL
    // ==============================================

    // wpigoScreenshots PHP tarafindan tanimlanıyor (fallback dahil)
    var wpigoScreenshotsArray = (typeof wpigoScreenshots !== 'undefined') ? wpigoScreenshots : [];

    var currentIndex = 0;
    var $modal = $('#wpigo-screenshot-modal');
    var $image = $('#wpigo-screenshot-image');
    var $currentCounter = $('#wpigo-screenshot-current');
    var $totalCounter = $('#wpigo-screenshot-total');
    var totalScreenshots = wpigoScreenshotsArray.length;

    function openModal(index) {
        currentIndex = index || 0;
        updateScreenshot();
        $modal.addClass('active');
        $('body').css('overflow', 'hidden');
    }

    function closeModal() {
        $modal.removeClass('active');
        $('body').css('overflow', '');
    }

    function nextScreenshot() {
        if (totalScreenshots <= 1) return;
        currentIndex = (currentIndex + 1) % totalScreenshots;
        updateScreenshot();
    }

    function prevScreenshot() {
        if (totalScreenshots <= 1) return;
        currentIndex = (currentIndex - 1 + totalScreenshots) % totalScreenshots;
        updateScreenshot();
    }

    function updateScreenshot() {
        $image.attr('src', wpigoScreenshotsArray[currentIndex]);
        $currentCounter.text(currentIndex + 1);
        $totalCounter.text(totalScreenshots);
    }

    // Screenshot button click - Always works
    $('.wpigo-action-screenshots').on('click', function(e) {
        e.preventDefault();

        if (totalScreenshots === 0) {
            alert('No image available for this product.');
            return;
        }

        openModal(0);
    });

    // Close button
    $('.wpigo-screenshot-close').on('click', function(e) {
        e.preventDefault();
        closeModal();
    });

    // Overlay click to close
    $('.wpigo-screenshot-modal-overlay').on('click', function() {
        closeModal();
    });

    // Next button
    $('.wpigo-screenshot-next').on('click', function(e) {
        e.preventDefault();
        nextScreenshot();
    });

    // Previous button
    $('.wpigo-screenshot-prev').on('click', function(e) {
        e.preventDefault();
        prevScreenshot();
    });

    // Keyboard navigation
    $(document).on('keydown', function(e) {
        if (!$modal.hasClass('active')) {
            return;
        }

        switch(e.keyCode) {
            case 27:
                closeModal();
                break;
            case 37:
                prevScreenshot();
                break;
            case 39:
                nextScreenshot();
                break;
        }
    });

    // Prevent modal content clicks from closing
    $('.wpigo-screenshot-modal-content').on('click', function(e) {
        e.stopPropagation();
    });

    // Preload images
    if (totalScreenshots > 0) {
        wpigoScreenshotsArray.forEach(function(url) {
            var img = new Image();
            img.src = url;
        });
    }

    // ==============================================
    // SOCIAL SHARE - COPY LINK
    // ==============================================

    const copyButtons = document.querySelectorAll('.wpigo-share-copy');

    copyButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const url = this.getAttribute('data-url');

            // Try Clipboard API first
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(function() {
                    showCopyFeedback(button, 'Copied!');
                }).catch(function() {
                    fallbackCopy(url, button);
                });
            } else {
                fallbackCopy(url, button);
            }
        });
    });

    // Fallback copy method for older browsers
    function fallbackCopy(text, button) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();

        try {
            document.execCommand('copy');
            showCopyFeedback(button, 'Copied!');
        } catch (err) {
            showCopyFeedback(button, 'Failed');
        }

        document.body.removeChild(textarea);
    }

    // Show feedback when link is copied
    function showCopyFeedback(button, message) {
        const originalLabel = button.querySelector('.wpigo-share-label').textContent;

        button.querySelector('.wpigo-share-label').textContent = message;
        button.classList.add('wpigo-share-copied');

        setTimeout(function() {
            button.querySelector('.wpigo-share-label').textContent = originalLabel;
            button.classList.remove('wpigo-share-copied');
        }, 2000);
    }

    // ==============================================
    // AJAX COMMENT SUBMISSION
    // ==============================================

    // Intercept comment form submission
    $(document).on('submit', '#commentform', function(e) {
        e.preventDefault();

        const $form = $(this);
        const $submitButton = $form.find('#submit');
        const originalButtonText = $submitButton.val();

        // Check if rating is required and selected
        const $ratingInputs = $form.find('input[name="rating"]');
        if ($ratingInputs.length > 0) {
            const isRatingSelected = $ratingInputs.is(':checked');
            if (!isRatingSelected) {
                alert('Please select a rating before submitting your review.');
                return false;
            }
        }

        // Disable submit button
        $submitButton.prop('disabled', true).val('Submitting...');

        // Prepare form data
        const formData = $form.serialize();

        // Submit via AJAX
        $.ajax({
            url: $form.attr('action') || window.location.href,
            type: 'POST',
            data: formData,
            success: function(response) {
                // Parse response if it's a full HTML page
                const $response = $(response);

                // Check if comment was successful
                // WordPress usually redirects to the comment after success
                // or shows an error message

                // Look for error messages
                const errorText = $response.find('.comment-error, .error').text();

                if (errorText) {
                    // Show error
                    alert(errorText || 'Error submitting comment. Please try again.');
                    $submitButton.prop('disabled', false).val(originalButtonText);
                } else {
                    // Success! Reload comments section

                    // Show success message
                    $form.before('<div class="wpigo-comment-success" style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 0.25rem; margin-bottom: 1rem;"><strong>Success!</strong> Your review has been submitted and is awaiting moderation.</div>');

                    // Clear form
                    $form[0].reset();

                    // Reset rating stars if present
                    const $ratingStars = $form.find('.comment-form-rating-stars');
                    if ($ratingStars.length > 0) {
                        $ratingStars.find('label').removeClass('filled');
                        $ratingStars.find('input[type="radio"]').prop('checked', false);
                    }

                    // Re-enable button
                    $submitButton.prop('disabled', false).val(originalButtonText);

                    // Remove success message after 5 seconds
                    setTimeout(function() {
                        $('.wpigo-comment-success').fadeOut(300, function() {
                            $(this).remove();
                        });
                    }, 5000);

                    // Optionally reload the page to show the new comment
                    // Uncomment the line below if you want to reload
                    // setTimeout(function() { window.location.reload(); }, 2000);
                }
            },
            error: function(xhr, status, error) {
                alert('An error occurred while submitting your review. Please try again.');
                $submitButton.prop('disabled', false).val(originalButtonText);
            }
        });

        return false;
    });
});