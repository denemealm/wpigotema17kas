<?php
/**
 * WPiGo Schema Manager
 *
 * Central manager for all Schema.org structured data
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WPiGo_Schema {

    /**
     * Initialize schema system
     */
    public static function init() {
        // Load all schema modules
        self::load_schema_modules();

        // Hook into wp_head for automatic schema output
        add_action('wp_head', array(__CLASS__, 'output_schemas'), 5);
    }

    /**
     * Load all schema module files
     */
    private static function load_schema_modules() {
        $schema_files = array(
            'wpigo-schema-product.php',
            'wpigo-schema-faq.php',
            'wpigo-schema-howto.php',
            'wpigo-schema-organization.php',
            'wpigo-schema-checkout.php',
            'wpigo-schema-cart.php',
            'wpigo-schema-page.php'
        );

        foreach ($schema_files as $file) {
            $filepath = get_template_directory() . '/' . $file;
            if (file_exists($filepath)) {
                require_once $filepath;
            }
        }
    }

    /**
     * Output schemas based on current page context
     */
    public static function output_schemas() {
        // Organization and WebSite schemas (all pages)
        if (function_exists('wpigo_schema_organization')) {
            echo wpigo_schema_organization();
        }

        if (function_exists('wpigo_schema_website')) {
            echo wpigo_schema_website();
        }

        // Single product page
        if (is_single()) {
            global $post;

            // Product schema
            if (function_exists('wpigo_schema_product')) {
                echo wpigo_schema_product($post->ID);
            }

            // FAQ schema
            if (function_exists('wpigo_schema_faq')) {
                echo wpigo_schema_faq($post->ID);
            }

            // HowTo schema
            if (function_exists('wpigo_schema_howto')) {
                echo wpigo_schema_howto($post->ID);
            }
        }

        // Note: Homepage/Archive CollectionPage schema is output manually in index.php
        // because it needs to collect items during the loop

        // Note: Checkout schema is output manually in template-checkout.php
        // because it needs checkout_items data from the template

        // Note: Order schema is output manually in template-order-confirmation.php
        // because it needs order_number and order_id data from the template

        // Note: Cart schema is output manually in cart.php
        // because it needs cart_items and cart_total data from the template

        // Contact page
        if (is_page_template('page-contact.php') && function_exists('wpigo_schema_contact_page')) {
            echo wpigo_schema_contact_page();
        }

        // Sitemap page
        if (is_page_template('template-sitemap.php') && function_exists('wpigo_schema_sitemap_page')) {
            echo wpigo_schema_sitemap_page();
        }

        // Regular page
        if (is_page() && !is_page_template() && function_exists('wpigo_schema_webpage')) {
            echo wpigo_schema_webpage();
        }
    }

    /**
     * Helper: Output schema JSON-LD
     */
    public static function output_json_ld($schema_array) {
        if (empty($schema_array)) {
            return '';
        }

        return '<script type="application/ld+json">' .
               json_encode($schema_array, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) .
               '</script>' . "\n";
    }
}

// Initialize on theme setup
add_action('after_setup_theme', array('WPiGo_Schema', 'init'));
