<?php
/**
 * Ana Sayfa - Kompakt 3 Sütun Grid
 */
?>
<?php get_header(); ?>

<div class="content-wrapper">

    <main class="wpigo-content-container">

        <?php if (is_category()) : ?>
            <div class="wpigo-page-header">
                <h1 class="wpigo-page-title"><?php single_cat_title(); ?></h1>
            </div>
        <?php elseif (is_home()) : ?>
            <div class="wpigo-page-header">
                <h1 class="wpigo-page-title">
                    <?php
                    $homepage_title = get_theme_mod('wpigo_homepage_title', 'Featured Products');
                    echo esc_html($homepage_title);
                    if (is_paged()) {
                        echo ' <span class="wpigo-page-number">Page ' . get_query_var('paged') . '</span>';
                    }
                    ?>
                </h1>
                <?php
                $homepage_subtitle = get_theme_mod('wpigo_homepage_subtitle', '');
                if ($homepage_subtitle) :
                ?>
                    <p class="wpigo-page-subtitle"><?php echo esc_html($homepage_subtitle); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="wpigo-products-grid">

            <?php if (have_posts()) : ?>

                <?php
                // Array to hold schema data, collected during the main loop
                $schema_items = [];
                $item_index = 1;
                $post_counter = 0; // Counter for image loading optimization
                ?>

                <?php while (have_posts()) : the_post(); ?>
                    <?php $post_counter++; ?>
                    <?php
                    // Get all meta for the post in one go (from cache, thanks to our function)
                    $post_meta = get_post_meta(get_the_ID());
                    $sales = $post_meta['_product_sales_count'][0] ?? 0;
                    $price = $post_meta['product_price'][0] ?? '29';

                    // Get image metadata for ImageObject schema
                    $thumbnail_id = get_post_thumbnail_id(get_the_ID());
                    $image_full = wp_get_attachment_image_src($thumbnail_id, 'full');
                    $image_thumb = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail');
                    $image_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);

                    // Collect data for ItemList Schema (only on the first page)
                    if (!is_paged()) {
                        $product_item = [
                            "@type" => "Product",
                            "name" => get_the_title(),
                            "url" => get_permalink(),
                            "image" => [
                                "@type" => "ImageObject",
                                "url" => $image_full[0],
                                "width" => $image_full[1],
                                "height" => $image_full[2],
                                "caption" => !empty($image_alt) ? $image_alt : get_the_title(),
                                "thumbnailUrl" => $image_thumb[0],
                                "creator" => [
                                    "@type" => "Organization",
                                    "name" => get_bloginfo('name')
                                ],
                                "copyrightHolder" => [
                                    "@type" => "Organization",
                                    "name" => get_bloginfo('name')
                                ],
                                "license" => home_url('/license/'),
                                "acquireLicensePage" => home_url('/license/')
                            ],
                            "description" => esc_js(wp_trim_words(get_the_excerpt(), 25)),
                            "sku" => "WP-" . get_the_ID(),
                            "mpn" => "WPIGO-" . get_the_ID(),
                            "brand" => [
                                "@type" => "Brand",
                                "name" => "WPiGo"
                            ],
                            "offers" => [
                                "@type" => "Offer",
                                "url" => get_permalink(),
                                "priceCurrency" => "USD",
                                "price" => esc_attr($price),
                                "priceValidUntil" => date('Y-12-31'),
                                "availability" => "https://schema.org/InStock",
                                "itemCondition" => "https://schema.org/NewCondition",
                                "shippingDetails" => [
                                    "@type" => "OfferShippingDetails",
                                    "shippingRate" => [
                                        "@type" => "MonetaryAmount",
                                        "value" => "0",
                                        "currency" => "USD"
                                    ],
                                    "deliveryTime" => [
                                        "@type" => "ShippingDeliveryTime",
                                        "handlingTime" => [
                                            "@type" => "QuantitativeValue",
                                            "minValue" => 0,
                                            "maxValue" => 0,
                                            "unitCode" => "DAY"
                                        ],
                                        "transitTime" => [
                                            "@type" => "QuantitativeValue",
                                            "minValue" => 0,
                                            "maxValue" => 0,
                                            "unitCode" => "DAY"
                                        ]
                                    ],
                                    "shippingDestination" => [
                                        "@type" => "DefinedRegion",
                                        "addressCountry" => "US"
                                    ]
                                ],
                                "hasMerchantReturnPolicy" => [
                                    "@type" => "MerchantReturnPolicy",
                                    "applicableCountry" => "US",
                                    "returnPolicyCategory" => "https://schema.org/MerchantReturnFiniteReturnWindow",
                                    "merchantReturnDays" => 30,
                                    "merchantReturnLink" => "https://wpigo.com/refund-policy/",
                                    "returnMethod" => "https://schema.org/ReturnByMail",
                                    "returnFees" => "https://schema.org/FreeReturn"
                                ],
                                "seller" => [
                                    "@type" => "Organization",
                                    "name" => get_bloginfo('name'),
                                    "url" => home_url('/')
                                ]
                            ]
                        ];

                        // Add aggregateRating if product has ratings
                        $ratings = wpigo_get_ratings(get_the_ID());
                        if ($ratings['overall'] > 0 && $ratings['total_rating_count'] > 0) {
                            $product_item['aggregateRating'] = [
                                "@type" => "AggregateRating",
                                "ratingValue" => number_format($ratings['overall'], 1),
                                "reviewCount" => intval($ratings['total_rating_count']),
                                "ratingCount" => intval($ratings['total_rating_count'])
                            ];
                        }

                        $schema_items[] = [
                            "@type" => "ListItem",
                            "position" => $item_index++,
                            "item" => $product_item
                        ];
                    }
                    ?>
                    <article class="wpigo-product-card">
                        <a href="<?php the_permalink(); ?>" aria-label="View product: <?php the_title_attribute(); ?>">

                            <div class="wpigo-product-thumbnail">
                                <?php
                                $thumbnail_id = get_post_thumbnail_id();
                                if ($thumbnail_id) :
                                    $image_1x = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail');
                                    $image_2x = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail-2x');

                                    if ($image_1x) :
                                        $srcset = esc_url($image_1x[0]) . ' 450w';
                                        if ($image_2x) {
                                            $srcset .= ', ' . esc_url($image_2x[0]) . ' 900w';
                                        }

                                        // LCP Optimization: First 3 images should load eagerly
                                        $loading_attr = ($post_counter <= 3) ? '' : ' loading="lazy"';
                                        $fetchpriority_attr = ($post_counter <= 3) ? ' fetchpriority="high"' : '';
                                ?>
                                    <img src="<?php echo esc_url($image_1x[0]); ?>"
                                         srcset="<?php echo $srcset; ?>"
                                         sizes="(max-width: 768px) 50vw, 400px"
                                         width="<?php echo esc_attr($image_1x[1]); ?>"
                                         height="<?php echo esc_attr($image_1x[2]); ?>"
                                         alt="<?php the_title_attribute(); ?>"<?php echo $fetchpriority_attr . $loading_attr; ?>>
                                <?php
                                    endif;
                                else :
                                ?>
                                    <img src="https://via.placeholder.com/450x300/e8e8e8/999?text=No+Image"
                                         alt="<?php the_title_attribute(); ?>" width="450" height="300">
                                <?php endif; ?>
                            </div>

                            <div class="wpigo-product-info">
                                <h2 class="wpigo-product-info-title"><?php the_title(); ?></h2>

                                <div class="wpigo-product-meta">
                                    <div class="wpigo-product-author-sales">
                                        <span class="wpigo-product-author">
                                            by <?php echo get_the_author(); ?>
                                        </span>
                                        <span class="wpigo-product-sales">
                                            • <?php echo $sales; ?> sales
                                        </span>
                                    </div>
                                    <span class="wpigo-product-price">
                                        $<?php echo esc_html($price); ?>
                                    </span>
                                </div>
                            </div>

                        </a>
                    </article>

                <?php endwhile; ?>

                <div class="wpigo-pagination">
                    <?php
                    the_posts_pagination(array(
                        'screen_reader_text' => 'Products navigation',
                        'aria_label' => 'Product pagination',
                        'mid_size'  => 1,
                        'prev_text' => '<span aria-hidden="true">‹</span><span class="screen-reader-text">Previous page</span>',
                        'next_text' => '<span class="screen-reader-text">Next page</span><span aria-hidden="true">›</span>',
                    ));
                    ?>
                </div>

            <?php else : ?>

                <div class="wpigo-no-products">
                    <p>No products yet</p>
                </div>

            <?php endif; ?>

        </div>

        <?php if (is_category() && category_description()) : ?>
            <div class="wpigo-category-description">
                <div class="wpigo-category-description-inner">
                    <h2 class="wpigo-category-description-title">
                        About <?php single_cat_title(); ?>
                    </h2>
                    <div class="wpigo-category-description-content">
                        <?php echo category_description(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </main>

</div>

<?php
// Output CollectionPage schema if we collected any items
if (!empty($schema_items) && function_exists('wpigo_schema_collection_page')) {
    echo wpigo_schema_collection_page($schema_items);
}
?>

<?php get_footer(); ?>