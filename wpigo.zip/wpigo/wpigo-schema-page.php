<?php
/**
 * Page Schemas
 *
 * Generates Schema.org markup for various page types
 * Includes WebPage, ContactPage, CollectionPage
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate WebPage Schema (regular pages and single posts)
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_webpage() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "WebPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "dateModified" => get_the_modified_date('c'),
        "datePublished" => get_the_date('c'),
        "inLanguage" => get_bloginfo('language'),
        "isFamilyFriendly" => true
    ];

    // Add relatedLink for single posts (category hierarchy + tags)
    if (is_single()) {
        $related_links = [];

        // Homepage
        $related_links[] = home_url('/');

        // Category hierarchy (parent to child)
        $categories = get_the_category();
        if (!empty($categories)) {
            $cat = $categories[0]; // Primary category

            // Get ancestor categories (top to bottom)
            $ancestors = get_ancestors($cat->term_id, 'category');
            $ancestors = array_reverse($ancestors); // Top to bottom

            foreach ($ancestors as $ancestor_id) {
                $related_links[] = get_category_link($ancestor_id);
            }

            // Current category
            $related_links[] = get_category_link($cat->term_id);
        }

        // Primary tag (if exists)
        $tags = get_the_tags();
        if (!empty($tags)) {
            $related_links[] = get_tag_link($tags[0]->term_id);
        }

        // Remove duplicates and add to schema
        $related_links = array_unique($related_links);
        if (!empty($related_links)) {
            $schema["relatedLink"] = $related_links;
        }
    }

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate ContactPage Schema
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_contact_page() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "ContactPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => "Contact WPiGo for support, sales inquiries, or other questions.",
        "mainEntity" => [
            "@type" => "ContactPoint",
            "contactType" => "Customer Service",
            "telephone" => "+905369379337",
            "email" => "contact@wpigo.com",
            "areaServed" => "TR",
            "availableLanguage" => "en"
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate AboutPage Schema
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_about_page() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "AboutPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => get_the_excerpt() ?: "Learn more about WPiGo, your trusted marketplace for premium WordPress plugins, themes, and digital products.",
        "dateModified" => get_the_modified_date('c'),
        "datePublished" => get_the_date('c'),
        "inLanguage" => get_bloginfo('language'),
        "mainEntity" => [
            "@type" => "Organization",
            "name" => get_bloginfo('name'),
            "url" => home_url('/')
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate FAQPage Schema for general site FAQ page
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_faq_page() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "FAQPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => get_the_excerpt() ?: "Frequently asked questions about WPiGo marketplace, purchasing, licensing, and support.",
        "dateModified" => get_the_modified_date('c'),
        "datePublished" => get_the_date('c'),
        "inLanguage" => get_bloginfo('language')
    ];

    // Add FAQ questions from post meta
    $faq_questions = get_post_meta(get_the_ID(), 'faq_question', true);
    $faq_answers = get_post_meta(get_the_ID(), 'faq_answer', true);

    if (!empty($faq_questions) && is_array($faq_questions) && !empty($faq_answers) && is_array($faq_answers)) {
        $main_entity = [];

        foreach ($faq_questions as $index => $question) {
            if (!empty($question) && !empty($faq_answers[$index])) {
                $main_entity[] = [
                    "@type" => "Question",
                    "name" => $question,
                    "acceptedAnswer" => [
                        "@type" => "Answer",
                        "text" => $faq_answers[$index]
                    ]
                ];
            }
        }

        if (!empty($main_entity)) {
            $schema["mainEntity"] = $main_entity;
        }
    }

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate CollectionPage Schema for sitemap
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_sitemap_page() {
    $sitemap_description = "Complete sitemap of all WordPress plugins, themes, and resources available on WPiGo.";

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "CollectionPage",
        "name" => get_the_title(),
        "url" => get_permalink(),
        "description" => $sitemap_description,
        "dateModified" => get_the_modified_date('c'),
        "inLanguage" => get_bloginfo('language')
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate CollectionPage Schema for homepage/archive with product list
 *
 * @param array $schema_items Array of product ListItem schemas
 * @return string JSON-LD schema markup
 */
function wpigo_schema_collection_page($schema_items = array()) {
    if (empty($schema_items)) {
        return '';
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "CollectionPage",
        "name" => is_category() ? single_cat_title('', false) : get_bloginfo('name'),
        "description" => is_category() ? strip_tags(category_description()) : get_bloginfo('description'),
        "url" => is_category() ? get_category_link(get_query_var('cat')) : home_url(),
        "mainEntity" => [
            "@type" => "ItemList",
            "itemListElement" => $schema_items
        ]
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate BreadcrumbList Schema for category pages
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_breadcrumb() {
    if (!is_category()) {
        return '';
    }

    $current_cat = get_queried_object();
    if (!$current_cat) {
        return '';
    }

    $breadcrumb_items = [];
    $position = 1;

    // Always start with homepage
    $breadcrumb_items[] = [
        "@type" => "ListItem",
        "position" => $position++,
        "name" => "Home",
        "item" => home_url('/')
    ];

    // Get parent categories (if any) in hierarchical order
    $ancestors = get_ancestors($current_cat->term_id, 'category');
    $ancestors = array_reverse($ancestors); // Top to bottom

    foreach ($ancestors as $ancestor_id) {
        $ancestor = get_category($ancestor_id);
        $breadcrumb_items[] = [
            "@type" => "ListItem",
            "position" => $position++,
            "name" => $ancestor->name,
            "item" => get_category_link($ancestor_id)
        ];
    }

    // Add current category (last item)
    $breadcrumb_items[] = [
        "@type" => "ListItem",
        "position" => $position,
        "name" => $current_cat->name,
        "item" => get_category_link($current_cat->term_id)
    ];

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "BreadcrumbList",
        "itemListElement" => $breadcrumb_items
    ];

    return WPiGo_Schema::output_json_ld($schema);
}
