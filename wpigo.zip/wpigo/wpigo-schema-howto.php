<?php
/**
 * HowTo Schema
 *
 * Generates Schema.org markup for HowTo guides
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate HowTo Schema for product
 *
 * @param int $post_id Post ID
 * @return string JSON-LD schema markup
 */
function wpigo_schema_howto($post_id) {
    if (!$post_id) {
        return '';
    }

    $howto_data_raw = get_post_meta($post_id, 'product_howto', true);

    if (empty($howto_data_raw)) {
        return '';
    }

    $howto_data = json_decode($howto_data_raw, true);

    // CRITICAL: Do NOT output HowTo schema if data is incomplete or empty
    // This prevents empty/incomplete schema from appearing in source code
    if (empty($howto_data) ||
        !isset($howto_data['title']) ||
        trim($howto_data['title']) === '' ||
        !isset($howto_data['steps']) ||
        !is_array($howto_data['steps']) ||
        count($howto_data['steps']) === 0) {
        return ''; // No schema output at all
    }

    // Calculate estimated time (10 minutes per step)
    $step_count = count($howto_data['steps']);
    $total_minutes = $step_count * 10;

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "HowTo",
        "name" => $howto_data['title'],

        // Use HowTo-specific description with priority fallback - NO LIMITS
        "description" => (function() use ($post_id, $howto_data) {
            // Priority 1: HowTo-specific description (from HowTo meta box)
            $howto_desc = !empty($howto_data['description']) ? $howto_data['description'] : '';
            if (!empty($howto_desc)) {
                return strip_tags($howto_desc);
            }

            // Priority 2: SEO description (product_description)
            $product_desc = get_post_meta($post_id, 'product_description', true);
            if (!empty($product_desc)) {
                return strip_tags($product_desc);
            }

            // Priority 3: Excerpt (final fallback)
            return get_the_excerpt($post_id);
        })(),

        "image" => [
            "@type" => "ImageObject",
            "url" => get_the_post_thumbnail_url($post_id, 'full'),
            "height" => 800,
            "width" => 1200
        ],
        "totalTime" => "PT{$total_minutes}M",
        "estimatedCost" => [
            "@type" => "MonetaryAmount",
            "currency" => "USD",
            "value" => "0"
        ],
        "tool" => [
            [
                "@type" => "HowToTool",
                "name" => "WordPress Admin Panel"
            ]
        ],
        "step" => []
    ];

    $step_counter = 1;
    foreach ($howto_data['steps'] as $step) {
        // Clean newlines and extra spaces for schema (NO LIMIT on text length)
        $step_text = str_replace(["\r\n", "\n", "\r", 'rn'], ' ', $step['text']);
        $step_text = preg_replace('/\s+/', ' ', $step_text); // Remove extra spaces
        $step_text = trim($step_text);

        $schema["step"][] = [
            "@type" => "HowToStep",
            "url" => get_permalink($post_id) . "#step-" . $step_counter,
            "name" => $step['name'],
            "text" => $step_text,
            "image" => get_the_post_thumbnail_url($post_id, 'detail-image')
        ];
        $step_counter++;
    }

    return WPiGo_Schema::output_json_ld($schema);
}
