<?php
/**
 * Tema Functions
 */

// Load Schema Manager
require_once get_template_directory() . '/class-wpigo-schema.php';

function marketplace_theme_scripts() {
    wp_enqueue_style('marketplace-style', get_stylesheet_uri(), array(), time());

    // Enqueue product.js on single post pages (ratings, screenshots, social-share)
    if (is_single()) {
        wp_enqueue_script('wpigo-product', get_template_directory_uri() . '/js/product.js', array('jquery'), time(), true);

        // Localize script for AJAX
        wp_localize_script('wpigo-product', 'wpigoRatings', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpigo_rating_nonce')
        ));
    }

    // Enqueue contact form script only on the contact page
    if (is_page_template('page-contact.php')) {
        wp_enqueue_script('wpigo-contact-form', get_template_directory_uri() . '/js/contact-form.js', array(), time(), true);

        // Localize script to pass PHP variables
        wp_localize_script('wpigo-contact-form', 'wpigoContact', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpigo_contact_nonce')
        ));
    }
}
add_action('wp_enqueue_scripts', 'marketplace_theme_scripts');

function marketplace_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption'));
    add_theme_support('automatic-feed-links');

    // Custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array('wpigo-site-title'),
    ));

    // Retina-ready görsel boyutları - Her boyut için 1x ve 2x versiyonu (3:2 oran)

    // Checkout & Cart (küçk görseller - retina ready)
    add_image_size('checkout-thumb', 120, 80, false);      // Checkout: 80-120px alan (1x)
    add_image_size('checkout-thumb-2x', 240, 160, false);  // Checkout: 80-120px alan (2x retina)
    add_image_size('cart-thumb', 180, 120, false);         // Cart: 80-120px alan (1x)
    add_image_size('cart-thumb-2x', 360, 240, false);      // Cart: 80-120px alan (2x retina)

    // Ana sayfa ürün kartları (retina ready)
    add_image_size('grid-thumbnail', 450, 300, false);     // Ana sayfa: ~400px alan (1x)
    add_image_size('grid-thumbnail-2x', 900, 600, false);  // Ana sayfa: ~400px alan (2x retina)

    // Ürün detay sayfası (retina ready)
    add_image_size('detail-image', 720, 480, false);       // Ürün detay: 720px alan (1x)
    add_image_size('detail-image-2x', 1440, 960, false);   // Ürün detay: 720px alan (2x retina)

    // Menü desteği
    register_nav_menus(array(
        'primary' => 'Primary Menu',
        'footer-menu-1' => 'Footer Menu 1',
        'footer-menu-2' => 'Footer Menu 2',
    ));
}
add_action('after_setup_theme', 'marketplace_theme_setup');

// ============================================ 
// GÖRSEL OPTİMİZASYONU
// ============================================ 

// WordPress varsayılan görsel boyutlarını kapat (disk tasarrufu iin)
add_filter('intermediate_image_sizes_advanced', function($sizes) {
    unset($sizes['thumbnail']);      // 150x150 WordPress varsayılan
    unset($sizes['medium']);         // 300x300 WordPress varsayılan
    unset($sizes['medium_large']);   // 768px WordPress varsayılan
    unset($sizes['large']);          // 1024px WordPress varsayılan
    return $sizes;
});

// Yüklenen görselin max boyutunu 1440x960 ile sınırla (retina 2x için)
add_filter('big_image_size_threshold', function($threshold) {
    return 1440; // Max genişlik 1440px (retina iin gerekli)
});

// Helper function - Kesin thumbnail URL al
function wpigo_get_thumbnail_url($post_id, $size) {
    $thumbnail_id = get_post_thumbnail_id($post_id);
    if (!$thumbnail_id) {
        return '';
    }

    $image_data = wp_get_attachment_image_src($thumbnail_id, $size);
    if (!$image_data) {
        return '';
    }

    return $image_data[0];
}

// REGENERATE GÖRSELLERİ - Mevcut görseller için yeni boyutları oluştur





// ============================================ 
// FOOTER WIDGET AREAS
// ============================================ 

function wpigo_register_footer_widgets() {
    register_sidebar(array(
        'name'          => 'Footer Column 1',
        'id'            => 'footer-1',
        'description'   => 'First footer column - appears on left',
        'before_widget' => '<div id="%1$s" class="wpigo-footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="wpigo-footer-widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => 'Footer Column 2',
        'id'            => 'footer-2',
        'description'   => 'Second footer column - appears in center',
        'before_widget' => '<div id="%1$s" class="wpigo-footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="wpigo-footer-widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'wpigo_register_footer_widgets');

// ============================================ 
// FOOTER CUSTOMIZER SETTINGS
// ============================================ 

function wpigo_footer_customizer($wp_customize) {
    // Footer Section
    $wp_customize->add_section('wpigo_footer_settings', array(
        'title'    => 'Footer Settings',
        'priority' => 120,
    ));

    // Site Description
    $wp_customize->add_setting('wpigo_footer_description', array(
        'default'           => 'Your trusted marketplace for premium WordPress themes, plugins, and digital products.',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_footer_description', array(
        'label'       => 'Footer Description',
        'section'     => 'wpigo_footer_settings',
        'type'        => 'textarea',
        'description' => 'Brief description shown in footer',
    ));

    // Social Media Links
    $social_networks = array(
        'facebook'  => 'Facebook URL',
        'twitter'   => 'Twitter (X) URL',
        'instagram' => 'Instagram URL',
        'linkedin'  => 'LinkedIn URL',
        'youtube'   => 'YouTube URL',
        'github'    => 'GitHub URL',
    );

    foreach ($social_networks as $network => $label) {
        $wp_customize->add_setting('wpigo_social_' . $network, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'transport'         => 'refresh',
        ));

        $wp_customize->add_control('wpigo_social_' . $network, array(
            'label'       => $label,
            'section'     => 'wpigo_footer_settings',
            'type'        => 'url',
            'description' => 'Enter full URL (e.g., https://facebook.com/yourpage)',
        ));
    }

    // Contact Information - Address
    $wp_customize->add_setting('wpigo_footer_address', array(
        'default'           => 'Your Location',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_footer_address', array(
        'label'       => 'Footer Address',
        'section'     => 'wpigo_footer_settings',
        'type'        => 'text',
    ));

    // Contact Information - Phone
    $wp_customize->add_setting('wpigo_footer_phone', array(
        'default'           => '+1 234 567 890',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_footer_phone', array(
        'label'       => 'Footer Phone',
        'section'     => 'wpigo_footer_settings',
        'type'        => 'text',
    ));

    // Contact Information - Email
    $wp_customize->add_setting('wpigo_footer_email', array(
        'default'           => 'info@wpigo.com',
        'sanitize_callback' => 'sanitize_email',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_footer_email', array(
        'label'       => 'Footer Email',
        'section'     => 'wpigo_footer_settings',
        'type'        => 'email',
    ));

    // Copyright Text
    $wp_customize->add_setting('wpigo_copyright_text', array(
        'default'           => ' ' . date('Y') . ' WPiGo. All rights reserved.',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_copyright_text', array(
        'label'       => 'Copyright Text',
        'section'     => 'wpigo_footer_settings',
        'type'        => 'text',
        'description' => 'Copyright text in footer bottom',
    ));
}
add_action('customize_register', 'wpigo_footer_customizer');

// ============================================
// HOMEPAGE CUSTOMIZER SETTINGS
// ============================================

function wpigo_homepage_customizer($wp_customize) {
    // Homepage Section
    $wp_customize->add_section('wpigo_homepage_settings', array(
        'title'    => 'Homepage Settings',
        'priority' => 30,
    ));

    // Homepage Title
    $wp_customize->add_setting('wpigo_homepage_title', array(
        'default'           => 'Featured Products',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_homepage_title', array(
        'label'       => 'Homepage Title',
        'section'     => 'wpigo_homepage_settings',
        'type'        => 'text',
        'description' => 'Main heading shown on homepage',
    ));

    // Homepage Subtitle (optional)
    $wp_customize->add_setting('wpigo_homepage_subtitle', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_homepage_subtitle', array(
        'label'       => 'Homepage Subtitle',
        'section'     => 'wpigo_homepage_settings',
        'type'        => 'text',
        'description' => 'Optional subtitle below main heading',
    ));
}
add_action('customize_register', 'wpigo_homepage_customizer');

// ============================================
// SOCIAL MEDIA CUSTOMIZER SETTINGS
// ============================================

function wpigo_social_customizer($wp_customize) {
    // Social Media Section
    $wp_customize->add_section('wpigo_social_settings', array(
        'title'    => 'Social Media & SEO',
        'priority' => 35,
    ));

    // Facebook App ID
    $wp_customize->add_setting('wpigo_fb_app_id', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('wpigo_fb_app_id', array(
        'label'       => 'Facebook App ID',
        'section'     => 'wpigo_social_settings',
        'type'        => 'text',
        'description' => 'Optional: Your Facebook App ID for better sharing analytics',
    ));
}
add_action('customize_register', 'wpigo_social_customizer');

// ============================================ 
// CLASSIC EDITOR (Disable Gutenberg)
// ============================================ 

// Gutenberg block editor'ı devre dışı bırak
add_filter('use_block_editor_for_post', '__return_false', 10);

// Gutenberg CSS'lerini kaldır
function wpigo_remove_gutenberg_css() {
    wp_dequeue_style('wp-block-library');
    wp_deregister_style('wp-block-library');

    wp_dequeue_style('wp-block-library-theme');
    wp_deregister_style('wp-block-library-theme');

    wp_dequeue_style('wc-blocks-style');
    wp_deregister_style('wc-blocks-style');

    wp_dequeue_style('global-styles');
    wp_deregister_style('global-styles');
}
add_action('wp_enqueue_scripts', 'wpigo_remove_gutenberg_css', 100);

// Admin'de de Gutenberg CSS'lerini kaldır
add_action('admin_enqueue_scripts', 'wpigo_remove_gutenberg_css', 100);

// 10. YORUM RSS FEED'LERNİ KALDIR
add_filter('feed_links_show_comments_feed', '__return_false');

// 11. GUTENBERG CLASSIC THEME STYLES'I KALDIR (Classic Editor kullanıyorsanız)
function wpigo_remove_classic_theme_styles() {
    wp_dequeue_style('classic-theme-styles');
    wp_deregister_style('classic-theme-styles');
}
add_action('wp_enqueue_scripts', 'wpigo_remove_classic_theme_styles', 20);

// 12. JSON REST API LİNKİN KALDIR
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'wp_oembed_add_discovery_links');

// 13. RSD (XML-RPC) LİNKİNİ KALDIR
remove_action('wp_head', 'rsd_link');

// 14. XML-RPC'Yİ TAMAMEN KAPAT (Güvenlik)
add_filter('xmlrpc_enabled', '__return_false');

// 15. SHORTLINK'İ KALDIR
remove_action('wp_head', 'wp_shortlink_wp_head');

// 16. WLW MANIFEST LİNKNİ KALDIR (Windows Live Writer - eski)
remove_action('wp_head', 'wlwmanifest_link');



// ============================================ 
// SITEMAP VISIBILITY CONTROL
// ============================================ 

// Add meta box to pages and posts for sitemap visibility
function wpigo_add_sitemap_meta_box() {
    // Add to pages
    add_meta_box(
        'wpigo_sitemap_visibility',
        'Sitemap Settings',
        'wpigo_sitemap_meta_box_callback',
        'page',
        'side',
        'default'
    );

    // Add to posts (blog)
    add_meta_box(
        'wpigo_sitemap_visibility',
        'Sitemap Settings',
        'wpigo_sitemap_meta_box_callback',
        'post',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'wpigo_add_sitemap_meta_box');

// Meta box callback function
function wpigo_sitemap_meta_box_callback($post) {
    wp_nonce_field('wpigo_save_sitemap_meta', 'wpigo_sitemap_meta_nonce');
    $exclude_from_sitemap = get_post_meta($post->ID, '_exclude_from_sitemap', true);
    ?>
    <p>
        <label>
            <input type="checkbox" name="exclude_from_sitemap" value="1" <?php checked($exclude_from_sitemap, '1'); ?> />
            <?php _e('Hide this page from sitemap', 'wpigo'); ?>
        </label>
    </p>
    <p class="description">
        <?php _e('If checked, this page will not appear in the sitemap.', 'wpigo'); ?>
    </p>
    <?php
}

// Save meta box data
function wpigo_save_sitemap_meta($post_id) {
    // Check nonce
    if (!isset($_POST['wpigo_sitemap_meta_nonce']) || !wp_verify_nonce($_POST['wpigo_sitemap_meta_nonce'], 'wpigo_save_sitemap_meta')) {
        return;
    }

    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Checkbox: Varsa 1, yoksa 0
    update_post_meta($post_id, '_exclude_from_sitemap', isset($_POST['exclude_from_sitemap']) && $_POST['exclude_from_sitemap'] == '1' ? '1' : '0');
}
add_action('save_post_page', 'wpigo_save_sitemap_meta');
add_action('save_post_post', 'wpigo_save_sitemap_meta');

// ============================================ 
// SMTP EMAIL SETTINGS (Gmail)
// ============================================ 

// Add SMTP settings page to admin menu
function wpigo_smtp_settings_menu() {
    add_options_page(
        'SMTP Email Settings',
        'SMTP Settings',
        'manage_options',
        'wpigo-smtp-settings',
        'wpigo_smtp_settings_page'
    );
}
add_action('admin_menu', 'wpigo_smtp_settings_menu');

// SMTP settings page
function wpigo_smtp_settings_page() {
    // Check user permissions
    if (!current_user_can('manage_options')) {
        return;
    }

    // Save settings
    if (isset($_POST['wpigo_smtp_submit'])) {
        check_admin_referer('wpigo_smtp_settings_save');

        update_option('wpigo_smtp_host', sanitize_text_field($_POST['wpigo_smtp_host']));
        update_option('wpigo_smtp_port', intval($_POST['wpigo_smtp_port']));
        update_option('wpigo_smtp_username', sanitize_email($_POST['wpigo_smtp_username']));
        update_option('wpigo_smtp_from_name', sanitize_text_field($_POST['wpigo_smtp_from_name']));
        update_option('wpigo_smtp_enabled', isset($_POST['wpigo_smtp_enabled']) ? '1' : '0');

        // Only update password if provided
        if (!empty($_POST['wpigo_smtp_password'])) {
            update_option('wpigo_smtp_password', base64_encode($_POST['wpigo_smtp_password']));
        }

        echo '<div class="notice notice-success"><p>SMTP settings saved successfully!</p></div>';
    }

    // Send test email
    if (isset($_POST['wpigo_smtp_test'])) {
        check_admin_referer('wpigo_smtp_test_email');
        $test_email = sanitize_email($_POST['test_email_address']);

        $subject = 'WPiGo SMTP Test Email';
        $message = 'This is a test email from WPiGo SMTP settings. If you receive this, your SMTP configuration is working correctly!';

        if (wp_mail($test_email, $subject, $message)) {
            echo '<div class="notice notice-success"><p>Test email sent successfully to ' . esc_html($test_email) . '!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Failed to send test email. Please check your settings.</p></div>';
        }
    }

    // Get current settings
    $smtp_host = get_option('wpigo_smtp_host', 'smtp.gmail.com');
    $smtp_port = get_option('wpigo_smtp_port', 587);
    $smtp_username = get_option('wpigo_smtp_username', '');
    $smtp_from_name = get_option('wpigo_smtp_from_name', 'WPiGo');
    $smtp_enabled = get_option('wpigo_smtp_enabled', '0');
    $smtp_password_exists = get_option('wpigo_smtp_password') ? true : false;

    ?>
    <div class="wrap">
        <h1>SMTP Email Settings</h1>
        <p>Configure Gmail SMTP settings for sending emails from WordPress.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpigo_smtp_settings_save'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_enabled">Enable SMTP</label>
                    </th>
                    <td>
                        <input type="checkbox" name="wpigo_smtp_enabled" id="wpigo_smtp_enabled" value="1" <?php checked($smtp_enabled, '1'); ?> />
                        <p class="description">Enable custom SMTP for sending emails</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_host">SMTP Host</label>
                    </th>
                    <td>
                        <input type="text" name="wpigo_smtp_host" id="wpigo_smtp_host" value="<?php echo esc_attr($smtp_host); ?>" class="regular-text">
                        <p class="description">Gmail: smtp.gmail.com</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_port">SMTP Port</label>
                    </th>
                    <td>
                        <input type="number" name="wpigo_smtp_port" id="wpigo_smtp_port" value="<?php echo esc_attr($smtp_port); ?>" class="small-text">
                        <p class="description">Gmail: 587 (TLS) or 465 (SSL)</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_username">Gmail Address</label>
                    </th>
                    <td>
                        <input type="email" name="wpigo_smtp_username" id="wpigo_smtp_username" value="<?php echo esc_attr($smtp_username); ?>" class="regular-text" required>
                        <p class="description">Your Gmail address (e.g., yourname@gmail.com)</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_password">App Password</label>
                    </th>
                    <td>
                        <input type="password" name="wpigo_smtp_password" id="wpigo_smtp_password" value="" class="regular-text" placeholder="<?php echo $smtp_password_exists ? '••••••••••••' : 'Enter app password'; ?>">
                        <p class="description">
                            <strong>Gmail App Password</strong> (not your regular password)<br>
                            Generate at: <a href="https://myaccount.google.com/apppasswords" target="_blank">https://myaccount.google.com/apppasswords</a><br>
                            <?php if ($smtp_password_exists) echo '<span style="color: green;">✓ Password is set. Leave blank to keep current password.</span>'; ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpigo_smtp_from_name">From Name</label>
                    </th>
                    <td>
                        <input type="text" name="wpigo_smtp_from_name" id="wpigo_smtp_from_name" value="<?php echo esc_attr($smtp_from_name); ?>" class="regular-text">
                        <p class="description">Name that appears in "From" field (e.g., WPiGo)</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpigo_smtp_submit" id="submit" class="button button-primary" value="Save Settings">
            </p>
        </form>

        <hr>

        <h2>Send Test Email</h2>
        <form method="post" action="">
            <?php wp_nonce_field('wpigo_smtp_test_email'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="test_email_address">Test Email Address</label>
                    </th>
                    <td>
                        <input type="email" name="test_email_address" id="test_email_address" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text" required>
                        <p class="description">Enter email address to send test email</p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="wpigo_smtp_test" class="button button-secondary" value="Send Test Email">
            </p>
        </form>

        <hr>

        <h3>Setup Instructions for Gmail:</h3>
        <ol>
            <li>Go to your Google Account: <a href="https://myaccount.google.com/" target="_blank">https://myaccount.google.com/</a></li>
            <li>Click <strong>Security</strong> in the left sidebar</li>
            <li>Enable <strong>2-Step Verification</strong> if not already enabled</li>
            <li>Go to <strong>App Passwords</strong>: <a href="https://myaccount.google.com/apppasswords" target="_blank">https://myaccount.google.com/apppasswords</a></li>
            <li>Select app: <strong>Mail</strong></li>
            <li>Select device: <strong>Other (Custom name)</strong>  Enter "WordPress" or "WPiGo"</li>
            <li>Click <strong>Generate</strong></li>
            <li>Copy the 16-character app password (without spaces)</li>
            <li>Paste it in the "App Password" field above</li>
            <li>Save settings and send a test email</li>
        </ol>

        <h3>Troubleshooting:</h3>
        <ul>
            <li><strong>Authentication failed:</strong> Double-check your Gmail address and app password</li>
            <li><strong>Connection failed:</strong> Verify SMTP host (smtp.gmail.com) and port (587)</li>
            <li><strong>2-Step Verification required:</strong> Enable it in your Google Account security settings</li>
            <li><strong>App Passwords not available:</strong> Make sure 2-Step Verification is enabled first</li>
        </ul>
    </div>
    <?php
}

// Configure PHPMailer to use SMTP
function wpigo_phpmailer_smtp($phpmailer) {
    // Check if SMTP is enabled
    if (get_option('wpigo_smtp_enabled') !== '1') {
        return;
    }

    // Get SMTP settings
    $smtp_host = get_option('wpigo_smtp_host', 'smtp.gmail.com');
    $smtp_port = get_option('wpigo_smtp_port', 587);
    $smtp_username = get_option('wpigo_smtp_username', '');
    $smtp_password = get_option('wpigo_smtp_password', '');
    $smtp_from_name = get_option('wpigo_smtp_from_name', 'WPiGo');

    // Decode password
    if ($smtp_password) {
        $smtp_password = base64_decode($smtp_password);
    }

    // Configure PHPMailer
    $phpmailer->isSMTP();
    $phpmailer->Host = $smtp_host;
    $phpmailer->SMTPAuth = true;
    $phpmailer->Port = $smtp_port;
    $phpmailer->Username = $smtp_username;
    $phpmailer->Password = $smtp_password;
    $phpmailer->SMTPSecure = ($smtp_port == 465) ? 'ssl' : 'tls';
    $phpmailer->From = $smtp_username;
    $phpmailer->FromName = $smtp_from_name;
}
add_action('phpmailer_init', 'wpigo_phpmailer_smtp');

// ============================================ 
// MAINTENANCE MODE
// ============================================ 

/**
 * Maintenance mode functionality
 */
function wpigo_maintenance_mode() {
    // Check if maintenance mode is enabled
    $maintenance_enabled = get_option('wpigo_maintenance_mode', false);

    // Allow logged-in admins to bypass
    if ($maintenance_enabled && !current_user_can('manage_options')) {
        wp_die(
            '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; max-width: 600px; margin: 100px auto; text-align: center; padding: 40px;">
                <h1 style="font-size: 48px; margin-bottom: 10px;">🔧</h1>
                <h2 style="font-size: 28px; color: #333; margin-bottom: 10px;">Site Under Maintenance</h2>
                <p style="font-size: 16px; color: #666; line-height: 1.6;">We are currently performing scheduled maintenance.<br>Please check back soon.</p>
                <p style="font-size: 14px; color: #999; margin-top: 30px;">— WPiGo Team</p>
            </div>',
            'Site Under Maintenance',
            array('response' => 503)
        );
    }
}
add_action('template_redirect', 'wpigo_maintenance_mode');

/**
 * Add maintenance mode toggle to admin menu
 */
function wpigo_maintenance_menu() {
    add_menu_page(
        'Maintenance Mode',
        'Maintenance',
        'manage_options',
        'wpigo-maintenance',
        'wpigo_maintenance_page',
        'dashicons-admin-tools',
        100
    );
}
add_action('admin_menu', 'wpigo_maintenance_menu');

/**
 * Maintenance mode settings page
 */
function wpigo_maintenance_page() {
    // Handle form submission
    if (isset($_POST['wpigo_maintenance_submit'])) {
        check_admin_referer('wpigo_maintenance_action', 'wpigo_maintenance_nonce');

        $enabled = isset($_POST['wpigo_maintenance_enabled']) ? true : false;
        update_option('wpigo_maintenance_mode', $enabled);

        echo '<div class="notice notice-success"><p><strong>Settings saved!</strong></p></div>';
    }

    $maintenance_enabled = get_option('wpigo_maintenance_mode', false);
    ?>
    <div class="wrap">
        <h1> Maintenance Mode</h1>
        <p>Enable maintenance mode to temporarily hide content from visitors. Administrators will still have full access.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpigo_maintenance_action', 'wpigo_maintenance_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">Maintenance Mode</th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpigo_maintenance_enabled" value="1" <?php checked($maintenance_enabled, true); ?> />
                            <strong>Enable Maintenance Mode</strong>
                        </label>
                        <p class="description">
                            When enabled, visitors will see a maintenance page. Only administrators can access the site.
                        </p>
                    </td>
                </tr>
            </table>

            <?php if ($maintenance_enabled) : ?>
            <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
                <strong>⚠️ Maintenance mode is currently ACTIVE</strong><br>
                Regular visitors cannot access the site. Only you (as an administrator) can see the content.
            </div>
            <?php endif; ?>

            <p class="submit">
                <input type="submit" name="wpigo_maintenance_submit" class="button button-primary" value="Save Settings">
            </p>
        </form>

        <hr style="margin: 40px 0;">

        <h2>Quick Test</h2>
        <p>Open your site in a private/incognito browser window to see the maintenance page (make sure you're not logged in).</p>
    </div>
    <?php
}

/**
 * Add maintenance mode indicator to admin bar
 */
function wpigo_maintenance_admin_bar($wp_admin_bar) {
    if (!current_user_can('manage_options')) {
        return;
    }

    $maintenance_enabled = get_option('wpigo_maintenance_mode', false);

    if ($maintenance_enabled) {
        $wp_admin_bar->add_node(array(
            'id'    => 'wpigo-maintenance-notice',
            'title' => '<span style="color: #ff9800;">🔧 Maintenance Mode Active</span>',
            'href'  => admin_url('admin.php?page=wpigo-maintenance'),
            'meta'  => array(
                'title' => 'Click to manage maintenance mode'
            )
        ));
    }
}
add_action('admin_bar_menu', 'wpigo_maintenance_admin_bar', 100);

// ============================================ 
// BOT BLOCKING
// ============================================ 

/**
 * Block web archive and SEO crawler bots
 */
function wpigo_block_unwanted_bots() {
    // Only run on frontend
    if (is_admin()) {
        return;
    }

    // Get user agent
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';

    // List of blocked bots
    $blocked_bots = array(
        // Archive bots
        'archive.org_bot',
        'ia_archiver',
        'waybackmachine',
        'archiveis',
        'archive.is',
        'archive-it',
        'webcitation',
        'memorybot',
        'archivebot',

        // SEO/Analytics crawlers
        'semrush',
        'semrushbot',
        'ahrefs',
        'ahrefsbot',
        'mj12bot',
        'dotbot',
        'blexbot',
        'serpstat',
        'petalbot',
        'dataforseo',
        'screaming frog',
        'siteauditbot',
        'seokicks',
        'spbot',
        'linkpadbot',

        // Other scraper bots
        'scrapy',
        'wget',
        'curl',
        'python-requests',
        'go-http-client',
    );

    // Check if current user agent contains any blocked bot string
    foreach ($blocked_bots as $bot) {
        if (strpos($user_agent, $bot) !== false) {
            // Send 403 Forbidden
            header('HTTP/1.1 403 Forbidden');
            exit('Access Denied');
        }
    }
}
add_action('init', 'wpigo_block_unwanted_bots', 1);

// Meta boxes
function marketplace_add_product_meta_boxes() {
    add_meta_box('product_details', 'Product Details', 'marketplace_product_meta_box_callback', 'post', 'normal', 'high');
    add_meta_box('product_ratings', 'Initial Ratings', 'marketplace_product_ratings_meta_box_callback', 'post', 'normal', 'high');
    add_meta_box('product_compatibility', 'Compatibility', 'marketplace_product_compatibility_meta_box_callback', 'post', 'side', 'default');
    add_meta_box('product_support', 'Support & Updates', 'marketplace_product_support_meta_box_callback', 'post', 'side', 'default');
    add_meta_box('product_files', 'Included Files', 'marketplace_product_files_meta_box_callback', 'post', 'side', 'default');
}
add_action('add_meta_boxes', 'marketplace_add_product_meta_boxes');

function marketplace_product_meta_box_callback($post) {
    wp_nonce_field('marketplace_save_product_meta', 'marketplace_product_meta_nonce');
    $price = get_post_meta($post->ID, 'product_price', true);
    $version = get_post_meta($post->ID, 'product_version', true);
    $product_slug = get_post_meta($post->ID, '_product_slug', true);
    $live_demo_url = get_post_meta($post->ID, 'product_live_demo_url', true);
    $features = get_post_meta($post->ID, 'product_features', true);
    $sales_count = get_post_meta($post->ID, '_product_sales_count', true);
    ?>
    <p>
        <label><strong>Price (USD):</strong></label><br>
        <input type="number" name="product_price" value="<?php echo esc_attr($price); ?>" step="0.01" style="width: 200px;">
    </p>
    <p>
        <label><strong>Version:</strong></label><br>
        <input type="text" name="product_version" value="<?php echo esc_attr($version); ?>" placeholder="1.0" style="width: 200px;">
    </p>
    <p style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 15px 0;">
        <label><strong>🔑 Product Slug (License System Identifier):</strong></label><br>
        <input type="text" name="product_slug" value="<?php echo esc_attr($product_slug); ?>" placeholder="wordpress-easy-popup-plugin" style="width: 100%; font-family: monospace; margin-top: 8px;" pattern="[a-z0-9\-]+" required>
        <span style="display: block; margin-top: 8px; font-size: 12px; color: #856404; line-height: 1.6;">
            <strong>IMPORTANT:</strong> Unique identifier for license validation (lowercase, numbers, hyphens only).<br>
            📌 <strong>This MUST match the <code>WPIGO_PRODUCT_SLUG</code> constant in your plugin/theme main file.</strong><br>
            Example: <code>wordpress-easy-popup-plugin</code>, <code>wpigo-premium-theme</code>, <code>seo-optimizer-pro</code>
        </span>
    </p>
    <p>
        <label><strong>Sales Count:</strong></label><br>
        <input type="number" name="product_sales_count" value="<?php echo esc_attr($sales_count); ?>" min="0" step="1" style="width: 200px;" placeholder="0">
        <span style="display: block; margin-top: 5px; font-size: 12px; color: #666;">
            Current sales count. New sales will be added on top of this value.
        </span>
    </p>
    <p>
        <label><strong>Live Demo URL:</strong></label><br>
        <input type="url" name="product_live_demo_url" value="<?php echo esc_attr($live_demo_url); ?>" placeholder="https://demo.example.com" style="width: 100%;">
        <span style="display: block; margin-top: 5px; font-size: 12px; color: #666;">
            Enter the full URL including https:// (e.g., https://demo.yoursite.com)
        </span>
    </p>
    <p>
        <label><strong>Features (one per line):</strong></label><br>
        <textarea name="product_features" rows="8" style="width: 100%;"><?php echo esc_textarea($features); ?></textarea>
    </p>
    <?php
}

// Initial Ratings Meta Box
function marketplace_product_ratings_meta_box_callback($post) {
    wp_nonce_field('marketplace_save_ratings_meta', 'marketplace_ratings_meta_nonce');

    // Get current admin-set ratings
    $admin_code_quality = get_post_meta($post->ID, '_admin_rating_code_quality', true) ?: '';
    $admin_documentation = get_post_meta($post->ID, '_admin_rating_documentation', true) ?: '';
    $admin_support = get_post_meta($post->ID, '_admin_rating_support', true) ?: '';
    $admin_features = get_post_meta($post->ID, '_admin_rating_features', true) ?: '';
    $admin_design = get_post_meta($post->ID, '_admin_rating_design', true) ?: '';

    $admin_rating_count = get_post_meta($post->ID, '_admin_rating_count', true) ?: '';
    ?>
    <p style="color: #666; margin-bottom: 15px;">
        <em>Set initial ratings for this product (1-5 stars). These will be combined with user ratings.</em>
    </p>

    <table class="form-table" style="width: 100%;">
        <tr>
            <td style="width: 200px;"><label><strong>Code Quality:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_code_quality" value="<?php echo esc_attr($admin_code_quality); ?>"
                       min="0" max="5" step="0.1" style="width: 100px;" placeholder="0-5">
                <span style="color: #999; margin-left: 10px;">Average rating (decimals allowed)</span>
            </td>
        </tr>
        <tr>
            <td><label><strong>Documentation:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_documentation" value="<?php echo esc_attr($admin_documentation); ?>"
                       min="0" max="5" step="0.1" style="width: 100px;" placeholder="0-5">
            </td>
        </tr>
        <tr>
            <td><label><strong>Support Quality:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_support" value="<?php echo esc_attr($admin_support); ?>"
                       min="0" max="5" step="0.1" style="width: 100px;" placeholder="0-5">
            </td>
        </tr>
        <tr>
            <td><label><strong>Features:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_features" value="<?php echo esc_attr($admin_features); ?>"
                       min="0" max="5" step="0.1" style="width: 100px;" placeholder="0-5">
            </td>
        </tr>
        <tr>
            <td><label><strong>Design Quality:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_design" value="<?php echo esc_attr($admin_design); ?>"
                       min="0" max="5" step="0.1" style="width: 100px;" placeholder="0-5">
            </td>
        </tr>
        <tr style="border-top: 2px solid #ddd;">
            <td><label><strong>Simulated Rating Count:</strong></label></td>
            <td>
                <input type="number" name="admin_rating_count" value="<?php echo esc_attr($admin_rating_count); ?>"
                       min="0" step="1" style="width: 100px;" placeholder="0">
                <span style="color: #999; margin-left: 10px;">Number of ratings to simulate (e.g., 150)</span>
            </td>
        </tr>
    </table>

    <p style="background: #fff3cd; padding: 10px; border-left: 4px solid #ffc107; margin-top: 15px;">
        <strong>Note:</strong> User ratings will be added on top of these initial values.
        Leave empty (or 0) to start with no ratings.
    </p>
    <?php
}

function marketplace_save_product_meta($post_id) {
    if (!isset($_POST['marketplace_product_meta_nonce']) ||
        !wp_verify_nonce($_POST['marketplace_product_meta_nonce'], 'marketplace_save_product_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    // Only save for 'post' post type
    if (get_post_type($post_id) !== 'post') {
        return;
    }

    if (isset($_POST['product_price'])) {
        update_post_meta($post_id, 'product_price', sanitize_text_field($_POST['product_price']));
    }
    if (isset($_POST['product_version'])) {
        update_post_meta($post_id, 'product_version', sanitize_text_field($_POST['product_version']));
    }
    if (isset($_POST['product_slug'])) {
        $slug = sanitize_text_field($_POST['product_slug']);
        // Validate: lowercase, numbers, hyphens only
        $slug = strtolower($slug);
        $slug = preg_replace('/[^a-z0-9\-]/', '', $slug);

        // DEBUG: Log the save
        error_log("WPIGO Product Slug Save - Post ID: {$post_id}, Input: {$_POST['product_slug']}, Sanitized: {$slug}");

        update_post_meta($post_id, '_product_slug', $slug);

        // DEBUG: Verify it was saved
        $saved_slug = get_post_meta($post_id, '_product_slug', true);
        error_log("WPIGO Product Slug After Save - Post ID: {$post_id}, Saved Value: {$saved_slug}");
    }
    if (isset($_POST['product_live_demo_url'])) {
        update_post_meta($post_id, 'product_live_demo_url', esc_url_raw($_POST['product_live_demo_url']));
    }
    if (isset($_POST['product_features'])) {
        update_post_meta($post_id, 'product_features', sanitize_textarea_field($_POST['product_features']));
    }
    if (isset($_POST['product_sales_count'])) {
        $sales_count = intval($_POST['product_sales_count']);
        update_post_meta($post_id, '_product_sales_count', max(0, $sales_count));
    }
}
add_action('save_post', 'marketplace_save_product_meta');

function marketplace_save_ratings_meta($post_id) {
    if (!isset($_POST['marketplace_ratings_meta_nonce']) ||
        !wp_verify_nonce($_POST['marketplace_ratings_meta_nonce'], 'marketplace_save_ratings_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    // Save admin ratings
    $rating_fields = array('code_quality', 'documentation', 'support', 'features', 'design');

    foreach ($rating_fields as $field) {
        if (isset($_POST['admin_rating_' . $field])) {
            $value = floatval($_POST['admin_rating_' . $field]);
            if ($value >= 0 && $value <= 5) {
                update_post_meta($post_id, '_admin_rating_' . $field, $value);
            }
        }
    }

    // Save admin rating count
    if (isset($_POST['admin_rating_count'])) {
        $count = intval($_POST['admin_rating_count']);
        update_post_meta($post_id, '_admin_rating_count', max(0, $count));
    }
}
add_action('save_post', 'marketplace_save_ratings_meta');

// ============================================ 
// RATING SYSTEM
// ============================================ 

/**
 * Generate star HTML
 */
function wpigo_generate_stars($rating, $max = 5) {
    $output = '';
    $full_stars = floor($rating);
    $half_star = ($rating - $full_stars) >= 0.5;
    $empty_stars = $max - $full_stars - ($half_star ? 1 : 0);

    // Full stars
    for ($i = 0; $i < $full_stars; $i++) {
        $output .= '<span class="wpigo-star wpigo-star-full"></span>';
    }

    // Half star
    if ($half_star) {
        $output .= '<span class="wpigo-star wpigo-star-half">★</span>';
    }

    // Empty stars
    for ($i = 0; $i < $empty_stars; $i++) {
        $output .= '<span class="wpigo-star wpigo-star-empty">☆</span>';
    }

    return $output;
}

/**
 * Check if user has already rated the product
 */
function wpigo_user_has_rated($post_id, $user_id) {
    $rated_users = get_post_meta($post_id, '_rated_users', true);
    if (!is_array($rated_users)) {
        $rated_users = array();
    }
    return in_array($user_id, $rated_users);
}

/**
 * AJAX handler for submitting ratings
 */
function wpigo_submit_rating() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wpigo_rating_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed'));
    }

    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'You must be logged in to rate'));
    }

    $post_id = intval($_POST['post_id']);
    $user_id = get_current_user_id();

    // Check if user has already rated
    if (wpigo_user_has_rated($post_id, $user_id)) {
        wp_send_json_error(array('message' => 'You have already rated this product'));
    }

    // Get ratings
    $ratings = array(
        'code_quality' => intval($_POST['code_quality']),
        'documentation' => intval($_POST['documentation']),
        'support' => intval($_POST['support']),
        'features' => intval($_POST['features']),
        'design' => intval($_POST['design'])
    );

    // Validate ratings (1-5)
    foreach ($ratings as $key => $value) {
        if ($value < 1 || $value > 5) {
            wp_send_json_error(array('message' => 'Invalid rating value'));
        }
    }

    // Update ratings
    foreach ($ratings as $category => $rating) {
        // Get current total
        $current_total = get_post_meta($post_id, '_rating_' . $category, true) ?: 0;
        $current_count = get_post_meta($post_id, '_rating_' . $category . '_count', true) ?: 0;

        // Add new rating
        update_post_meta($post_id, '_rating_' . $category, $current_total + $rating);
        update_post_meta($post_id, '_rating_' . $category . '_count', $current_count + 1);
    }

    // Mark user as rated
    $rated_users = get_post_meta($post_id, '_rated_users', true);
    if (!is_array($rated_users)) {
        $rated_users = array();
    }
    $rated_users[] = $user_id;
    update_post_meta($post_id, '_rated_users', $rated_users);

    wp_send_json_success(array('message' => 'Thank you for your rating!'));
}
add_action('wp_ajax_wpigo_submit_rating', 'wpigo_submit_rating');

// ============================================ 
// PRODUCT INFO META BOXES
// ============================================ 

/**
 * Compatibility Meta Box
 */
function marketplace_product_compatibility_meta_box_callback($post) {
    wp_nonce_field('marketplace_save_compatibility_meta', 'marketplace_compatibility_meta_nonce');

    // Get all compatibility data
    $compat = array();
    $all_fields = array(
        // Core
        'wp_64', 'wp_65', 'wp_66', 'wp_67', 'wp_68',
        'php_74', 'php_80', 'php_81', 'php_82', 'php_83', 'php_84',
        'mysql_57', 'mysql_80', 'mariadb_103', 'mariadb_105',
        // Hosting & Server
        'host_shared', 'host_vps', 'host_vds', 'host_dedicated', 'host_cloud', 'host_managed',
        'server_apache', 'server_nginx', 'server_litespeed', 'server_openlitespeed',
        // Browsers
        'browser_chrome', 'browser_firefox', 'browser_safari', 'browser_edge', 'browser_opera',
        // Page Builders
        'builder_elementor', 'builder_wpbakery', 'builder_divi', 'builder_beaver', 'builder_oxygen', 'builder_bricks', 'builder_gutenberg',
        // Plugins
        'plugin_woocommerce', 'plugin_edd', 'plugin_yoast', 'plugin_rankmath', 'plugin_aioseo',
        'plugin_cf7', 'plugin_wpforms', 'plugin_gravityforms', 'plugin_acf', 'plugin_polylang', 'plugin_wpml',
        // Performance
        'perf_wprocket', 'perf_w3cache', 'perf_wpsuper', 'perf_litespeed', 'perf_cdn', 'perf_redis', 'perf_memcached',
        // Security
        'sec_wordfence', 'sec_ithemes', 'sec_sucuri', 'sec_aio',
        // WordPress Features
        'wp_multisite', 'wp_childtheme', 'wp_translationready', 'wp_rtl', 'wp_restapi', 'wp_wpcli', 'wp_coding_standards', 'wp_fse',
        // Community
        'comm_buddypress', 'comm_bbpress', 'comm_ultimatemember',
        // Modern Standards
        'std_ssl', 'std_gdpr', 'std_wcag', 'std_schema', 'std_html5', 'std_responsive', 'std_amp'
    );

    foreach ($all_fields as $field) {
        $compat[$field] = get_post_meta($post->ID, '_compat_' . $field, true);
    }
    ?>

    <div class="wpigo-compatibility-wrapper" style="max-height: 800px; overflow-y: auto; padding-right: 10px;">

        <!-- CORE COMPATIBILITY -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">🔧 Core Compatibility</h4>

            <p style="margin: 5px 0 8px; font-weight: 600; font-size: 12px;">WordPress Versions:</p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_64" value="1" <?php checked($compat['wp_64'], '1'); ?>> WordPress 6.4</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_65" value="1" <?php checked($compat['wp_65'], '1'); ?>> WordPress 6.5</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_66" value="1" <?php checked($compat['wp_66'], '1'); ?>> WordPress 6.6</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_67" value="1" <?php checked($compat['wp_67'], '1'); ?>> WordPress 6.7</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_68" value="1" <?php checked($compat['wp_68'], '1'); ?>> WordPress 6.8</label></p>

            <p style="margin: 12px 0 8px; font-weight: 600; font-size: 12px;">PHP Versions:</p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_74" value="1" <?php checked($compat['php_74'], '1'); ?>> PHP 7.4</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_80" value="1" <?php checked($compat['php_80'], '1'); ?>> PHP 8.0</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_81" value="1" <?php checked($compat['php_81'], '1'); ?>> PHP 8.1</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_82" value="1" <?php checked($compat['php_82'], '1'); ?>> PHP 8.2</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_83" value="1" <?php checked($compat['php_83'], '1'); ?>> PHP 8.3</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_php_84" value="1" <?php checked($compat['php_84'], '1'); ?>> PHP 8.4</label></p>

            <p style="margin: 12px 0 8px; font-weight: 600; font-size: 12px;">Database:</p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_mysql_57" value="1" <?php checked($compat['mysql_57'], '1'); ?>> MySQL 5.7+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_mysql_80" value="1" <?php checked($compat['mysql_80'], '1'); ?>> MySQL 8.0+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_mariadb_103" value="1" <?php checked($compat['mariadb_103'], '1'); ?>> MariaDB 10.3+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_mariadb_105" value="1" <?php checked($compat['mariadb_105'], '1'); ?>> MariaDB 10.5+</label></p>
        </div>

        <!-- HOSTING & SERVER -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;"> Hosting & Server</h4>

            <p style="margin: 5px 0 8px; font-weight: 600; font-size: 12px;">Hosting Types:</p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_shared" value="1" <?php checked($compat['host_shared'], '1'); ?>> Shared Hosting</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_vps" value="1" <?php checked($compat['host_vps'], '1'); ?>> VPS</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_vds" value="1" <?php checked($compat['host_vds'], '1'); ?>> VDS</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_dedicated" value="1" <?php checked($compat['host_dedicated'], '1'); ?>> Dedicated Server</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_cloud" value="1" <?php checked($compat['host_cloud'], '1'); ?>> Cloud Hosting</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_host_managed" value="1" <?php checked($compat['host_managed'], '1'); ?>> Managed WordPress</label></p>

            <p style="margin: 12px 0 8px; font-weight: 600; font-size: 12px;">Server Software:</p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_server_apache" value="1" <?php checked($compat['server_apache'], '1'); ?>> Apache 2.4+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_server_nginx" value="1" <?php checked($compat['server_nginx'], '1'); ?>> Nginx 1.18+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_server_litespeed" value="1" <?php checked($compat['server_litespeed'], '1'); ?>> LiteSpeed 5.4+</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_server_openlitespeed" value="1" <?php checked($compat['server_openlitespeed'], '1'); ?>> OpenLiteSpeed</label></p>
        </div>

        <!-- BROWSERS -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">🌍 Browser Compatibility</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_browser_chrome" value="1" <?php checked($compat['browser_chrome'], '1'); ?>> Google Chrome</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_browser_firefox" value="1" <?php checked($compat['browser_firefox'], '1'); ?>> Mozilla Firefox</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_browser_safari" value="1" <?php checked($compat['browser_safari'], '1'); ?>> Safari</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_browser_edge" value="1" <?php checked($compat['browser_edge'], '1'); ?>> Microsoft Edge</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_browser_opera" value="1" <?php checked($compat['browser_opera'], '1'); ?>> Opera</label></p>
        </div>

        <!-- PAGE BUILDERS -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">🎨 Page Builders</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_elementor" value="1" <?php checked($compat['builder_elementor'], '1'); ?>> Elementor</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_wpbakery" value="1" <?php checked($compat['builder_wpbakery'], '1'); ?>> WPBakery Page Builder</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_divi" value="1" <?php checked($compat['builder_divi'], '1'); ?>> Divi Builder</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_beaver" value="1" <?php checked($compat['builder_beaver'], '1'); ?>> Beaver Builder</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_oxygen" value="1" <?php checked($compat['builder_oxygen'], '1'); ?>> Oxygen Builder</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_bricks" value="1" <?php checked($compat['builder_bricks'], '1'); ?>> Bricks Builder</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_builder_gutenberg" value="1" <?php checked($compat['builder_gutenberg'], '1'); ?>> Gutenberg (Block Editor)</label></p>
        </div>

        <!-- POPULAR PLUGINS -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;"> Popular Plugins</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_woocommerce" value="1" <?php checked($compat['plugin_woocommerce'], '1'); ?>> WooCommerce</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_edd" value="1" <?php checked($compat['plugin_edd'], '1'); ?>> Easy Digital Downloads</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_yoast" value="1" <?php checked($compat['plugin_yoast'], '1'); ?>> Yoast SEO</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_rankmath" value="1" <?php checked($compat['plugin_rankmath'], '1'); ?>> Rank Math SEO</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_aioseo" value="1" <?php checked($compat['plugin_aioseo'], '1'); ?>> All in One SEO</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_cf7" value="1" <?php checked($compat['plugin_cf7'], '1'); ?>> Contact Form 7</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_wpforms" value="1" <?php checked($compat['plugin_wpforms'], '1'); ?>> WPForms</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_gravityforms" value="1" <?php checked($compat['plugin_gravityforms'], '1'); ?>> Gravity Forms</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_acf" value="1" <?php checked($compat['plugin_acf'], '1'); ?>> Advanced Custom Fields (ACF)</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_polylang" value="1" <?php checked($compat['plugin_polylang'], '1'); ?>> Polylang</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_plugin_wpml" value="1" <?php checked($compat['plugin_wpml'], '1'); ?>> WPML</label></p>
        </div>

        <!-- PERFORMANCE & CACHE -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;"> Performance & Cache</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_wprocket" value="1" <?php checked($compat['perf_wprocket'], '1'); ?>> WP Rocket</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_w3cache" value="1" <?php checked($compat['perf_w3cache'], '1'); ?>> W3 Total Cache</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_wpsuper" value="1" <?php checked($compat['perf_wpsuper'], '1'); ?>> WP Super Cache</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_litespeed" value="1" <?php checked($compat['perf_litespeed'], '1'); ?>> LiteSpeed Cache</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_cdn" value="1" <?php checked($compat['perf_cdn'], '1'); ?>> CDN Ready</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_redis" value="1" <?php checked($compat['perf_redis'], '1'); ?>> Redis Compatible</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_perf_memcached" value="1" <?php checked($compat['perf_memcached'], '1'); ?>> Memcached Compatible</label></p>
        </div>

        <!-- SECURITY -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;"> Security Plugins</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_sec_wordfence" value="1" <?php checked($compat['sec_wordfence'], '1'); ?>> Wordfence Security</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_sec_ithemes" value="1" <?php checked($compat['sec_ithemes'], '1'); ?>> iThemes Security</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_sec_sucuri" value="1" <?php checked($compat['sec_sucuri'], '1'); ?>> Sucuri Security</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_sec_aio" value="1" <?php checked($compat['sec_aio'], '1'); ?>> All In One WP Security</label></p>
        </div>

        <!-- WORDPRESS FEATURES -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">️ WordPress Features</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_multisite" value="1" <?php checked($compat['wp_multisite'], '1'); ?>> Multisite Network</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_childtheme" value="1" <?php checked($compat['wp_childtheme'], '1'); ?>> Child Theme Ready</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_translationready" value="1" <?php checked($compat['wp_translationready'], '1'); ?>> Translation Ready (.pot file)</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_rtl" value="1" <?php checked($compat['wp_rtl'], '1'); ?>> RTL (Right to Left) Support</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_restapi" value="1" <?php checked($compat['wp_restapi'], '1'); ?>> REST API Compatible</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_wpcli" value="1" <?php checked($compat['wp_wpcli'], '1'); ?>> WP-CLI Compatible</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_coding_standards" value="1" <?php checked($compat['wp_coding_standards'], '1'); ?>> WordPress Coding Standards</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_wp_fse" value="1" <?php checked($compat['wp_fse'], '1'); ?>> Full Site Editing (FSE)</label></p>
        </div>

        <!-- COMMUNITY/SOCIAL -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">👥 Community/Social</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_comm_buddypress" value="1" <?php checked($compat['comm_buddypress'], '1'); ?>> BuddyPress</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_comm_bbpress" value="1" <?php checked($compat['comm_bbpress'], '1'); ?>> bbPress</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_comm_ultimatemember" value="1" <?php checked($compat['comm_ultimatemember'], '1'); ?>> Ultimate Member</label></p>
        </div>

        <!-- MODERN STANDARDS -->
        <div style="margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px; padding: 8px; background: #f0f0f1; border-left: 4px solid #2271b1;">✨ Modern Standards</h4>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_ssl" value="1" <?php checked($compat['std_ssl'], '1'); ?>> SSL/HTTPS Ready</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_gdpr" value="1" <?php checked($compat['std_gdpr'], '1'); ?>> GDPR Compliant</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_wcag" value="1" <?php checked($compat['std_wcag'], '1'); ?>> WCAG 2.1 Accessible</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_schema" value="1" <?php checked($compat['std_schema'], '1'); ?>> Schema.org Markup</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_html5" value="1" <?php checked($compat['std_html5'], '1'); ?>> HTML5 Valid</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_responsive" value="1" <?php checked($compat['std_responsive'], '1'); ?>> Mobile Responsive</label></p>
            <p style="margin: 3px 0;"><label><input type="checkbox" name="compat_std_amp" value="1" <?php checked($compat['std_amp'], '1'); ?>> AMP Ready</label></p>
        </div>

    </div>

    <p style="margin-top: 15px; padding: 10px; background: #e7f5fe; border-left: 4px solid #2271b1; font-size: 12px;">
        💡 <strong>Tip:</strong> Select all compatible versions, features, and technologies. This helps customers understand exactly what your product supports.
    </p>
    <?php
}

/**
 * Support & Updates Meta Box
 */
function marketplace_product_support_meta_box_callback($post) {
    wp_nonce_field('marketplace_save_support_meta', 'marketplace_support_meta_nonce');

    $support_period = get_post_meta($post->ID, '_support_period', true);
    $updates_period = get_post_meta($post->ID, '_updates_period', true);
    $update_extension_price = get_post_meta($post->ID, '_update_extension_price', true);
    $response_time = get_post_meta($post->ID, '_response_time', true);
    ?>

    <!-- Free Support Period -->
    <p>
        <label><strong>Free Support Period:</strong></label><br>
        <select name="support_period" style="width: 100%;">
            <option value="">Select duration...</option>
            <?php for ($i = 1; $i <= 12; $i++) : ?>
                <option value="<?php echo $i; ?>" <?php selected($support_period, $i); ?> >
                    <?php echo $i; ?> <?php echo $i == 1 ? 'month' : 'months'; ?>
                </option>
            <?php endfor; ?>
        </select>
        <span style="display: block; margin-top: 5px; font-size: 11px; color: #666; font-style: italic;">
            How long will you provide free support from the purchase date?
        </span>
    </p>

    <!-- Updates Period -->
    <p>
        <label><strong>Updates Period:</strong></label><br>
        <select name="updates_period" id="updates_period" style="width: 100%;">
            <option value="">Select duration...</option>
            <option value="1" <?php selected($updates_period, '1'); ?>>1 Year</option>
            <option value="2" <?php selected($updates_period, '2'); ?>>2 Years</option>
            <option value="3" <?php selected($updates_period, '3'); ?>>3 Years</option>
            <option value="lifetime" <?php selected($updates_period, 'lifetime'); ?>>Lifetime</option>
        </select>
        <span style="display: block; margin-top: 5px; font-size: 11px; color: #666; font-style: italic;">
            How long will customers receive free updates from the purchase date?
        </span>
    </p>

    <!-- Update Extension Price (conditional) -->
    <p id="update_extension_price_wrapper" style="<?php echo ($updates_period === 'lifetime' || empty($updates_period)) ? 'display: none;' : ''; ?>">
        <label><strong>Update Extension Price (USD):</strong></label><br>
        <input type="number" name="update_extension_price" id="update_extension_price" value="<?php echo esc_attr($update_extension_price); ?>" step="0.01" min="0" placeholder="0.00" style="width: 100%;">
        <span style="display: block; margin-top: 5px; font-size: 11px; color: #666; font-style: italic;">
            Price customers must pay to extend update access for an additional 1 year after the initial period expires. You receive 90% of this price, 10% is site commission.
        </span>
    </p>

    <div style="background: #fff3cd; padding: 10px; border-left: 4px solid #ffc107; margin: 10px 0; font-size: 12px;">
        <strong>⚠️ Important:</strong> If you select anything other than <strong>Lifetime</strong> (e.g., 1 year), customers will receive free updates for that period. After that, they must purchase an update extension package to continue receiving updates.
    </div>

    <!-- Response Time -->
    <p>
        <label><strong>Response Time:</strong></label><br>
        <select name="response_time" style="width: 100%;">
            <option value="">Select response time...</option>
            <option value="12" <?php selected($response_time, '12'); ?>>12 hours</option>
            <option value="24" <?php selected($response_time, '24'); ?>>24 hours</option>
            <option value="48" <?php selected($response_time, '48'); ?>>48 hours</option>
            <option value="72" <?php selected($response_time, '72'); ?>>72 hours (max)</option>
        </select>
        <span style="display: block; margin-top: 5px; font-size: 11px; color: #666; font-style: italic;">
            How quickly can you respond to support requests? This cannot exceed 72 hours (excluding public holidays) and you are obligated to respond within your chosen timeframe.
        </span>
    </p>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // Toggle update extension price field based on updates period
        $('#updates_period').on('change', function() {
            var selectedValue = $(this).val();
            if (selectedValue === 'lifetime' || selectedValue === '') {
                $('#update_extension_price_wrapper').slideUp();
                $('#update_extension_price').val('');
            } else {
                $('#update_extension_price_wrapper').slideDown();
            }
        });
    });
    </script>
    <?php
}

/**
 * Included Files Meta Box
 */
function marketplace_product_files_meta_box_callback($post) {
    wp_nonce_field('marketplace_save_files_meta', 'marketplace_files_meta_nonce');

    $php_files = get_post_meta($post->ID, '_files_php', true);
    $css_files = get_post_meta($post->ID, '_files_css', true);
    $js_files = get_post_meta($post->ID, '_files_js', true);
    $docs = get_post_meta($post->ID, '_files_docs', true);
    $sql = get_post_meta($post->ID, '_files_sql', true);
    ?>
    <p><label><input type="checkbox" name="files_php" value="1" <?php checked($php_files, '1'); ?>> PHP Files</label></p>
    <p><label><input type="checkbox" name="files_css" value="1" <?php checked($css_files, '1'); ?>> CSS/SCSS</label></p>
    <p><label><input type="checkbox" name="files_js" value="1" <?php checked($js_files, '1'); ?>> JavaScript/jQuery</label></p>
    <p><label><input type="checkbox" name="files_docs" value="1" <?php checked($docs, '1'); ?>> Documentation (PDF)</label></p>
    <p><label><input type="checkbox" name="files_sql" value="1" <?php checked($sql, '1'); ?>> SQL Installation File</label></p>
    <?php
}

/**
 * Save all new meta boxes
 */
function marketplace_save_extra_meta($post_id) {
    // Compatibility
    if (isset($_POST['marketplace_compatibility_meta_nonce']) &&
        wp_verify_nonce($_POST['marketplace_compatibility_meta_nonce'], 'marketplace_save_compatibility_meta')) {

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $fields = array(
            // Core
            'wp_64', 'wp_65', 'wp_66', 'wp_67', 'wp_68',
            'php_74', 'php_80', 'php_81', 'php_82', 'php_83', 'php_84',
            'mysql_57', 'mysql_80', 'mariadb_103', 'mariadb_105',
            // Hosting & Server
            'host_shared', 'host_vps', 'host_vds', 'host_dedicated', 'host_cloud', 'host_managed',
            'server_apache', 'server_nginx', 'server_litespeed', 'server_openlitespeed',
            // Browsers
            'browser_chrome', 'browser_firefox', 'browser_safari', 'browser_edge', 'browser_opera',
            // Page Builders
            'builder_elementor', 'builder_wpbakery', 'builder_divi', 'builder_beaver', 'builder_oxygen', 'builder_bricks', 'builder_gutenberg',
            // Plugins
            'plugin_woocommerce', 'plugin_edd', 'plugin_yoast', 'plugin_rankmath', 'plugin_aioseo',
            'plugin_cf7', 'plugin_wpforms', 'plugin_gravityforms', 'plugin_acf', 'plugin_polylang', 'plugin_wpml',
            // Performance
            'perf_wprocket', 'perf_w3cache', 'perf_wpsuper', 'perf_litespeed', 'perf_cdn', 'perf_redis', 'perf_memcached',
            // Security
            'sec_wordfence', 'sec_ithemes', 'sec_sucuri', 'sec_aio',
            // WordPress Features
            'wp_multisite', 'wp_childtheme', 'wp_translationready', 'wp_rtl', 'wp_restapi', 'wp_wpcli', 'wp_coding_standards', 'wp_fse',
            // Community
            'comm_buddypress', 'comm_bbpress', 'comm_ultimatemember',
            // Modern Standards
            'std_ssl', 'std_gdpr', 'std_wcag', 'std_schema', 'std_html5', 'std_responsive', 'std_amp'
        );

        foreach ($fields as $field) {
            $value = isset($_POST['compat_' . $field]) ? '1' : '0';
            update_post_meta($post_id, '_compat_' . $field, $value);
        }
    }

    // Support
    if (isset($_POST['marketplace_support_meta_nonce']) &&
        wp_verify_nonce($_POST['marketplace_support_meta_nonce'], 'marketplace_save_support_meta')) {

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        if (isset($_POST['support_period'])) {
            update_post_meta($post_id, '_support_period', sanitize_text_field($_POST['support_period']));
        }
        if (isset($_POST['updates_period'])) {
            update_post_meta($post_id, '_updates_period', sanitize_text_field($_POST['updates_period']));
        }
        if (isset($_POST['update_extension_price'])) {
            $price = sanitize_text_field($_POST['update_extension_price']);
            update_post_meta($post_id, '_update_extension_price', $price);
        }
        if (isset($_POST['response_time'])) {
            update_post_meta($post_id, '_response_time', sanitize_text_field($_POST['response_time']));
        }
    }

    // Files
    if (isset($_POST['marketplace_files_meta_nonce']) &&
        wp_verify_nonce($_POST['marketplace_files_meta_nonce'], 'marketplace_save_files_meta')) {

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $fields = array('php', 'css', 'js', 'docs', 'sql');
        foreach ($fields as $field) {
            $value = isset($_POST['files_' . $field]) ? '1' : '0';
            update_post_meta($post_id, '_files_' . $field, $value);
        }
    }
}
add_action('save_post', 'marketplace_save_extra_meta');


/**
 * Get author statistics
 */

// ============================================ 
// SHOPPING CART SYSTEM
// ============================================ 

/**
 * Get or create cart identifier for guests
 */
function wpigo_get_cart_id() {
    if (is_user_logged_in()) {
        return 'wpigo_cart_user_' . get_current_user_id();
    }

    // Guest user - check for existing cookie
    if (isset($_COOKIE['wpigo_cart_token'])) {
        $token = sanitize_text_field($_COOKIE['wpigo_cart_token']);
        // Verify token format (now 32 hex chars from random_bytes)
        if (preg_match('/^[a-f0-9]{32}$/', $token)) {
            return 'wpigo_cart_guest_' . $token;
        }
    }

    // Generate new, cryptographically secure token
    $token = bin2hex(random_bytes(16));

    // Try to set cookie with security flags (only works if headers not sent)
    if (!headers_sent()) {
        setcookie(
            'wpigo_cart_token', 
            $token, 
            [
                'expires' => time() + (86400 * 30), // 30 days
                'path' => defined('COOKIEPATH') ? COOKIEPATH : '/',
                'domain' => defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '',
                'secure' => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax'
            ]
        );
    }

    return 'wpigo_cart_guest_' . $token;
}

/**
 * Get cart items
 */
function wpigo_get_cart_items() {
    $cart_id = wpigo_get_cart_id();
    $cart_data = get_transient($cart_id);

    if (!$cart_data || !is_array($cart_data)) {
        return array();
    }

    return $cart_data;
}

/**
 * Add item to cart
 */
function wpigo_add_to_cart($product_id) {
    $cart_id = wpigo_get_cart_id();
    $cart_items = wpigo_get_cart_items();

    // Cart item limit check (max 25 items)
    if (count($cart_items) >= 25) {
        return ['error' => 'You can add a maximum of 25 items to your cart.'];
    }

    // Check if product exists and is published
    $product = get_post($product_id);
    if (!$product || $product->post_status !== 'publish' || $product->post_type !== 'post') {
        return false;
    }

    // Check if already in cart
    if (isset($cart_items[$product_id])) {
        return true; // Already in cart
    }

    // Add to cart
    $cart_items[$product_id] = array(
        'product_id' => $product_id,
        'added_time' => current_time('timestamp')
    );

    // Save to transient (24 hours)
    set_transient($cart_id, $cart_items, 86400);

    return true;
}

/**
 * Remove item from cart
 */
function wpigo_remove_from_cart($product_id) {
    $cart_id = wpigo_get_cart_id();
    $cart_items = wpigo_get_cart_items();

    if (isset($cart_items[$product_id])) {
        unset($cart_items[$product_id]);
        set_transient($cart_id, $cart_items, 86400);
        return true;
    }

    return false;
}

/**
 * Clear entire cart
 */
function wpigo_clear_cart() {
    $cart_id = wpigo_get_cart_id();
    delete_transient($cart_id);
}

/**
 * Get cart item count
 */
function wpigo_get_cart_count() {
    return count(wpigo_get_cart_items());
}

/**
 * Get cart total price
 */
function wpigo_get_cart_total() {
    $cart_items = wpigo_get_cart_items();
    $total = 0;

    foreach ($cart_items as $item) {
        $price = get_post_meta($item['product_id'], 'product_price', true);
        $total += floatval($price ?: 29);
    }

    return $total;
}

/**
 * AJAX handler for adding to cart
 */
function wpigo_ajax_add_to_cart() {
    // Rate limiting: max 50 cart adds per hour per IP
    $user_ip = $_SERVER['REMOTE_ADDR'];
    $rate_key = 'wpigo_cart_rate_' . md5($user_ip);
    $attempts = get_transient($rate_key) ?: 0;

    if ($attempts > 50) {
        wp_send_json_error(array('message' => 'Too many requests. Please try again later.'));
        return;
    }
    
    set_transient($rate_key, $attempts + 1, HOUR_IN_SECONDS);

    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'wpigo_cart_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed'));
    }

    $product_id = intval($_POST['product_id']);
    
    $result = wpigo_add_to_cart($product_id);

    if ($result === true) {
        wp_send_json_success(array(
            'message' => 'Product added to cart!',
            'cart_count' => wpigo_get_cart_count()
        ));
    } else {
        // Pass the error message from wpigo_add_to_cart if it exists
        $error_message = is_array($result) && isset($result['error']) ? $result['error'] : 'Failed to add product to cart.';
        wp_send_json_error(array('message' => $error_message));
    }
}
add_action('wp_ajax_wpigo_add_to_cart', 'wpigo_ajax_add_to_cart');
add_action('wp_ajax_nopriv_wpigo_add_to_cart', 'wpigo_ajax_add_to_cart');

/**
 * AJAX handler for removing from cart
 */
function wpigo_ajax_remove_from_cart() {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    // Use a specific nonce for the removal action for enhanced security
    check_ajax_referer('wpigo_remove_from_cart_' . $product_id, 'nonce');

    if (wpigo_remove_from_cart($product_id)) {
        wp_send_json_success(array(
            'message' => 'Product removed from cart',
            'cart_count' => wpigo_get_cart_count(),
            'cart_total' => wpigo_get_cart_total()
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to remove product'));
    }
}
add_action('wp_ajax_wpigo_remove_from_cart', 'wpigo_ajax_remove_from_cart');
add_action('wp_ajax_nopriv_wpigo_remove_from_cart', 'wpigo_ajax_remove_from_cart');

/**
 * Enqueue shop scripts (cart, checkout, member-profile)
 */
function wpigo_enqueue_shop_scripts() {
    // Load shop.js on: single posts (Add to Cart), cart page, checkout page, member profile pages
    if (is_single() || is_page_template('cart.php') || is_page_template('template-checkout.php') || is_page_template('template-order-confirmation.php') || get_query_var('member_username')) {
        wp_enqueue_script('wpigo-shop', get_template_directory_uri() . '/js/shop.js', array('jquery'), time(), true);

        // Localize for cart
        wp_localize_script('wpigo-shop', 'wpigoCart', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpigo_cart_nonce'),
            'cart_url' => home_url('/cart/'),
            'checkout_url' => home_url('/checkout/')
        ));

        // Localize for checkout
        wp_localize_script('wpigo-shop', 'wpigoCheckout', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpigo_checkout_nonce'),
        ));
    }
}
add_action('wp_enqueue_scripts', 'wpigo_enqueue_shop_scripts');

/**
 * ======================================== 
 * MEMBER PROFILE SYSTEM
 * ======================================== 
 */

/**
 * Add member rewrite rules
 */
function wpigo_member_rewrite_rules() {
    add_rewrite_rule(
        '^member/([^/]+)/?$',
        'index.php?member_username=$matches[1]',
        'top'
    );
}
add_action('init', 'wpigo_member_rewrite_rules');

/**
 * Add member query var
 */
function wpigo_member_query_vars($vars) {
    $vars[] = 'member_username';
    return $vars;
}
add_filter('query_vars', 'wpigo_member_query_vars');

/**
 * Load member template
 */
function wpigo_member_template($template) {
    $member_username = get_query_var('member_username');

    if ($member_username) {
        $member_template = locate_template('member.php');
        if ($member_template) {
            return $member_template;
        }
    }

    return $template;
}
add_filter('template_include', 'wpigo_member_template');

/**
 * Member profile page title filter
 */
function wpigo_member_profile_title($title) {
    if (in_the_loop() && get_query_var('member_username')) {
        $member_username = get_query_var('member_username');
        $member = get_user_by('login', $member_username);

        if ($member) {
            $title = $member->display_name . ' - Member Profile';
        }
    }

    return $title;
}
add_filter('the_title', 'wpigo_member_profile_title');

/**
 * Get member profile URL
 */
function wpigo_get_member_profile_url($user_id_or_login) {
    if (is_numeric($user_id_or_login)) {
        $user = get_user_by('id', $user_id_or_login);
        $username = $user ? $user->user_login : '';
    } else {
        $username = $user_id_or_login;
    }

    return $username ? home_url('/member/' . $username . '/') : '';
}

/**
 * Flush rewrite rules on theme activation
 */
function wpigo_flush_rewrite_rules_on_activation() {
    wpigo_member_rewrite_rules();
    wpigo_add_license_api_rewrite_rules();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'wpigo_flush_rewrite_rules_on_activation');

// ============================================ 
// RATING CALCULATION
// ============================================ 

/**
 * Get and calculate all product ratings (admin + user) with caching.
 *
 * @param int $post_id The ID of the product.
 * @return array An array of calculated ratings.
 */
function wpigo_get_ratings($post_id) {
    // Use static cache to avoid recalculating on the same page load
    static $cache = array();
    if (isset($cache[$post_id])) {
        return $cache[$post_id];
    }

    $rating_categories = array('code_quality', 'documentation', 'support', 'features', 'design');
    $ratings = array();

    // 1. Get admin-set initial ratings and simulated count
    $admin_rating_count = (int) get_post_meta($post_id, '_admin_rating_count', true);
    $admin_totals = array();
    foreach ($rating_categories as $cat) {
        $admin_rating = (float) get_post_meta($post_id, '_admin_rating_' . $cat, true);
        $admin_totals[$cat] = $admin_rating * $admin_rating_count;
    }

    // 2. Get user-submitted ratings and counts
    $user_rating_count = 0;
    $user_totals = array();
    foreach ($rating_categories as $cat) {
        $user_totals[$cat] = (float) get_post_meta($post_id, '_rating_' . $cat, true);
        $count = (int) get_post_meta($post_id, '_rating_' . $cat . '_count', true);
        // Use the count from the first category as the definitive user rating count
        if ($cat === 'code_quality') {
            $user_rating_count = $count;
        }
    }

    // 3. Calculate combined averages
    $total_rating_count = $admin_rating_count + $user_rating_count;
    $overall_sum = 0;
    $category_averages = array();

    foreach ($rating_categories as $cat) {
        $total_sum = ($admin_totals[$cat] ?? 0) + ($user_totals[$cat] ?? 0);
        if ($total_rating_count > 0) {
            $average = $total_sum / $total_rating_count;
        } else {
            $average = 0;
        }
        $category_averages['avg_' . $cat] = $average;
        $overall_sum += $average;
    }

    // 4. Calculate final overall rating
    $overall_rating = 0;
    if (count($rating_categories) > 0 && $overall_sum > 0) {
        $overall_rating = $overall_sum / count($rating_categories);
    }

    // 5. Prepare the results array
    $result = array(
        'overall' => $overall_rating,
        'total_rating_count' => $total_rating_count,
        'user_rating_count' => $user_rating_count,
        'admin_rating_count' => $admin_rating_count,
        'avg_code' => $category_averages['avg_code_quality'] ?? 0,
        'avg_doc' => $category_averages['avg_documentation'] ?? 0,
        'avg_support' => $category_averages['avg_support'] ?? 0,
        'avg_features' => $category_averages['avg_features'] ?? 0,
        'avg_design' => $category_averages['avg_design'] ?? 0,
    );

    // Cache the result and return
    $cache[$post_id] = $result;
    return $result;
}


/**
 * ======================================== 
 * ORDER SYSTEM - SIPARIŞ SİSTEMİ
 * ======================================== 
 */

/**
 * Register Order Custom Post Type
 */
function wpigo_register_order_post_type() {
    register_post_type('wpigo_order', array(
        'labels' => array(
            'name' => 'Orders',
            'singular_name' => 'Order',
            'add_new' => 'Add New Order',
            'add_new_item' => 'Add New Order',
            'edit_item' => 'Edit Order',
            'view_item' => 'View Order',
            'search_items' => 'Search Orders',
            'not_found' => 'No orders found',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => false, // We'll add custom menu
        'capability_type' => 'post',
        'capabilities' => array(
            'create_posts' => 'do_not_allow',
        ),
        'map_meta_cap' => true,
        'hierarchical' => false,
        'supports' => array('title'),
        'has_archive' => false,
        'rewrite' => false,
        'query_var' => false,
    ));

    // Register order statuses
    register_post_status('wc-completed', array(
        'label' => 'Completed',
        'public' => false,
        'exclude_from_search' => true,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop('Completed <span class="count">(%s)</span>', 'Completed <span class="count">(%s)</span>'),
    ));

    register_post_status('wc-pending', array(
        'label' => 'Pending',
        'public' => false,
        'exclude_from_search' => true,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop('Pending <span class="count">(%s)</span>', 'Pending <span class="count">(%s)</span>'),
    ));

    register_post_status('wc-cancelled', array(
        'label' => 'Cancelled',
        'public' => false,
        'exclude_from_search' => true,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
        'label_count' => _n_noop('Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>'),
    ));
}
add_action('init', 'wpigo_register_order_post_type');

/**
 * Pre-cache post meta for product grid to prevent N+1 queries.
 * This function is hooked to 'the_posts' and runs before the main loop.
 */
function wpigo_prime_post_meta_cache($posts) {
    // Only run on the main query for archives (home, category, etc.)
    if (is_main_query() && is_archive()) {
        if (empty($posts)) {
            return $posts;
        }
        
        $post_ids = wp_list_pluck($posts, 'ID');
        
        // Prime the meta cache for all post IDs in a single query
        update_meta_cache('post', $post_ids);
    }
    
    return $posts;
}
add_filter('the_posts', 'wpigo_prime_post_meta_cache');


/**
 * Generate BreadcrumbList Schema for SEO.
 */
function wpigo_get_breadcrumb_schema() {
    $breadcrumbs = [];
    $position = 1;

    // Home Page
    $breadcrumbs[] = [
        "@type" => "ListItem",
        "position" => $position++,
        "name" => "Home",
        "item" => home_url('/')
    ];

    if (is_category()) {
        $category = get_queried_object();
        if ($category) {
            $breadcrumbs[] = [
                "@type" => "ListItem",
                "position" => $position++,
                "name" => $category->name
                // No "item" for the last element
            ];
        }
    } elseif (is_single()) {
        $post_id = get_the_ID();
        $categories = get_the_category($post_id);
        if (!empty($categories)) {
            $category = $categories[0];
            $breadcrumbs[] = [
                "@type" => "ListItem",
                "position" => $position++,
                "name" => $category->name,
                "item" => get_category_link($category->term_id)
            ];
        }
        $breadcrumbs[] = [
            "@type" => "ListItem",
            "position" => $position++,
            "name" => get_the_title($post_id)
            // No "item" for the last element
        ];
    } elseif (is_page()) {
        $post_id = get_the_ID();
        $breadcrumbs[] = [
            "@type" => "ListItem",
            "position" => $position++,
            "name" => get_the_title($post_id)
            // No "item" for the last element
        ];
    }

    if (count($breadcrumbs) < 2) {
        return '';
    }

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "BreadcrumbList",
        "itemListElement" => $breadcrumbs
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>';
}


/**
 * Generate unique purchase code
 */
function wpigo_generate_purchase_code() {
    // Generate UUID v4 format with WPIGO prefix
    // Format: WPIGO-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx (42 characters total)
    return sprintf('WPIGO-%s-%s-%s-%s-%s',
        bin2hex(random_bytes(4)),  // 8 hex characters
        bin2hex(random_bytes(2)),  // 4 hex characters
        bin2hex(random_bytes(2)),  // 4 hex characters
        bin2hex(random_bytes(2)),  // 4 hex characters
        bin2hex(random_bytes(6))   // 12 hex characters
    );
}

/**
 * Generate API key
 */
function wpigo_generate_api_key() {
    $random = bin2hex(random_bytes(15));
    return 'sk_live_' . substr($random, 0, 20);
}

/**
 * Generate secret key
 */
function wpigo_generate_secret_key() {
    $random = bin2hex(random_bytes(15));
    return 'sec_live_' . substr($random, 0, 20);
}

/**
 * Create new order with JSON data structure and transaction support
 * 
 * Data Structure:
 * - Critical fields stored separately for fast SQL queries (_buyer_id, _order_status, _purchase_code)
 * - All other data stored in single JSON field (_order_data) for atomicity and easy maintenance
 * - Transaction support ensures data consistency across all updates
 */
function wpigo_create_order($data) {
    global $wpdb;

    // Validate required data (buyer_id can be 0 for guests)
    if (!isset($data['buyer_id']) || empty($data['items']) || empty($data['total'])) {
        error_log('WPIGO Order Creation Failed: Missing required data');
        return false;
    }

    // Start transaction for data consistency
    $wpdb->query('START TRANSACTION');

    try {
        // Generate unique order number
        $order_number = 'ORD-' . time() . '-' . wp_rand(1000, 9999);
        $buyer_id = intval($data['buyer_id']);
        $current_time = current_time('mysql');

        // Create order post
        $order_id = wp_insert_post(array(
            'post_type' => 'wpigo_order',
            'post_title' => 'Order #' . $order_number,
            'post_status' => 'wc-completed',
            'post_author' => $buyer_id,
            'post_date' => $current_time,
        ));

        if (!$order_id || is_wp_error($order_id)) {
            throw new Exception('Failed to create order post');
        }

        // Generate license keys for each item
        $items_with_licenses = array();
        if (is_array($data['items'])) {
            foreach ($data['items'] as $item) {
                $item['license_keys'] = array(
                    'purchase_code' => wpigo_generate_purchase_code(),
                    'api_key' => wpigo_generate_api_key(),
                    'secret_key' => wpigo_generate_secret_key(),
                    'activations' => array()  // Empty activations array
                );
                $items_with_licenses[] = $item;
            }
        }

        // Build complete order data JSON (single source of truth)
        $order_data = array(
            'order_number' => $order_number,
            'total' => floatval($data['total']),
            'status' => 'completed',
            'buyer' => array(
                'id' => $buyer_id,
                'email' => sanitize_email($data['buyer_email']),
                'name' => sanitize_text_field($data['buyer_name']),
            ),
            'payment' => array(
                'method' => sanitize_text_field($data['payment_method'] ?? 'Credit Card (Test Mode)'),
                'card_last4' => sanitize_text_field($data['card_last4'] ?? ''),
                'card_brand' => sanitize_text_field($data['card_brand'] ?? ''),
            ),
            'items' => $items_with_licenses,
            'meta' => array(
                'ip' => sanitize_text_field($data['ip'] ?? $_SERVER['REMOTE_ADDR']),
                'user_agent' => sanitize_text_field($data['user_agent'] ?? $_SERVER['HTTP_USER_AGENT']),
                'created_at' => $current_time,
            ),
        );

        // Save main order data as JSON (1 query instead of 11!)
        update_post_meta($order_id, '_order_data', $order_data);

        // ALSO save items separately for backward compatibility with order confirmation page
        update_post_meta($order_id, '_order_items', $items_with_licenses);
        update_post_meta($order_id, '_order_total', floatval($data['total']));
        update_post_meta($order_id, '_order_number', $order_number);
        update_post_meta($order_id, '_buyer_email', sanitize_email($data['buyer_email']));
        update_post_meta($order_id, '_buyer_name', sanitize_text_field($data['buyer_name']));
        update_post_meta($order_id, '_payment_method', sanitize_text_field($data['payment_method'] ?? 'Credit Card (Test Mode)'));
        update_post_meta($order_id, '_card_brand', sanitize_text_field($data['card_brand'] ?? ''));
        update_post_meta($order_id, '_card_last4', sanitize_text_field($data['card_last4'] ?? ''));
        update_post_meta($order_id, '_order_ip', sanitize_text_field($data['ip'] ?? $_SERVER['REMOTE_ADDR']));

        // Save critical field separately for fast SQL queries (with INDEX)
        update_post_meta($order_id, '_buyer_id', $buyer_id);

        // Save purchase codes separately for fast download lookup
        foreach ($items_with_licenses as $item) {
            if (isset($item['license_keys']['purchase_code'])) {
                add_post_meta($order_id, '_purchase_code', $item['license_keys']['purchase_code'], false);
            }
        }

        // Update product sales (each product)
        foreach ($items_with_licenses as $item) {
            $result = wpigo_update_product_sales($item['product_id'], $order_id, floatval($item['price']));
            if (!$result) {
                throw new Exception('Failed to update product sales for product ' . $item['product_id']);
            }
        }

        // Update user purchase history
        $result = wpigo_update_user_purchases($buyer_id, $order_id, $items_with_licenses);
        if (!$result) {
            throw new Exception('Failed to update user purchases');
        }

        // Commit transaction - everything succeeded!
        $wpdb->query('COMMIT');

        error_log("WPIGO Order Created Successfully: Order #{$order_number} (ID: {$order_id})");
        return $order_id;

    } catch (Exception $e) {
        // Rollback all changes on any error
        $wpdb->query('ROLLBACK');
        error_log('WPIGO Order Creation Failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Update product sales count and total
 * 
 * @param int $product_id Product ID
 * @param int $order_id Order ID
 * @param float $price Price (passed from order to avoid extra query)
 * @return bool Success status
 */
function wpigo_update_product_sales($product_id, $order_id, $price = null) {
    try {
        // Get price from parameter or fallback to product meta
        if ($price === null) {
            $price = get_post_meta($product_id, 'product_price', true);
            $price = $price ? floatval($price) : 29;
        }

        // Get current sales count
        $sales_count = get_post_meta($product_id, '_product_sales_count', true);
        $sales_count = $sales_count ? intval($sales_count) : 0;

        // Increment sales count
        update_post_meta($product_id, '_product_sales_count', $sales_count + 1);

        // Update sales total
        $sales_total = get_post_meta($product_id, '_product_sales_total', true);
        $sales_total = $sales_total ? floatval($sales_total) : 0;
        update_post_meta($product_id, '_product_sales_total', $sales_total + $price);

        // Update buyers list (for author sales tracking - JSON format)
        $buyers = get_post_meta($product_id, '_product_buyers', true);
        if (!is_array($buyers)) {
            $buyers = array();
        }

        $user_id = get_post_meta($order_id, '_buyer_id', true);
        if (!isset($buyers[$user_id])) {
            $buyers[$user_id] = array();
        }

        $buyers[$user_id][] = array(
            'order_id' => $order_id,
            'date' => current_time('mysql'),
            'price' => $price,
        );

        update_post_meta($product_id, '_product_buyers', $buyers);

        return true;

    } catch (Exception $e) {
        error_log("Failed to update product sales for product {$product_id}: " . $e->getMessage());
        return false;
    }
}

/**
 * Update user purchase history (JSON format for purchased products)
 * 
 * @param int $user_id User ID
 * @param int $order_id Order ID
 * @param array $items Items purchased
 * @return bool Success status
 */
function wpigo_update_user_purchases($user_id, $order_id, $items) {
    try {
        // Skip user meta updates for guest orders (user_id = 0)
        if ($user_id == 0) {
            return true;
        }

        // Get current purchases (JSON format)
        $purchased = get_user_meta($user_id, 'wpigo_purchased_products', true);
        if (!is_array($purchased)) {
            $purchased = array();
        }

        // Calculate order total from items
        $order_total = 0;

        // Add new purchases
        foreach ($items as $item) {
            $product_id = $item['product_id'];
            $price = floatval($item['price']);
            $order_total += $price;

            if (!isset($purchased[$product_id])) {
                $purchased[$product_id] = array();
            }

            $purchased[$product_id][] = array(
                'order_id' => $order_id,
                'date' => current_time('mysql'),
                'price' => $price,
            );
        }

        // Update purchased products (JSON)
        update_user_meta($user_id, 'wpigo_purchased_products', $purchased);

        // Update total spent
        $total_spent = get_user_meta($user_id, 'wpigo_total_spent', true);
        $total_spent = $total_spent ? floatval($total_spent) : 0;
        update_user_meta($user_id, 'wpigo_total_spent', $total_spent + $order_total);

        // Update orders count
        $orders_count = get_user_meta($user_id, 'wpigo_orders_count', true);
        $orders_count = $orders_count ? intval($orders_count) : 0;
        update_user_meta($user_id, 'wpigo_orders_count', $orders_count + 1);

        return true;

    } catch (Exception $e) {
        error_log("Failed to update user purchases for user {$user_id}: " . $e->getMessage());
        return false;
    }
}

/**
 * Get user orders
 */
function wpigo_get_user_orders($user_id, $limit = -1) {
    $args = array(
        'post_type' => 'wpigo_order',
        'author' => $user_id,
        'posts_per_page' => $limit,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_status' => array('wc-completed', 'wc-pending', 'wc-cancelled'),
    );

    return get_posts($args);
}

/**
 * Get user purchased products
 */
function wpigo_get_user_purchased_products($user_id) {
    $purchased = get_user_meta($user_id, 'wpigo_purchased_products', true);

    if (!is_array($purchased) || empty($purchased)) {
        return array();
    }

    return array_keys($purchased);
}

/**
 * Check if user has purchased product
 */
function wpigo_user_has_purchased_product($user_id, $product_id) {
    $purchased = get_user_meta($user_id, 'wpigo_purchased_products', true);

    if (!is_array($purchased)) {
        return false;
    }

    return isset($purchased[$product_id]);
}

/**
 * Get user purchases with full details
 * Returns array of all purchases with order details, dates, prices
 */
function wpigo_get_user_purchases_detailed($user_id) {
    $purchased = get_user_meta($user_id, 'wpigo_purchased_products', true);

    if (!is_array($purchased) || empty($purchased)) {
        return array();
    }

    $detailed_purchases = array();

    foreach ($purchased as $product_id => $purchases) {
        // Check if product still exists
        $product = get_post($product_id);
        if (!$product || $product->post_status !== 'publish') {
            continue;
        }

        foreach ($purchases as $purchase) {
            $order_id = $purchase['order_id'];
            $order = get_post($order_id);

            if (!$order) {
                continue;
            }

            // Get license keys for this specific product from order items
            $order_items = get_post_meta($order_id, '_order_items', true);
            $license_keys = null;

            if (is_array($order_items)) {
                foreach ($order_items as $item) {
                    if (isset($item['product_id']) && $item['product_id'] == $product_id) {
                        if (isset($item['license_keys'])) {
                            $license_keys = $item['license_keys'];
                            break;
                        }
                    }
                }
            }

            // Fallback for old orders (before per-product license keys)
            if (!$license_keys) {
                $license_keys = array(
                    'purchase_code' => get_post_meta($order_id, '_purchase_code', true),
                    'api_key' => get_post_meta($order_id, '_api_key', true),
                    'secret_key' => get_post_meta($order_id, '_secret_key', true),
                );
            }

            $detailed_purchases[] = array(
                'product_id' => $product_id,
                'product_title' => $product->post_title,
                'product_thumbnail' => get_the_post_thumbnail_url($product_id, 'product-thumbnail'),
                'product_url' => get_permalink($product_id),
                'order_id' => $order_id,
                'order_number' => get_post_meta($order_id, '_order_number', true),
                'purchase_date' => $purchase['date'],
                'price_paid' => $purchase['price'],
                'order_status' => $order->post_status,
                'license_keys' => $license_keys,
                'support_period' => get_post_meta($product_id, '_support_period', true),
                'updates_period' => get_post_meta($product_id, '_updates_period', true),
                'update_extension_price' => get_post_meta($product_id, '_update_extension_price', true),
                'response_time' => get_post_meta($product_id, '_response_time', true),
            );
        }
    }

    // Sort by purchase date (newest first)
    usort($detailed_purchases, function($a, $b) {
        return strtotime($b['purchase_date']) - strtotime($a['purchase_date']);
    });

    return $detailed_purchases;
}

/**
 * Get author's product sales with customer details
 * Returns array of all sales for author's products
 */

/**
 * AJAX handler for creating order
 */
function wpigo_ajax_create_order() {
    // Verify nonce
    if (!check_ajax_referer('wpigo_checkout_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => 'Security check failed'));
    }

    // Get form data
    $card_number = sanitize_text_field($_POST['card_number'] ?? '');
    $card_name = sanitize_text_field($_POST['card_name'] ?? '');
    $card_expiry = sanitize_text_field($_POST['card_expiry'] ?? '');
    $card_cvc = sanitize_text_field($_POST['card_cvc'] ?? '');
    $product_ids = isset($_POST['product_ids']) ? array_map('intval', $_POST['product_ids']) : array();

    // Guest checkout data
    $billing_email = sanitize_email($_POST['billing_email'] ?? '');
    $billing_name = sanitize_text_field($_POST['billing_name'] ?? '');
    $create_account = isset($_POST['create_account']) ? intval($_POST['create_account']) : 0;

    // Determine if guest or logged in
    $is_guest = !is_user_logged_in();
    $user_id = 0;
    $user_email = '';
    $buyer_name = $card_name;

    if ($is_guest) {
        // Guest checkout - validate billing info
        if (empty($billing_email) || !is_email($billing_email)) {
            wp_send_json_error(array('message' => 'Please provide a valid email address'));
        }

        if (empty($billing_name)) {
            wp_send_json_error(array('message' => 'Please provide your full name'));
        }

        // Check if email already exists
        $existing_user = get_user_by('email', $billing_email);

        if ($existing_user) {
            // Email exists - don't create account, just use for order
            $user_id = $existing_user->ID;
            $user_email = $billing_email;
        } elseif ($create_account) {
            // Create new user account
            $new_user_id = wpigo_auto_register_guest($billing_email, $billing_name);

            if (is_wp_error($new_user_id)) {
                wp_send_json_error(array('message' => 'Failed to create account: ' . $new_user_id->get_error_message()));
            }

            $user_id = $new_user_id;
            $user_email = $billing_email;

            // Auto-login the newly created user
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, true);
            do_action('wp_login', get_userdata($user_id)->user_login, get_userdata($user_id));
        } else {
            // Guest without account - use email only
            $user_id = 0;
            $user_email = $billing_email;
        }

        $buyer_name = $billing_name;

    } else {
        // Logged in user
        $user_id = get_current_user_id();
        $user = get_userdata($user_id);
        $user_email = $user->user_email;
        $buyer_name = $card_name;
    }

    // Validate
    if (empty($card_number) || empty($card_name) || empty($card_expiry) || empty($card_cvc)) {
        wp_send_json_error(array('message' => 'Please fill in all payment fields'));
    }

    if (empty($product_ids)) {
        wp_send_json_error(array('message' => 'No products to purchase'));
    }

    // Prepare order items
    $items = array();
    $total = 0;

    foreach ($product_ids as $product_id) {
        $product = get_post($product_id);
        if (!$product || $product->post_status !== 'publish') {
            continue;
        }

        $price = get_post_meta($product_id, 'product_price', true);
        $price = $price ? floatval($price) : 29;

        $product_slug = get_post_meta($product_id, '_product_slug', true);

        $items[] = array(
            'product_id' => $product_id,
            'title' => $product->post_title,
            'price' => $price,
            'product_slug' => $product_slug,  // License validation identifier
        );

        $total += $price;
    }

    if (empty($items)) {
        wp_send_json_error(array('message' => 'Invalid products'));
    }

    // Detect card brand (simple detection)
    $card_brand = 'Unknown';
    if (preg_match('/^4/', $card_number)) {
        $card_brand = 'Visa';
    } elseif (preg_match('/^5[1-5]/', $card_number)) {
        $card_brand = 'Mastercard';
    } elseif (preg_match('/^3[47]/', $card_number)) {
        $card_brand = 'Amex';
    }

    // Create order
    $order_data = array(
        'buyer_id' => $user_id,
        'buyer_email' => $user_email,
        'buyer_name' => $buyer_name,
        'items' => $items,
        'total' => $total,
        'payment_method' => 'Credit Card (Test Mode)',
        'card_last4' => substr($card_number, -4),
        'card_brand' => $card_brand,
    );

    $order_id = wpigo_create_order($order_data);

    if (!$order_id) {
        wp_send_json_error(array('message' => 'Failed to create order'));
    }

    // Clear cart
    wpigo_clear_cart();

    // Get order confirmation URL
    $confirmation_url = add_query_arg('order_id', $order_id, home_url('/order-confirmation/'));

    wp_send_json_success(array(
        'message' => 'Order completed successfully!',
        'order_id' => $order_id,
        'redirect_url' => $confirmation_url,
    ));
}
add_action('wp_ajax_wpigo_create_order', 'wpigo_ajax_create_order');
add_action('wp_ajax_nopriv_wpigo_create_order', 'wpigo_ajax_create_order');

/**
 * Auto-register guest user during checkout
 */
function wpigo_auto_register_guest($email, $full_name) {
    // Generate username from email
    $username = sanitize_user(substr($email, 0, strpos($email, '@')));

    // Make username unique if already exists
    $base_username = $username;
    $counter = 1;
    while (username_exists($username)) {
        $username = $base_username . $counter;
        $counter++;
    }

    // Generate random password
    $password = wp_generate_password(12, true, true);

    // Create user
    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        return $user_id;
    }

    // Update user meta with full name
    $name_parts = explode(' ', $full_name, 2);
    $first_name = $name_parts[0];
    $last_name = isset($name_parts[1]) ? $name_parts[1] : '';

    wp_update_user(array(
        'ID' => $user_id,
        'display_name' => $full_name,
        'first_name' => $first_name,
        'last_name' => $last_name,
    ));

    // Send welcome email with login credentials
    $subject = 'Welcome to ' . get_bloginfo('name') . ' - Your Account Details';

    $message = "Hello {$full_name},\n\n";
    $message .= "Thank you for your purchase! An account has been created for you to manage your purchases and license keys.\n\n";
    $message .= "Your Login Details:\n";
    $message .= "Username: {$username}\n";
    $message .= "Email: {$email}\n";
    $message .= "Password: {$password}\n\n";
    $message .= "Login URL: " . wp_login_url() . "\n\n";
    $message .= "You can view your purchases and license keys by logging in to your account.\n\n";
    $message .= "Best regards,\n";
    $message .= get_bloginfo('name');

    wp_mail($email, $subject, $message);

    return $user_id;
}


/**
 * Add admin sales menu with submenus
 */
function wpigo_add_admin_sales_menu() {
    // Main menu: WPiGo Sales
    add_menu_page(
        'WPiGo Sales',
        'WPiGo Sales',
        'manage_options',
        'wpigo-sales',
        'wpigo_render_sales_dashboard',
        'dashicons-chart-line',
        30
    );

    // Submenu 1: Dashboard (default)
    add_submenu_page(
        'wpigo-sales',
        'Sales Dashboard',
        'Dashboard',
        'manage_options',
        'wpigo-sales',
        'wpigo_render_sales_dashboard'
    );

    // Submenu 2: All Orders
    add_submenu_page(
        'wpigo-sales',
        'All Orders',
        'All Orders',
        'manage_options',
        'wpigo-orders',
        'wpigo_render_orders_page'
    );
}
add_action('admin_menu', 'wpigo_add_admin_sales_menu');

/**
 * Get ALL product sales (admin version - not author-specific)
 */
function wpigo_get_all_product_sales($product_filter = 0) {
    $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
    );

    if ($product_filter > 0) {
        $args['post__in'] = array($product_filter);
    }

    $product_ids = get_posts($args);

    if (empty($product_ids)) {
        return array();
    }

    $all_sales = array();

    foreach ($product_ids as $product_id) {
        $product = get_post($product_id);
        $buyers = get_post_meta($product_id, '_product_buyers', true);

        if (!is_array($buyers) || empty($buyers)) {
            continue;
        }

        foreach ($buyers as $buyer_id => $purchases) {
            $buyer = get_userdata($buyer_id);

            if (!$buyer) {
                continue;
            }

            foreach ($purchases as $purchase) {
                $order_id = $purchase['order_id'];
                $order = get_post($order_id);

                if (!$order || $order->post_status !== 'wc-completed') {
                    continue;
                }

                // Get license keys
                $order_items = get_post_meta($order_id, '_order_items', true);
                $license_keys = null;

                if (is_array($order_items)) {
                    foreach ($order_items as $item) {
                        if (isset($item['product_id']) && $item['product_id'] == $product_id) {
                            if (isset($item['license_keys'])) {
                                $license_keys = $item['license_keys'];
                                break;
                            }
                        }
                    }
                }

                $order_number = get_post_meta($order_id, '_order_number', true);
                $buyer_email = get_post_meta($order_id, '_buyer_email', true);
                $buyer_name = get_post_meta($order_id, '_buyer_name', true);

                $all_sales[] = array(
                    'product_id' => $product_id,
                    'product_title' => $product->post_title,
                    'product_url' => get_permalink($product_id),
                    'order_id' => $order_id,
                    'order_number' => $order_number,
                    'buyer_id' => $buyer_id,
                    'buyer_name' => $buyer_name,
                    'buyer_email' => $buyer_email,
                    'buyer_username' => $buyer->user_login,
                    'purchase_date' => $purchase['date'],
                    'price' => $purchase['price'],
                    'license_keys' => $license_keys,
                );
            }
        }
    }

    // Sort by date (newest first)
    usort($all_sales, function($a, $b) {
        return strtotime($b['purchase_date']) - strtotime($a['purchase_date']);
    });

    return $all_sales;
}

/**
 * Render Sales Dashboard (Admin Panel)
 */
function wpigo_render_sales_dashboard() {
    // Check permissions
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    // Get filter
    $product_filter = isset($_GET['product']) ? intval($_GET['product']) : 0;

    // Get ALL products (not author-specific)
    $all_products = get_posts(array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ));

    // Get ALL sales (not author-specific)
    $all_sales = wpigo_get_all_product_sales($product_filter);

    // Calculate statistics
    $total_sales = count($all_sales);
    $total_revenue = 0;
    $unique_customers = array();
    $product_stats = array(); // Per-product breakdown

    foreach ($all_sales as $sale) {
        $total_revenue += $sale['price'];

        if (!in_array($sale['buyer_id'], $unique_customers)) {
            $unique_customers[] = $sale['buyer_id'];
        }

        // Product stats
        $pid = $sale['product_id'];
        if (!isset($product_stats[$pid])) {
            $product_stats[$pid] = array(
                'title' => $sale['product_title'],
                'sales_count' => 0,
                'revenue' => 0,
                'customers' => array()
            );
        }
        $product_stats[$pid]['sales_count']++;
        $product_stats[$pid]['revenue'] += $sale['price'];
        $product_stats[$pid]['customers'][] = $sale['buyer_id'];
    }

    // Check if admin template exists, otherwise use inline HTML
    $template_path = get_template_directory() . '/admin/sales-dashboard.php';

    if (file_exists($template_path)) {
        include($template_path);
    } else {
        // Inline template (fallback)
        wpigo_render_sales_dashboard_inline($all_products, $all_sales, $total_sales, $total_revenue, $unique_customers, $product_stats, $product_filter);
    }
}

/**
 * Inline Sales Dashboard Template (fallback if file doesn't exist)
 */
function wpigo_render_sales_dashboard_inline($all_products, $all_sales, $total_sales, $total_revenue, $unique_customers, $product_stats, $product_filter) {
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"> Sales Dashboard</h1>
        <hr class="wp-header-end">

        <!-- Statistics Cards -->
        <div class="wpigo-admin-stats-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;">

            <!-- Total Sales -->
            <div class="wpigo-stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #0073aa; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <div style="font-size: 36px; font-weight: bold; color: #0073aa;">
                    <?php echo number_format($total_sales); ?>
                </div>
                <div style="color: #666; margin-top: 5px;">📦 Total Sales</div>
            </div>

            <!-- Total Revenue -->
            <div class="wpigo-stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #46b450; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <div style="font-size: 36px; font-weight: bold; color: #46b450;">
                    $<?php echo number_format($total_revenue, 2); ?>
                </div>
                <div style="color: #666; margin-top: 5px;">💵 Total Revenue</div>
            </div>

            <!-- Unique Customers -->
            <div class="wpigo-stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #f56e28; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <div style="font-size: 36px; font-weight: bold; color: #f56e28;">
                    <?php echo count($unique_customers); ?>
                </div>
                <div style="color: #666; margin-top: 5px;"> Unique Customers</div>
            </div>

            <!-- Total Products -->
            <div class="wpigo-stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #826eb4; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <div style="font-size: 36px; font-weight: bold; color: #826eb4;">
                    <?php echo count($all_products); ?>
                </div>
                <div style="color: #666; margin-top: 5px;">🎯 Total Products</div>
            </div>

        </div>

        <!-- Filter Section -->
        <?php if (!empty($all_products)) : ?>
        <div class="tablenav top">
            <form method="get" action="" style="display: inline-block;">
                <input type="hidden" name="page" value="wpigo-sales">
                <label for="product-filter" style="margin-right: 10px;">Filter by Product:</label>
                <select name="product" id="product-filter" style="width: 300px;">
                    <option value="0">All Products</option>
                    <?php foreach ($all_products as $product) : ?>
                        <option value="<?php echo $product->ID; ?>" <?php selected($product_filter, $product->ID); ?> >
                            <?php echo esc_html($product->post_title); ?>
                            (<?php
                            $sales_count = get_post_meta($product->ID, '_product_sales_count', true);
                            echo $sales_count ? $sales_count : 0;
                            ?> sales)
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="button">Filter</button>
                <?php if ($product_filter) : ?>
                    <a href="?page=wpigo-sales" class="button">Reset</a>
                <?php endif; ?>
            </form>
        </div>
        <?php endif; ?>

        <!-- Product Breakdown Table -->
        <?php if (!empty($product_stats)) : ?>
        <h2>📊 Product Sales Breakdown</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Sales Count</th>
                    <th>Revenue</th>
                    <th>Unique Customers</th>
                    <th>Avg. Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($product_stats as $pid => $stats) : ?>
                    <tr>
                        <td>
                            <strong>
                                <a href="<?php echo get_edit_post_link($pid); ?>" target="_blank">
                                    <?php echo esc_html($stats['title']); ?>
                                </a>
                            </strong>
                        </td>
                        <td><?php echo $stats['sales_count']; ?></td>
                        <td><strong>$<?php echo number_format($stats['revenue'], 2); ?></strong></td>
                        <td><?php echo count(array_unique($stats['customers'])); ?></td>
                        <td>$<?php echo number_format($stats['revenue'] / $stats['sales_count'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <!-- Recent Sales List -->
        <?php if (!empty($all_sales)) : ?>
        <h2 style="margin-top: 40px;">📋 Recent Sales (<?php echo count($all_sales); ?> total)</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Date</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Show only first 50 for performance
                $recent_sales = array_slice($all_sales, 0, 50);
                foreach ($recent_sales as $sale) :
                ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html($sale['order_number']); ?></strong>
                        </td>
                        <td>
                            <strong><?php echo esc_html($sale['buyer_name']); ?></strong><br>
                            <small><?php echo esc_html($sale['buyer_email']); ?></small>
                        </td>
                        <td>
                            <a href="<?php echo esc_url($sale['product_url']); ?>" target="_blank">
                                <?php echo esc_html($sale['product_title']); ?>
                            </a>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($sale['purchase_date'])); ?></td>
                        <td><strong>$<?php echo number_format($sale['price'], 2); ?></strong></td>
                        <td>
                            <a href="<?php echo admin_url('post.php?post=' . $sale['order_id'] . '&action=edit'); ?>" class="button button-small">
                                View Order
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if (count($all_sales) > 50) : ?>
        <p style="margin-top: 20px;">
            <em>Showing first 50 sales. Total: <?php echo count($all_sales); ?> sales.</em>
        </p>
        <?php endif; ?>

        <?php else : ?>
        <div class="notice notice-info" style="margin-top: 40px;">
            <p><strong>No sales yet.</strong> When customers purchase products, they will appear here.</p>
        </div>
        <?php endif; ?>

    </div>
    <?php
    wp_reset_postdata();
}

/**
 * Render orders admin page
 */
function wpigo_render_orders_page() {
    // Get filter parameters
    $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    // Build query args
    $args = array(
        'post_type' => 'wpigo_order',
        'posts_per_page' => 20,
        'paged' => isset($_GET['paged']) ? intval($_GET['paged']) : 1,
        'orderby' => 'date',
        'order' => 'DESC',
    );

    if ($status_filter) {
        $args['post_status'] = 'wc-' . $status_filter;
    } else {
        $args['post_status'] = array('wc-completed', 'wc-pending', 'wc-cancelled');
    }

    if ($search) {
        $args['s'] = $search;
    }

    $orders_query = new WP_Query($args);

    // Get statistics
    $total_orders = wp_count_posts('wpigo_order');
    $total_completed = isset($total_orders->{'wc-completed'}) ? $total_orders->{'wc-completed'} : 0;
    $total_pending = isset($total_orders->{'wc-pending'}) ? $total_orders->{'wc-pending'} : 0;

    // Calculate total revenue
    $all_orders = get_posts(array(
        'post_type' => 'wpigo_order',
        'post_status' => 'wc-completed',
        'posts_per_page' => -1,
        'fields' => 'ids',
    ));

    $total_revenue = 0;
    foreach ($all_orders as $order_id) {
        $order_total = get_post_meta($order_id, '_order_total', true);
        $total_revenue += floatval($order_total);
    }

    // Get unique customers count
    $customers = array();
    foreach ($all_orders as $order_id) {
        $buyer_id = get_post_meta($order_id, '_buyer_id', true);
        if ($buyer_id && !in_array($buyer_id, $customers)) {
            $customers[] = $buyer_id;
        }
    }
    $total_customers = count($customers);

    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">WPiGo Orders</h1>
        <hr class="wp-header-end">

        <!-- Statistics -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <div style="font-size: 32px; font-weight: 600; color: #27ae60;"><?php echo $total_completed; ?></div>
                <div style="color: #666; font-size: 13px;">Total Sales</div>
            </div>
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <div style="font-size: 32px; font-weight: 600; color: #3498db;">$<?php echo number_format($total_revenue, 2); ?></div>
                <div style="color: #666; font-size: 13px;">Total Revenue</div>
            </div>
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <div style="font-size: 32px; font-weight: 600; color: #e67e22;"><?php echo $total_customers; ?></div>
                <div style="color: #666; font-size: 13px;">Total Customers</div>
            </div>
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <div style="font-size: 32px; font-weight: 600; color: #f39c12;"><?php echo $total_pending; ?></div>
                <div style="color: #666; font-size: 13px;">Pending Orders</div>
            </div>
        </div>

        <!-- Filters -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="wpigo-orders">

                    <select name="status" id="status-filter">
                        <option value="">All Statuses</option>
                        <option value="completed" <?php selected($status_filter, 'completed'); ?>>Completed</option>
                        <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
                        <option value="cancelled" <?php selected($status_filter, 'cancelled'); ?>>Cancelled</option>
                    </select>

                    <input type="submit" class="button" value="Filter">

                    <?php if ($status_filter) : ?>
                        <a href="<?php echo admin_url('admin.php?page=wpigo-orders'); ?>" class="button">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $orders_query->max_num_pages,
                    'current' => $args['paged']
                ));
                ?>
            </div>
        </div>

        <!-- Orders Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 80px;">Order ID</th>
                    <th style="width: 150px;">Date</th>
                    <th>Customer</th>
                    <th>Products</th>
                    <th style="width: 100px;">Total</th>
                    <th style="width: 100px;">Status</th>
                    <th style="width: 100px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($orders_query->have_posts()) : ?>
                    <?php while ($orders_query->have_posts()) : $orders_query->the_post(); ?>
                        <?php
                        $order_id = get_the_ID();
                        $order_number = get_post_meta($order_id, '_order_number', true);
                        $buyer_id = get_post_meta($order_id, '_buyer_id', true);
                        $buyer_email = get_post_meta($order_id, '_buyer_email', true);
                        $buyer_name = get_post_meta($order_id, '_buyer_name', true);
                        $order_total = get_post_meta($order_id, '_order_total', true);
                        $order_items = get_post_meta($order_id, '_order_items', true);
                        $order_status = get_post_status();

                        $status_label = '';
                        $status_color = '';
                        if ($order_status === 'wc-completed') {
                            $status_label = 'Completed';
                            $status_color = '#27ae60';
                        } elseif ($order_status === 'wc-pending') {
                            $status_label = 'Pending';
                            $status_color = '#f39c12';
                        } elseif ($order_status === 'wc-cancelled') {
                            $status_label = 'Cancelled';
                            $status_color = '#e74c3c';
                        }

                        $product_titles = array();
                        if (is_array($order_items)) {
                            foreach ($order_items as $item) {
                                $product_titles[] = $item['title'];
                            }
                        }
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html($order_number); ?></strong></td>
                            <td><?php echo get_the_date('M j, Y'); ?><br><small><?php echo get_the_date('g:i a'); ?></small></td>
                            <td>
                                <strong><?php echo esc_html($buyer_name); ?></strong><br>
                                <small><?php echo esc_html($buyer_email); ?></small>
                            </td>
                            <td><?php echo esc_html(implode(', ', $product_titles)); ?></td>
                            <td><strong>$<?php echo number_format($order_total, 2); ?></strong></td>
                            <td>
                                <span style="display: inline-block; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; color: #fff; background: <?php echo $status_color; ?>;">
                                    <?php echo $status_label; ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo admin_url('post.php?post=' . $order_id . '&action=edit'); ?>" class="button button-small">View</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">
                            <p style="color: #666;">No orders found.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Bottom Pagination -->
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $orders_query->max_num_pages,
                    'current' => $args['paged']
                ));
                ?>
            </div>
        </div>

    </div>
    <?php
    wp_reset_postdata();
}

/**
 * Add meta boxes for wpigo_order custom post type
 */
function wpigo_add_order_meta_boxes() {
    add_meta_box(
        'wpigo_order_details',
        'Order Details',
        'wpigo_order_details_meta_box',
        'wpigo_order',
        'normal',
        'high'
    );

    add_meta_box(
        'wpigo_order_items',
        'Order Items & License Keys',
        'wpigo_order_items_meta_box',
        'wpigo_order',
        'normal',
        'high'
    );

    add_meta_box(
        'wpigo_order_customer',
        'Customer Information',
        'wpigo_order_customer_meta_box',
        'wpigo_order',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'wpigo_add_order_meta_boxes');

/**
 * Order Details Meta Box
 */
function wpigo_order_details_meta_box($post) {
    $order_number = get_post_meta($post->ID, '_order_number', true);
    $order_total = get_post_meta($post->ID, '_order_total', true);
    $order_status = get_post_status($post->ID);
    $payment_method = get_post_meta($post->ID, '_payment_method', true);
    $card_brand = get_post_meta($post->ID, '_card_brand', true);
    $card_last4 = get_post_meta($post->ID, '_card_last4', true);
    $order_ip = get_post_meta($post->ID, '_order_ip', true);

    $status_labels = array(
        'wc-completed' => 'Completed',
        'wc-pending' => 'Pending',
        'wc-cancelled' => 'Cancelled'
    );
    ?>
    <table class="form-table">
        <tr>
            <th><strong>Order Number:</strong></th>
            <td><?php echo esc_html($order_number); ?></td>
        </tr>
        <tr>
            <th><strong>Order Date:</strong></th>
            <td><?php echo get_the_date('F j, Y g:i A', $post->ID); ?></td>
        </tr>
        <tr>
            <th><strong>Order Total:</strong></th>
            <td><strong style="font-size: 18px; color: #27ae60;">$<?php echo number_format($order_total, 2); ?></strong></td>
        </tr>
        <tr>
            <th><strong>Status:</strong></th>
            <td>
                <span style="padding: 5px 10px; border-radius: 3px; color: #fff; background: <?php echo $order_status === 'wc-completed' ? '#27ae60' : ($order_status === 'wc-pending' ? '#f39c12' : '#e74c3c'); ?>;">
                    <?php echo isset($status_labels[$order_status]) ? $status_labels[$order_status] : $order_status; ?>
                </span>
            </td>
        </tr>
        <tr>
            <th><strong>Payment Method:</strong></th>
            <td><?php echo esc_html($payment_method); ?></td>
        </tr>
        <?php if ($card_brand && $card_last4) : ?>
        <tr>
            <th><strong>Card:</strong></th>
            <td><?php echo esc_html($card_brand); ?> ending in <?php echo esc_html($card_last4); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <th><strong>Customer IP:</strong></th>
            <td><?php echo esc_html($order_ip); ?></td>
        </tr>
    </table>
    <?php
}

/**
 * Order Items & License Keys Meta Box
 */
function wpigo_order_items_meta_box($post) {
    $order_items = get_post_meta($post->ID, '_order_items', true);

    if (!is_array($order_items) || empty($order_items)) {
        echo '<p>No items found in this order.</p>';
        return;
    }

    foreach ($order_items as $index => $item) {
        $product_id = isset($item['product_id']) ? $item['product_id'] : 0;
        $product_title = isset($item['title']) ? $item['title'] : 'Unknown Product';
        $product_price = isset($item['price']) ? $item['price'] : 0;
        $license_keys = isset($item['license_keys']) ? $item['license_keys'] : array();

        ?>
        <div style="padding: 15px; margin-bottom: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
            <h4 style="margin: 0 0 10px 0; padding-bottom: 10px; border-bottom: 2px solid #0073aa;">
                <?php echo esc_html($product_title); ?>
            </h4>

            <table class="form-table">
                <tr>
                    <th style="width: 200px;"><strong>Product ID:</strong></th>
                    <td>
                        <?php if ($product_id && get_post($product_id)) : ?>
                            <a href="<?php echo get_edit_post_link($product_id); ?>" target="_blank">
                                #<?php echo $product_id; ?> - View Product
                            </a>
                        <?php else : ?>
                            #<?php echo $product_id; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th><strong>Price:</strong></th>
                    <td><strong>$<?php echo number_format($product_price, 2); ?></strong></td>
                </tr>
            </table>

            <?php if (!empty($license_keys)) : ?>
                <h5 style="margin: 15px 0 10px 0; color: #0073aa;">🔑 License Keys:</h5>
                <table class="form-table">
                    <tr>
                        <th style="width: 200px;"><strong>Purchase Code:</strong></th>
                        <td>
                            <input type="text" value="<?php echo esc_attr($license_keys['purchase_code']); ?>" readonly style="width: 100%; font-family: monospace; background: #fff; padding: 5px;">
                        </td>
                    </tr>
                    <tr>
                        <th><strong>API Key:</strong></th>
                        <td>
                            <input type="text" value="<?php echo esc_attr($license_keys['api_key']); ?>" readonly style="width: 100%; font-family: monospace; background: #fff; padding: 5px;">
                        </td>
                    </tr>
                    <tr>
                        <th><strong>Secret Key:</strong></th>
                        <td>
                            <input type="text" value="<?php echo esc_attr($license_keys['secret_key']); ?>" readonly style="width: 100%; font-family: monospace; background: #fff; padding: 5px;">
                        </td>
                    </tr>
                </table>
            <?php else : ?>
                <p style="color: #e74c3c;"><em>No license keys found for this product.</em></p>
            <?php endif; ?>
        </div>
        <?php
    }
}

/**
 * Customer Information Meta Box
 */
function wpigo_order_customer_meta_box($post) {
    $buyer_id = get_post_meta($post->ID, '_buyer_id', true);
    $buyer_email = get_post_meta($post->ID, '_buyer_email', true);
    $buyer_name = get_post_meta($post->ID, '_buyer_name', true);

    ?>
    <table class="form-table">
        <tr>
            <th><strong>Customer ID:</strong></th>
            <td>
                <?php if ($buyer_id) : ?>
                    <a href="<?php echo get_edit_user_link($buyer_id); ?>" target="_blank">
                        #<?php echo $buyer_id; ?>
                    </a>
                <?php else : ?>
                    N/A
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th><strong>Name:</strong></th>
            <td><?php echo esc_html($buyer_name); ?></td>
        </tr>
        <tr>
            <th><strong>Email:</strong></th>
            <td><a href="mailto:<?php echo esc_attr($buyer_email); ?>"><?php echo esc_html($buyer_email); ?></a></td>
        </tr>
    </table>
    <?php
}

// ============================================================================ 
// SECURE DOWNLOAD SYSTEM
// ============================================================================ 

/**
 * Add custom rewrite rule for secure downloads
 * URL Format: /download/WPIGO-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
 */
function wpigo_add_download_rewrite_rules() {
    add_rewrite_rule(
        '^download/([A-Za-z0-9-]+)/?$',
        'index.php?wpigo_download=1&purchase_code=$matches[1]',
        'top'
    );
}
add_action('init', 'wpigo_add_download_rewrite_rules');

/**
 * Add custom query vars for download system
 */
function wpigo_add_download_query_vars($vars) {
    $vars[] = 'wpigo_download';
    $vars[] = 'purchase_code';
    return $vars;
}
add_filter('query_vars', 'wpigo_add_download_query_vars');

/**
 * Handle secure download requests
 */
function wpigo_handle_download_request() {
    if (get_query_var('wpigo_download')) {
        $purchase_code = sanitize_text_field(get_query_var('purchase_code'));

        // Validate purchase code format
        if (!preg_match('/^WPIGO-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $purchase_code)) {
            wp_die('Invalid purchase code format.', 'Invalid Purchase Code', array('response' => 400));
        }

        // 1. User must be logged in
        if (!is_user_logged_in()) {
            $redirect_url = add_query_arg('redirect_to', urlencode(home_url('/download/' . $purchase_code)), wp_login_url());
            wp_redirect($redirect_url);
            exit;
        }

        $current_user_id = get_current_user_id();

        // 2. Find order and product by purchase code
        $purchase_data = wpigo_find_purchase_by_code($purchase_code);

        if (!$purchase_data) {
            wp_die(
                'Purchase code not found in our system. Please contact support if you believe this is an error.',
                'Purchase Not Found',
                array('response' => 404)
            );
        }

        $order_id = $purchase_data['order_id'];
        $product_id = $purchase_data['product_id'];

        // 3. Verify order exists and is valid
        $order = get_post($order_id);
        if (!$order || $order->post_type !== 'wpigo_order') {
            wp_die('Invalid order.', 'Order Error', array('response' => 400));
        }

        // 4. Verify ownership - this purchase belongs to current user
        $order_buyer_id = intval(get_post_meta($order_id, '_buyer_id', true));
        if ($order_buyer_id !== $current_user_id) {
            wp_die(
                'You do not have permission to download this file. This purchase belongs to a different account.',
                'Access Denied',
                array('response' => 403)
            );
        }

        // 5. Get product and verify it exists
        $product = get_post($product_id);
        if (!$product || $product->post_status !== 'publish') {
            wp_die('Product not found or no longer available.', 'Product Error', array('response' => 404));
        }

        // 6. Get product file URL
        $file_url = get_post_meta($product_id, '_product_file', true);
        if (!$file_url) {
            wp_die(
                'Product file not found. Please contact the author for support.',
                'File Not Found',
                array('response' => 404)
            );
        }

        // 7. Download the file securely
        wpigo_secure_file_download($file_url, $product_id, $product->post_title);
        exit;
    }
}
add_action('template_redirect', 'wpigo_handle_download_request');

/**
 * Find order and product by purchase code
 * Fast lookup using indexed _purchase_code meta key
 * 
 * @param string $purchase_code The purchase code to search for
 * @return array|false Array with order_id and product_id, or false if not found
 */
function wpigo_find_purchase_by_code($purchase_code) {
    global $wpdb;

    // Search in indexed _purchase_code meta (super fast with INDEX)
    $order_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id
        FROM {$wpdb->postmeta}
        WHERE meta_key = '_purchase_code'
        AND meta_value = %s
        LIMIT 1
    ", $purchase_code));

    if (!$order_id) {
        return false;
    }

    // Get order data from JSON
    $order_data = get_post_meta($order_id, '_order_data', true);

    if (!is_array($order_data) || !isset($order_data['items'])) {
        return false;
    }

    // Find the product_id for this purchase code
    foreach ($order_data['items'] as $item) {
        if (isset($item['license_keys']['purchase_code']) &&
            $item['license_keys']['purchase_code'] === $purchase_code) {

            return array(
                'order_id' => $order_id,
                'product_id' => $item['product_id']
            );
        }
    }

    return false;
}

/**
 * Securely download file through PHP (prevents direct file access)
 * 
 * @param string $file_url The URL of the file to download
 * @param int $product_id The product ID
 * @param string $product_title The product title for filename
 */
function wpigo_secure_file_download($file_url, $product_id, $product_title) {
    // Convert URL to file path
    $upload_dir = wp_upload_dir();
    $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file_url);

    // Security: Ensure file is within uploads directory
    $real_file_path = realpath($file_path);
    $real_upload_dir = realpath($upload_dir['basedir']);

    if ($real_file_path === false || strpos($real_file_path, $real_upload_dir) !== 0) {
        wp_die('Invalid file path.', 'Security Error', array('response' => 403));
    }

    // Check if file exists
    if (!file_exists($real_file_path)) {
        wp_die(
            'File not found on server. Please contact the author for support.',
            'File Not Found',
            array('response' => 404)
        );
    }

    // Get file info
    $file_size = filesize($real_file_path);
    $file_extension = pathinfo($real_file_path, PATHINFO_EXTENSION);

    // Generate clean filename
    $clean_title = sanitize_file_name($product_title);
    $filename = $clean_title . '.' . $file_extension;

    // Clear any previous output
    if (ob_get_level()) {
        ob_end_clean();
    }

    // Set headers for download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . $file_size);
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Content-Transfer-Encoding: binary');

    // Disable execution time limit for large files
    set_time_limit(0);

    // Read and output file in chunks (memory efficient for large files)
    $handle = fopen($real_file_path, 'rb');
    if ($handle === false) {
        wp_die('Could not open file for reading.', 'File Error', array('response' => 500));
    }

    while (!feof($handle)) {
        echo fread($handle, 8192); // 8KB chunks
        flush();
    }

    fclose($handle);
    exit;
}

// ============================================================================ 
// PRODUCT FILE UPLOAD META BOX
// ============================================================================ 

/**
 * Add product file upload meta box to post editor
 */
function wpigo_add_product_file_meta_box() {
    add_meta_box(
        'wpigo_product_file',
        '&#128230; Product Download File',
        'wpigo_product_file_meta_box_callback',
        'post',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'wpigo_add_product_file_meta_box');

/**
 * Render product file upload meta box
 */
function wpigo_product_file_meta_box_callback($post) {
    // Add nonce for security
    wp_nonce_field('wpigo_product_file_meta_box', 'wpigo_product_file_nonce');

    // Get current file URL
    $file_url = get_post_meta($post->ID, '_product_file', true);
    $file_id = get_post_meta($post->ID, '_product_file_id', true);

    ?>
    <div class="wpigo-product-file-upload">
        <p style="margin-bottom: 10px; font-size: 13px; color: #666;">
            <strong>Upload your product file (.zip)</strong><br>
            This file will be available for download after purchase.
        </p>

        <div id="wpigo-product-file-preview" style="margin-bottom: 10px;">
            <?php if ($file_url) : ?>
                <?php
                $file_name = basename($file_url);
                $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $file_url);
                $file_size = file_exists($file_path) ? size_format(filesize($file_path), 2) : 'Unknown';
                ?>
                <div style="padding: 10px; background: #f0f0f1; border: 1px solid #c3c4c7; border-radius: 4px;">
                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 5px;">
                        <span style="font-size: 20px;">&#128230;</span>
                        <strong style="font-size: 13px;"><?php echo esc_html($file_name); ?></strong>
                    </div>
                    <div style="font-size: 12px; color: #666;">
                        Size: <?php echo esc_html($file_size); ?>
                    </div>
                    <div style="margin-top: 8px;">
                        <a href="<?php echo esc_url($file_url); ?>" target="_blank" class="button button-small">
                            &#128065; View File
                        </a>
                    </div>
                </div>
            <?php else : ?>
                <div style="padding: 15px; text-align: center; background: #f9f9f9; border: 2px dashed #ddd; border-radius: 4px;">
                    <span style="font-size: 32px; opacity: 0.5;">&#128230;</span>
                    <p style="margin: 8px 0 0; font-size: 12px; color: #666;">No file uploaded yet</p>
                </div>
            <?php endif; ?>
        </div>

        <input type="hidden" id="wpigo_product_file_id" name="wpigo_product_file_id" value="<?php echo esc_attr($file_id); ?>">
        <input type="hidden" id="wpigo_product_file_url" name="wpigo_product_file_url" value="<?php echo esc_url($file_url); ?>">

        <div style="display: flex; gap: 5px;">
            <button type="button" class="button button-primary button-large" id="wpigo_upload_product_file_button" style="flex: 1;">
                <?php echo $file_url ? '&#128260; Change File' : '&#11014; Upload File'; ?>
            </button>
            <?php if ($file_url) : ?>
                <button type="button" class="button button-secondary" id="wpigo_remove_product_file_button" style="color: #b32d2e;">
                    &#128465; Remove
                </button>
            <?php endif; ?>
        </div>

        <p style="margin-top: 10px; font-size: 11px; color: #666; font-style: italic;">
            &#128161; Tip: Upload .zip files only. File will be securely stored and delivered through purchase code.
        </p>
    </div>

    <!-- Demo Site Automation Section -->
    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd;">
        <h4 style="margin: 0 0 15px 0; font-size: 14px;">Demo Site Automation</h4>

        <?php
        $create_demo = get_post_meta($post->ID, 'create_demo_site', true);
        $demo_url = get_post_meta($post->ID, 'demo_site_url', true);
        $demo_status = get_post_meta($post->ID, 'demo_site_status', true);
        ?>

        <div style="margin-bottom: 15px;">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="checkbox" name="create_demo_site" id="create_demo_site" value="1" <?php checked($create_demo, '1'); ?>>
                <span style="font-weight: 500;">Create/Update Demo Site</span>
            </label>
            <p style="margin: 5px 0 0 26px; font-size: 12px; color: #666;">
                Automatically create or update demo site when saving this product
            </p>
        </div>

        <div style="margin-bottom: 15px; padding-left: 26px;">
            <label for="product_type" style="display: block; font-weight: 500; margin-bottom: 5px; font-size: 13px;">Product Type</label>
            <select name="product_type" id="product_type" style="width: 100%;">
                <?php
                $product_type = get_post_meta($post->ID, '_product_type', true);
                ?>
                <option value="plugin" <?php selected($product_type, 'plugin'); ?>>Plugin</option>
                <option value="theme" <?php selected($product_type, 'theme'); ?>>Theme</option>
            </select>
        </div>

        <?php if ($demo_url) : ?>
        <div style="margin-bottom: 15px;">
            <label style="display: block; font-weight: 500; margin-bottom: 5px; font-size: 13px;">Demo Site URL</label>
            <div style="display: flex; gap: 5px;">
                <input type="text" value="<?php echo esc_attr($demo_url); ?>" readonly
                       style="flex: 1; background: #f0f0f0; border: 1px solid #ddd; padding: 6px 10px; font-size: 13px;">
                <a href="<?php echo esc_url($demo_url); ?>" target="_blank" class="button button-small">
                    &#128279; Visit
                </a>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($demo_status) : ?>
        <div style="margin-bottom: 0;">
            <label style="display: block; font-weight: 500; margin-bottom: 5px; font-size: 13px;">Demo Site Status</label>
            <textarea readonly rows="3" style="width: 100%; background: #f0f0f0; border: 1px solid #ddd; padding: 8px; font-family: monospace; font-size: 12px; resize: vertical;"><?php echo esc_textarea($demo_status); ?></textarea>
        </div>
        <?php endif; ?>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        var fileFrame;

        // Upload button click
        $('#wpigo_upload_product_file_button').on('click', function(e) {
            e.preventDefault();

            // If the media frame already exists, reopen it
            if (fileFrame) {
                fileFrame.open();
                return;
            }

            // Create new media frame
            fileFrame = wp.media({
                title: 'Select Product File',
                button: {
                    text: 'Use this file'
                },
                library: {
                    type: 'application/zip'
                },
                multiple: false
            });

            // When file is selected
            fileFrame.on('select', function() {
                var attachment = fileFrame.state().get('selection').first().toJSON();

                // Set values
                $('#wpigo_product_file_id').val(attachment.id);
                $('#wpigo_product_file_url').val(attachment.url);

                // Update preview
                var fileName = attachment.filename;
                var fileSize = attachment.filesizeHumanReadable || 'Unknown';

                var previewHtml = '<div style="padding: 10px; background: #f0f0f1; border: 1px solid #c3c4c7; border-radius: 4px;">' +
                    '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 5px;">' +
                        '<span style="font-size: 20px;">&#128230;</span>' +
                        '<strong style="font-size: 13px;">' + fileName + '</strong>' +
                    '</div>' +
                    '<div style="font-size: 12px; color: #666;">' +
                        'Size: ' + fileSize +
                    '</div>' +
                    '<div style="margin-top: 8px;">' +
                        '<a href="' + attachment.url + '" target="_blank" class="button button-small">' +
                            '&#128065; View File' +
                        '</a>' +
                    '</div>' +
                    '</div>';

                $('#wpigo-product-file-preview').html(previewHtml);

                // Update button text
                $('#wpigo_upload_product_file_button').html('&#128260; Change File');

                // Show remove button if not exists
                if ($('#wpigo_remove_product_file_button').length === 0) {
                    $('#wpigo_upload_product_file_button').after(
                        '<button type="button" class="button button-secondary" id="wpigo_remove_product_file_button" style="color: #b32d2e;">&#128465; Remove</button>'
                    );
                }
            });

            // Open media frame
            fileFrame.open();
        });

        // Remove button click (using event delegation for dynamically added button)
        $(document).on('click', '#wpigo_remove_product_file_button', function(e) {
            e.preventDefault();

            if (confirm('Are you sure you want to remove this file?')) {
                $('#wpigo_product_file_id').val('');
                $('#wpigo_product_file_url').val('');

                var emptyHtml = '<div style="padding: 15px; text-align: center; background: #f9f9f9; border: 2px dashed #ddd; border-radius: 4px;">' +
                    '<span style="font-size: 32px; opacity: 0.5;">&#128230;</span>' +
                    '<p style="margin: 8px 0 0; font-size: 12px; color: #666;">No file uploaded yet</p>' +
                '</div>';

                $('#wpigo-product-file-preview').html(emptyHtml);
                $('#wpigo_upload_product_file_button').html('&#11014; Upload File');
                $('#wpigo_remove_product_file_button').remove();
            }
        });
    });
    </script>
    <?php
}

/**
 * Save product file meta box data
 */
function wpigo_save_product_file_meta_box($post_id) {
    // Check if nonce is set
    if (!isset($_POST['wpigo_product_file_nonce'])) {
        return;
    }

    // Verify nonce
    if (!wp_verify_nonce($_POST['wpigo_product_file_nonce'], 'wpigo_product_file_meta_box')) {
        return;
    }

    // Check if this is an autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Field POST'ta varsa kaydet, yoksa DOKUNMA
    if (isset($_POST['wpigo_product_file_url'])) {
        update_post_meta($post_id, '_product_file', sanitize_text_field($_POST['wpigo_product_file_url']));
    }

    if (isset($_POST['wpigo_product_file_id'])) {
        update_post_meta($post_id, '_product_file_id', intval($_POST['wpigo_product_file_id']));
    }

    // Checkbox: Varsa 1, yoksa 0
    update_post_meta($post_id, 'create_demo_site', isset($_POST['create_demo_site']) ? '1' : '0');

    if (isset($_POST['product_type'])) {
        $product_type = sanitize_text_field($_POST['product_type']);
        if (in_array($product_type, array('plugin', 'theme'))) {
            update_post_meta($post_id, '_product_type', $product_type);
        }
    }
}
add_action('save_post', 'wpigo_save_product_file_meta_box');

// ============================================================================ 
// SCREENSHOT GALLERY META BOX
// ============================================================================ 

/**
 * Add screenshot gallery meta box
 */
function wpigo_add_screenshot_gallery_meta_box() {
    add_meta_box(
        'wpigo_screenshot_gallery',
        '&#128248; Screenshot Gallery',
        'wpigo_screenshot_gallery_meta_box_callback',
        'post',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'wpigo_add_screenshot_gallery_meta_box');

// Enqueue media uploader and jQuery UI sortable for screenshot gallery
function wpigo_enqueue_screenshot_assets($hook) {
    global $post;

    if (($hook == 'post-new.php' || $hook == 'post.php') && isset($post) && $post->post_type === 'post') {
        wp_enqueue_media();
        wp_enqueue_script('jquery-ui-sortable');
    }
}
add_action('admin_enqueue_scripts', 'wpigo_enqueue_screenshot_assets', 20);

/**
 * Render screenshot gallery meta box
 */
function wpigo_screenshot_gallery_meta_box_callback($post) {
    wp_nonce_field('wpigo_screenshot_gallery_meta_box', 'wpigo_screenshot_gallery_nonce');

    $screenshot_ids = get_post_meta($post->ID, '_screenshot_gallery', true);
    if (!is_array($screenshot_ids)) {
        $screenshot_ids = array();
    }
    ?>
    <div class="wpigo-screenshot-gallery-wrapper">
        <p style="margin-bottom: 15px; font-size: 13px; color: #666;">
            <strong>Add product screenshots (Max 20 images)</strong><br>
            These screenshots will be displayed in a modal when users click the "Screenshots" button.
        </p>

        <div id="wpigo-screenshot-gallery-container" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 15px;">
            <?php if (!empty($screenshot_ids)) : ?>
                <?php foreach ($screenshot_ids as $screenshot_id) : ?>
                    <?php
                    $image_url = wp_get_attachment_image_src($screenshot_id, 'thumbnail');
                    if ($image_url) :
                    ?>
                    <div class="wpigo-screenshot-item" data-id="<?php echo esc_attr($screenshot_id); ?>" style="position: relative; width: 100px; height: 100px; border: 2px solid #ddd; border-radius: 4px; overflow: hidden; cursor: move;">
                        <img src="<?php echo esc_url($image_url[0]); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                        <button type="button" class="wpigo-remove-screenshot" data-id="<?php echo esc_attr($screenshot_id); ?>" style="position: absolute; top: 2px; right: 2px; background: #dc3232; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; cursor: pointer; font-size: 12px; line-height: 1; padding: 0;">&times;</button>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <input type="hidden" id="wpigo_screenshot_gallery_ids" name="wpigo_screenshot_gallery_ids" value="<?php echo esc_attr(implode(',', $screenshot_ids)); ?>">

        <div style="display: flex; gap: 10px; align-items: center;">
            <button type="button" class="button button-primary" id="wpigo_add_screenshots_button">
                &#10133; Add Screenshots
            </button>
            <span id="wpigo-screenshot-count" style="font-size: 13px; color: #666;">
                <?php echo count($screenshot_ids); ?> / 20 images
            </span>
        </div>

        <p style="margin-top: 10px; font-size: 11px; color: #666; font-style: italic;">
            &#128161; Tip: You can drag and drop to reorder screenshots. First image will be shown first in the gallery.
        </p>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        var screenshotFrame;
        var maxScreenshots = 20;

        // Make screenshots sortable
        $('#wpigo-screenshot-gallery-container').sortable({
            items: '.wpigo-screenshot-item',
            cursor: 'move',
            placeholder: 'wpigo-screenshot-placeholder',
            update: function(event, ui) {
                updateScreenshotIds();
            }
        });

        // Add screenshots button
        $('#wpigo_add_screenshots_button').on('click', function(e) {
            e.preventDefault();

            var currentIds = getScreenshotIds();
            if (currentIds.length >= maxScreenshots) {
                alert('Maximum ' + maxScreenshots + ' screenshots allowed.');
                return;
            }

            if (screenshotFrame) {
                screenshotFrame.open();
                return;
            }

            screenshotFrame = wp.media({
                title: 'Select Screenshots',
                button: {
                    text: 'Add to Gallery'
                },
                library: {
                    type: 'image'
                },
                multiple: true
            });

            screenshotFrame.on('select', function() {
                var selection = screenshotFrame.state().get('selection');
                var currentIds = getScreenshotIds();

                selection.map(function(attachment) {
                    attachment = attachment.toJSON();

                    if (currentIds.length >= maxScreenshots) {
                        return;
                    }

                    if (currentIds.indexOf(attachment.id.toString()) === -1) {
                        var thumbUrl = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
                        addScreenshotToGallery(attachment.id, thumbUrl);
                        currentIds.push(attachment.id.toString());
                    }
                });

                updateScreenshotIds();
                updateScreenshotCount();
            });

            screenshotFrame.open();
        });

        // Remove screenshot
        $(document).on('click', '.wpigo-remove-screenshot', function(e) {
            e.preventDefault();
            $(this).closest('.wpigo-screenshot-item').remove();
            updateScreenshotIds();
            updateScreenshotCount();
        });

        // Add screenshot to gallery
                function addScreenshotToGallery(id, url) {
                    var html = '<div class="wpigo-screenshot-item" data-id="' + id + '" style="position: relative; width: 100px; height: 100px; border: 2px solid #ddd; border-radius: 4px; overflow: hidden; cursor: move;"><img src="' + url + '" style="width: 100%; height: 100%; object-fit: cover;"><button type="button" class="wpigo-remove-screenshot" data-id="' + id + '" style="position: absolute; top: 2px; right: 2px; background: #dc3232; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; cursor: pointer; font-size: 12px; line-height: 1; padding: 0;">&times;</button></div>';

                    $('#wpigo-screenshot-gallery-container').append(html);
                }
        // Get current screenshot IDs
        function getScreenshotIds() {
            var ids = [];
            $('.wpigo-screenshot-item').each(function() {
                ids.push($(this).data('id').toString());
            });
            return ids;
        }

        // Update hidden input
        function updateScreenshotIds() {
            var ids = getScreenshotIds();
            $('#wpigo_screenshot_gallery_ids').val(ids.join(','));
        }

        // Update screenshot count
        function updateScreenshotCount() {
            var count = getScreenshotIds().length;
            $('#wpigo-screenshot-count').text(count + ' / 20 images');
        }
    });
    </script>

    <style>
        .wpigo-screenshot-placeholder {
            width: 100px;
            height: 100px;
            border: 2px dashed #999;
            border-radius: 4px;
            background: #f0f0f1;
        }
    </style>
    <?php
}

/**
 * Save screenshot gallery meta box data
 */
function wpigo_save_screenshot_gallery_meta_box($post_id) {
    if (!isset($_POST['wpigo_screenshot_gallery_nonce'])) {
        return;
    }

    if (!wp_verify_nonce($_POST['wpigo_screenshot_gallery_nonce'], 'wpigo_screenshot_gallery_meta_box')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Field POST'ta varsa kaydet, yoksa DOKUNMA
    if (isset($_POST['wpigo_screenshot_gallery_ids'])) {
        $screenshot_ids = sanitize_text_field($_POST['wpigo_screenshot_gallery_ids']);
        $ids_array = explode(',', $screenshot_ids);
        $ids_array = array_map('intval', $ids_array);
        $ids_array = array_filter($ids_array);
        $ids_array = array_slice($ids_array, 0, 20); // Max 20

        update_post_meta($post_id, '_screenshot_gallery', $ids_array);
    }
}
add_action('save_post', 'wpigo_save_screenshot_gallery_meta_box');

// ============================================================================ 
// ORDER DATA HELPER FUNCTIONS (JSON Structure)
// ============================================================================ 

/**
 * Get specific order data from JSON structure
 * 
 * @param int $order_id Order ID
 * @param string $key Data key to retrieve (e.g. 'order_number', 'buyer_email')
 * @return mixed Value or null if not found
 */
function wpigo_get_order_data($order_id, $key) {
    $order_data = get_post_meta($order_id, '_order_data', true);

    if (!is_array($order_data)) {
        return null;
    }

    // Map requested key to JSON structure
    switch ($key) {
        case 'order_number':
            return $order_data['order_number'] ?? null;

        case 'total':
        case 'order_total':
            return $order_data['total'] ?? null;

        case 'status':
        case 'order_status':
            return $order_data['status'] ?? null;

        case 'buyer_id':
            return $order_data['buyer']['id'] ?? null;

        case 'buyer_email':
            return $order_data['buyer']['email'] ?? null;

        case 'buyer_name':
            return $order_data['buyer']['name'] ?? null;

        case 'payment_method':
            return $order_data['payment']['method'] ?? null;

        case 'card_last4':
            return $order_data['payment']['card_last4'] ?? null;

        case 'card_brand':
            return $order_data['payment']['card_brand'] ?? null;

        case 'items':
        case 'order_items':
            return $order_data['items'] ?? null;

        case 'ip':
        case 'order_ip':
            return $order_data['meta']['ip'] ?? null;

        case 'user_agent':
        case 'order_user_agent':
            return $order_data['meta']['user_agent'] ?? null;

        case 'created_at':
            return $order_data['meta']['created_at'] ?? null;

        default:
            return null;
    }
}

/**
 * Get complete order data as flattened array
 * 
 * @param int $order_id Order ID
 * @return array|false Order data array or false if not found
 */
function wpigo_get_order_data_all($order_id) {
    $order_data = get_post_meta($order_id, '_order_data', true);

    if (!is_array($order_data) || empty($order_data)) {
        return false;
    }

    // Return flattened structure for easy access
    return array(
        'order_number' => $order_data['order_number'] ?? '',
        'total' => $order_data['total'] ?? 0,
        'status' => $order_data['status'] ?? '',
        'buyer_id' => $order_data['buyer']['id'] ?? 0,
        'buyer_email' => $order_data['buyer']['email'] ?? '',
        'buyer_name' => $order_data['buyer']['name'] ?? '',
        'payment_method' => $order_data['payment']['method'] ?? '',
        'card_last4' => $order_data['payment']['card_last4'] ?? '',
        'card_brand' => $order_data['payment']['card_brand'] ?? '',
        'items' => $order_data['items'] ?? array(),
        'ip' => $order_data['meta']['ip'] ?? '',
        'user_agent' => $order_data['meta']['user_agent'] ?? '',
        'created_at' => $order_data['meta']['created_at'] ?? '',
    );
}

/**
 * Get raw order data JSON
 * Use this if you need direct access to JSON structure
 * 
 * @param int $order_id Order ID
 * @return array|false Raw JSON data or false if not found
 */
function wpigo_get_order_data_raw($order_id) {
    $order_data = get_post_meta($order_id, '_order_data', true);
    return is_array($order_data) ? $order_data : false;
}

// ============================================ 
// LICENSE API SYSTEM
// ============================================ 

/**
 * Add license API rewrite rules
 * URL Format: /api/license/verify
 */
function wpigo_add_license_api_rewrite_rules() {
    add_rewrite_rule(
        '^api/license/verify/?$',
        'index.php?wpigo_api=license&wpigo_action=verify',
        'top'
    );

    add_rewrite_rule(
        '^api/license/deactivate/?$',
        'index.php?wpigo_api=license&wpigo_action=deactivate',
        'top'
    );

    // TEMPORARY: One-time flush to activate license API
    // Delete this after first page load!
    if (get_option('wpigo_license_api_flushed') !== '1') {
        flush_rewrite_rules();
        update_option('wpigo_license_api_flushed', '1');
    }
}
add_action('init', 'wpigo_add_license_api_rewrite_rules');

/**
 * Add custom query vars for API
 */
function wpigo_add_license_api_query_vars($vars) {
    $vars[] = 'wpigo_api';
    $vars[] = 'wpigo_action';
    return $vars;
}
add_filter('query_vars', 'wpigo_add_license_api_query_vars');

/**
 * Check rate limit for IP address
 * 
 * @param string $ip IP address
 * @param int $limit Maximum requests per minute
 * @return bool True if within limit, false if exceeded
 */
function wpigo_check_ip_rate_limit($ip, $limit = 10) {
    $transient_key = 'wpigo_rate_limit_ip_' . md5($ip);
    $requests = get_transient($transient_key);

    if ($requests === false) {
        // First request
        set_transient($transient_key, 1, 60); // 60 seconds
        return true;
    }

    if ($requests >= $limit) {
        return false; // Rate limit exceeded
    }

    // Increment counter
    set_transient($transient_key, $requests + 1, 60);
    return true;
}

/**
 * Check rate limit for purchase code activation attempts
 * 
 * @param string $purchase_code Purchase code
 * @param int $limit Maximum attempts per hour
 * @return bool True if within limit, false if exceeded
 */
function wpigo_check_purchase_code_rate_limit($purchase_code, $limit = 5) {
    $transient_key = 'wpigo_rate_limit_code_' . md5($purchase_code);
    $attempts = get_transient($transient_key);

    if ($attempts === false) {
        // First attempt
        set_transient($transient_key, 1, 3600); // 3600 seconds (1 hour)
        return true;
    }

    if ($attempts >= $limit) {
        return false; // Rate limit exceeded
    }

    // Increment counter
    set_transient($transient_key, $attempts + 1, 3600);
    return true;
}

/**
 * Verify license and activate domain
 * 
 * @param string $purchase_code Purchase code
 * @param string $domain Domain to activate
 * @param string $ip IP address of the request
 * @return array Response array
 */
function wpigo_verify_license($purchase_code, $domain, $ip) {
    global $wpdb;

    // 1. Validate purchase code format
    if (!preg_match('/^WPIGO-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i', $purchase_code)) {
        return array(
            'status' => 'error',
            'message' => 'Invalid purchase code format'
        );
    }

    // 2. Find order by purchase code
    $order_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id
        FROM {$wpdb->postmeta}
        WHERE meta_key = '_purchase_code'
        AND meta_value = %s
        LIMIT 1
    ", $purchase_code));

    if (!$order_id) {
        return array(
            'status' => 'error',
            'message' => 'Invalid purchase code'
        );
    }

    // 3. Get order data
    $order_data = wpigo_get_order_data_raw($order_id);

    if (!$order_data) {
        return array(
            'status' => 'error',
            'message' => 'Order data not found'
        );
    }

    // 4. Find the product for this purchase code
    $product_item = null;
    $item_index = null;

    foreach ($order_data['items'] as $index => $item) {
        if (isset($item['license_keys']['purchase_code']) &&
            $item['license_keys']['purchase_code'] === $purchase_code) {
            $product_item = $item;
            $item_index = $index;
            break;
        }
    }

    if (!$product_item) {
        return array(
            'status' => 'error',
            'message' => 'Product not found for this purchase code'
        );
    }

    // 5. Check existing activations
    $activations = isset($product_item['license_keys']['activations']) ?
                   $product_item['license_keys']['activations'] : array();

    // 6. Check if already activated on a different domain
    foreach ($activations as $activation) {
        if ($activation['status'] === 'active' && $activation['domain'] !== $domain) {
            return array(
                'status' => 'error',
                'message' => 'This license is already activated on another domain: ' . $activation['domain']
            );
        }

        // If already activated on the same domain, return success
        if ($activation['status'] === 'active' && $activation['domain'] === $domain) {
            // Get current product_slug from post meta (not from order)
            $current_product_slug = get_post_meta($product_item['product_id'], '_product_slug', true);

            // Get announcement data
            $announcement = wpigo_get_announcement_data();

            return array(
                'status' => 'success',
                'message' => 'License already activated on this domain',
                'data' => array(
                    'license_status' => 'active',
                    'domain' => $domain,
                    'activated_at' => $activation['activated_at'],
                    'product' => $product_item['title'],
                    'product_id' => $product_item['product_id'],
                    'product_slug' => $current_product_slug ? $current_product_slug : '',
                    'api_key' => isset($product_item['license_keys']['api_key']) ? $product_item['license_keys']['api_key'] : '',
                    'secret_key' => isset($product_item['license_keys']['secret_key']) ? $product_item['license_keys']['secret_key'] : '',
                    'announcement' => $announcement
                )
            );
        }
    }

    // 7. Activate license on new domain
    $current_time = current_time('mysql');

    $new_activation = array(
        'domain' => $domain,
        'activated_at' => $current_time,
        'ip' => $ip,
        'status' => 'active'
    );

    // Add new activation
    $activations[] = $new_activation;

    // Update order data
    $order_data['items'][$item_index]['license_keys']['activations'] = $activations;

    // Save updated order data
    update_post_meta($order_id, '_order_data', $order_data);

    // Get current product_slug from post meta (not from order)
    $current_product_slug = get_post_meta($product_item['product_id'], '_product_slug', true);

    // Get announcement data
    $announcement = wpigo_get_announcement_data();

    // 8. Return success response
    return array(
        'status' => 'success',
        'message' => 'License activated successfully',
        'data' => array(
            'license_status' => 'active',
            'domain' => $domain,
            'activated_at' => $current_time,
            'product' => $product_item['title'],
            'product_id' => $product_item['product_id'],
            'product_slug' => $current_product_slug ? $current_product_slug : '',
            'api_key' => isset($product_item['license_keys']['api_key']) ? $product_item['license_keys']['api_key'] : '',
            'secret_key' => isset($product_item['license_keys']['secret_key']) ? $product_item['license_keys']['secret_key'] : '',
            'announcement' => $announcement
        )
    );
}

/**
 * Deactivate license for a domain
 * 
 * @param string $purchase_code Purchase code
 * @param string $domain Domain to deactivate
 * @return array Response array
 */
function wpigo_deactivate_license($purchase_code, $domain) {
    global $wpdb;

    // 1. Find order by purchase code
    $order_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id
        FROM {$wpdb->postmeta}
        WHERE meta_key = '_purchase_code'
        AND meta_value = %s
        LIMIT 1
    ", $purchase_code));

    if (!$order_id) {
        return array(
            'status' => 'error',
            'message' => 'Invalid purchase code'
        );
    }

    // 2. Get order data
    $order_data = wpigo_get_order_data_raw($order_id);

    if (!$order_data) {
        return array(
            'status' => 'error',
            'message' => 'Order data not found'
        );
    }

    // 3. Find the product for this purchase code
    $item_index = null;

    foreach ($order_data['items'] as $index => $item) {
        if (isset($item['license_keys']['purchase_code']) &&
            $item['license_keys']['purchase_code'] === $purchase_code) {
            $item_index = $index;
            break;
        }
    }

    if ($item_index === null) {
        return array(
            'status' => 'error',
            'message' => 'Product not found for this purchase code'
        );
    }

    // 4. Deactivate the domain
    $activations = isset($order_data['items'][$item_index]['license_keys']['activations']) ?
                   $order_data['items'][$item_index]['license_keys']['activations'] : array();

    $found = false;
    foreach ($activations as $key => $activation) {
        if ($activation['domain'] === $domain && $activation['status'] === 'active') {
            $activations[$key]['status'] = 'deactivated';
            $activations[$key]['deactivated_at'] = current_time('mysql');
            $found = true;
            break;
        }
    }

    if (!$found) {
        return array(
            'status' => 'error',
            'message' => 'License is not active on this domain'
        );
    }

    // 5. Update order data
    $order_data['items'][$item_index]['license_keys']['activations'] = $activations;
    update_post_meta($order_id, '_order_data', $order_data);

    // 6. Return success
    return array(
        'status' => 'success',
        'message' => 'License deactivated successfully'
    );
}

/**
 * Handle license API requests
 */
function wpigo_handle_license_api_request() {
    $api = get_query_var('wpigo_api');
    $action = get_query_var('wpigo_action');

    if ($api === 'license') {
        // Get request IP
        $ip = $_SERVER['REMOTE_ADDR'];

        // Check IP rate limit (5 requests per minute)
        if (!wpigo_check_ip_rate_limit($ip, 5)) {
            wp_send_json(array(
                'status' => 'error',
                'message' => 'Rate limit exceeded. Please try again later.'
            ), 429);
            exit;
        }

        // Get POST data
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            $data = $_POST;
        }

        $purchase_code = isset($data['purchase_code']) ? sanitize_text_field($data['purchase_code']) : '';
        $domain = isset($data['domain']) ? sanitize_text_field($data['domain']) : '';

        // Validate required fields
        if (empty($purchase_code) || empty($domain)) {
            wp_send_json(array(
                'status' => 'error',
                'message' => 'Missing required fields: purchase_code and domain'
            ), 400);
            exit;
        }

        // Check purchase code rate limit (20 attempts per hour)
        if (!wpigo_check_purchase_code_rate_limit($purchase_code, 20)) {
            wp_send_json(array(
                'status' => 'error',
                'message' => 'Too many activation attempts. Please try again later.'
            ), 429);
            exit;
        }

        // Handle action
        if ($action === 'verify') {
            $response = wpigo_verify_license($purchase_code, $domain, $ip);
            wp_send_json($response, $response['status'] === 'success' ? 200 : 400);
            exit;
        }
        elseif ($action === 'deactivate') {
            $response = wpigo_deactivate_license($purchase_code, $domain);
            wp_send_json($response, $response['status'] === 'success' ? 200 : 400);
            exit;
        }
        else {
            wp_send_json(array(
                'status' => 'error',
                'message' => 'Invalid action'
            ), 400);
            exit;
        }
    }
}
add_action('template_redirect', 'wpigo_handle_license_api_request');

// ============================================ 
// ADMIN ORDER META BOX - LICENSE INFORMATION
// ============================================ 

/**
 * Add license information meta box to order edit page
 */
function wpigo_add_order_license_meta_box() {
    add_meta_box(
        'wpigo_order_license_info',
        '&#128273; License Information & Activation Status',
        'wpigo_render_order_license_meta_box',
        'wpigo_order',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'wpigo_add_order_license_meta_box');

/**
 * Render license information meta box
 */
function wpigo_render_order_license_meta_box($post) {
    // Get order data
    $order_data = wpigo_get_order_data_raw($post->ID);

    if (!$order_data || !isset($order_data['items'])) {
        echo '<p>No license data found for this order.</p>';
        return;
    }

    // Get buyer info
    $buyer_name = isset($order_data['buyer']['name']) ? $order_data['buyer']['name'] : 'N/A';
    $buyer_email = isset($order_data['buyer']['email']) ? $order_data['buyer']['email'] : 'N/A';

    ?>
    <style>
        .wpigo-license-meta-box {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .wpigo-license-meta-section {
            margin-bottom: 30px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 6px;
            border-left: 4px solid #2271b1;
        }
        .wpigo-license-meta-section:last-child {
            margin-bottom: 0;
        }
        .wpigo-license-meta-title {
            margin: 0 0 15px 0;
            font-size: 16px;
            font-weight: 600;
            color: #1d2327;
        }
        .wpigo-license-meta-grid {
            display: grid;
            grid-template-columns: 150px 1fr;
            gap: 12px;
            margin-bottom: 20px;
        }
        .wpigo-license-meta-label {
            font-weight: 600;
            color: #646970;
            font-size: 13px;
        }
        .wpigo-license-meta-value {
            color: #1d2327;
            font-size: 13px;
        }
        .wpigo-license-meta-code {
            background: #fff;
            padding: 8px 12px;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            display: inline-block;
            user-select: all;
        }
        .wpigo-license-activation-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background: #fff;
            border-radius: 4px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .wpigo-license-activation-table th {
            background: #f0f0f1;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 12px;
            color: #1d2327;
            border-bottom: 2px solid #c3c4c7;
        }
        .wpigo-license-activation-table td {
            padding: 12px;
            font-size: 13px;
            border-bottom: 1px solid #f0f0f1;
        }
        .wpigo-license-activation-table tr:last-child td {
            border-bottom: none;
        }
        .wpigo-license-status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .wpigo-license-status-active {
            background: #d4edda;
            color: #155724;
        }
        .wpigo-license-status-deactivated {
            background: #f8d7da;
            color: #721c24;
        }
        .wpigo-license-status-none {
            background: #fff3cd;
            color: #856404;
        }
        .wpigo-license-buyer-info {
            background: #e7f5ff;
            border-left-color: #0073aa;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            border-left: 4px solid #0073aa;
        }
        .wpigo-license-buyer-info p {
            margin: 5px 0;
            font-size: 13px;
        }
    </style>

    <div class="wpigo-license-meta-box">
        <!-- Buyer Information -->
        <div class="wpigo-license-buyer-info">
            <p><strong>👤 Customer:</strong> <?php echo esc_html($buyer_name); ?> (<?php echo esc_html($buyer_email); ?>)</p>
        </div>

        <?php foreach ($order_data['items'] as $index => $item) : ?>
            <?php
            $product_title = isset($item['title']) ? $item['title'] : 'Unknown Product';
            $product_id = isset($item['product_id']) ? $item['product_id'] : 0;
            $license_keys = isset($item['license_keys']) ? $item['license_keys'] : array();
            $activations = isset($license_keys['activations']) ? $license_keys['activations'] : array();

            // Check if has active activation
            $has_active = false;
            foreach ($activations as $activation) {
                if (isset($activation['status']) && $activation['status'] === 'active') {
                    $has_active = true;
                    break;
                }
            }
            ?>

            <div class="wpigo-license-meta-section">
                <h3 class="wpigo-license-meta-title">
                    📦 <?php echo esc_html($product_title); ?>
                    <?php if ($product_id) : ?>
                        <a href="<?php echo get_edit_post_link($product_id); ?>" style="font-size: 12px; font-weight: normal; margin-left: 10px;">(Edit Product)</a>
                    <?php endif; ?>
                </h3>

                <!-- License Keys -->
                <div class="wpigo-license-meta-grid">
                    <div class="wpigo-license-meta-label">Purchase Code:</div>
                    <div class="wpigo-license-meta-value">
                        <code class="wpigo-license-meta-code"><?php echo esc_html($license_keys['purchase_code'] ?? 'N/A'); ?></code>
                    </div>

                    <div class="wpigo-license-meta-label">API Key:</div>
                    <div class="wpigo-license-meta-value">
                        <code class="wpigo-license-meta-code"><?php echo esc_html($license_keys['api_key'] ?? 'N/A'); ?></code>
                    </div>

                    <div class="wpigo-license-meta-label">Secret Key:</div>
                    <div class="wpigo-license-meta-value">
                        <code class="wpigo-license-meta-code"><?php echo esc_html($license_keys['secret_key'] ?? 'N/A'); ?></code>
                    </div>
                </div>

                <!-- Activation Status -->
                <div style="margin-top: 20px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 14px; font-weight: 600;">
                         Activation Status
                    </h4>

                    <?php if (!empty($activations)) : ?>
                        <table class="wpigo-license-activation-table">
                            <thead>
                                <tr>
                                    <th>Domain</th>
                                    <th>Status</th>
                                    <th>Activated At</th>
                                    <th>IP Address</th>
                                    <th>Deactivated At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($activations as $activation) : ?>
                                    <?php
                                    $status = isset($activation['status']) ? $activation['status'] : 'unknown';
                                    $status_class = $status === 'active' ? 'wpigo-license-status-active' : 'wpigo-license-status-deactivated';
                                    $status_text = $status === 'active' ? 'Active' : 'Deactivated';
                                    ?>
                                    <tr>
                                        <td><strong><?php echo esc_html($activation['domain']); ?></strong></td>
                                        <td>
                                            <span class="wpigo-license-status-badge <?php echo $status_class; ?>">
                                                <?php echo $status_text; ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(date('M j, Y - g:i A', strtotime($activation['activated_at']))); ?></td>
                                        <td><code><?php echo esc_html($activation['ip']); ?></code></td>
                                        <td>
                                            <?php if (isset($activation['deactivated_at'])) : ?>
                                                <?php echo esc_html(date('M j, Y - g:i A', strtotime($activation['deactivated_at']))); ?>
                                            <?php else : ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 4px; text-align: center;">
                            <span class="wpigo-license-status-badge wpigo-license-status-none">Not Activated</span>
                            <p style="margin: 10px 0 0 0; font-size: 12px; color: #856404;">
                                Customer has not activated this license on any domain yet.
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php endforeach; ?>
    </div>
    <?php
}
// ============================================ 
// CONTACT MESSAGE SYSTEM
// ============================================ 

// Register Custom Post Type for Contact Messages
function wpigo_register_contact_cpt() {
    $labels = array(
        'name'               => 'Contact Messages',
        'singular_name'      => 'Contact Message',
        'menu_name'          => 'Contact Messages',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Message',
        'edit_item'          => 'View Message',
        'new_item'           => 'New Message',
        'view_item'          => 'View Message',
        'search_items'       => 'Search Messages',
        'not_found'          => 'No messages found',
        'not_found_in_trash' => 'No messages found in trash',
    );

    $args = array(
        'labels'              => $labels,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-email',
        'capability_type'     => 'post',
        'capabilities'        => array(
            'create_posts' => 'do_not_allow',
        ),
        'map_meta_cap'        => true,
        'hierarchical'        => false,
        'supports'            => array('title', 'editor'),
        'has_archive'         => false,
        'can_export'          => true,
        'exclude_from_search' => true,
    );

    register_post_type('wpigo_contact', $args);
}
add_action('init', 'wpigo_register_contact_cpt');

// Add custom columns to admin list
function wpigo_contact_columns($columns) {
    $columns = array(
        'cb'       => '<input type="checkbox" />',
        'title'    => 'Name',
        'email'    => 'Email',
        'subject'  => 'Subject',
        'status'   => 'Status',
        'date'     => 'Date',
    );
    return $columns;
}
add_filter('manage_wpigo_contact_posts_columns', 'wpigo_contact_columns');

// Populate custom columns
function wpigo_contact_custom_column($column, $post_id) {
    switch ($column) {
        case 'email':
            echo esc_html(get_post_meta($post_id, '_contact_email', true));
            break;
        case 'subject':
            echo esc_html(get_post_meta($post_id, '_contact_subject', true));
            break;
        case 'status':
            $status = get_post_meta($post_id, '_contact_status', true);
            $status = $status ? $status : 'new';
            $colors = array(
                'new' => '#0073aa',
                'read' => '#46b450',
                'replied' => '#00a0d2',
            );
            $labels = array(
                'new' => 'New',
                'read' => 'Read',
                'replied' => 'Replied',
            );
            echo '<span style="background: ' . $colors[$status] . '; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px; font-weight: 600;">' . $labels[$status] . '</span>';
            break;
    }
}
add_action('manage_wpigo_contact_posts_custom_column', 'wpigo_contact_custom_column', 10, 2);

// Add meta box for message details
function wpigo_contact_meta_boxes() {
    add_meta_box(
        'wpigo_contact_details',
        'Message Details',
        'wpigo_contact_details_callback',
        'wpigo_contact',
        'normal',
        'high'
    );
    
    add_meta_box(
        'wpigo_contact_reply',
        'Reply to Message',
        'wpigo_contact_reply_callback',
        'wpigo_contact',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'wpigo_contact_meta_boxes');

// Message details meta box callback
function wpigo_contact_details_callback($post) {
    $email = get_post_meta($post->ID, '_contact_email', true);
    $subject = get_post_meta($post->ID, '_contact_subject', true);
    $phone = get_post_meta($post->ID, '_contact_phone', true);
    $ip = get_post_meta($post->ID, '_contact_ip', true);
    $user_id = get_post_meta($post->ID, '_contact_user_id', true);
    $status = get_post_meta($post->ID, '_contact_status', true);
    $status = $status ? $status : 'new';
    
    // Mark as read when viewing
    if ($status == 'new') {
        update_post_meta($post->ID, '_contact_status', 'read');
    }
    
    ?>
    <table class="form-table">
        <tr>
            <th><strong>From:</strong></th>
            <td><?php echo esc_html(get_the_title($post->ID)); ?></td>
        </tr>
        <tr>
            <th><strong>Email:</strong></th>
            <td><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></td>
        </tr>
        <tr>
            <th><strong>Subject:</strong></th>
            <td><?php echo esc_html($subject); ?></td>
        </tr>
        <?php if ($phone) : ?>
        <tr>
            <th><strong>Phone:</strong></th>
            <td><?php echo esc_html($phone); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <th><strong>Status:</strong></th>
            <td>
                <select name="contact_status" style="min-width: 150px;">
                    <option value="new" <?php selected($status, 'new'); ?>>New</option>
                    <option value="read" <?php selected($status, 'read'); ?>>Read</option>
                    <option value="replied" <?php selected($status, 'replied'); ?>>Replied</option>
                </select>
            </td>
        </tr>
        <?php if ($user_id) : ?>
        <tr>
            <th><strong>User:</strong></th>
            <td><a href="<?php echo admin_url('user-edit.php?user_id=' . $user_id); ?>">View User Profile</a></td>
        </tr>
        <?php endif; ?>
        <tr>
            <th><strong>IP Address:</strong></th>
            <td><?php echo esc_html($ip); ?></td>
        </tr>
        <tr>
            <th><strong>Date:</strong></th>
            <td><?php echo get_the_date('F j, Y g:i a', $post->ID); ?></td>
        </tr>
    </table>
    
    <h3 style="margin-top: 20px;">Message:</h3>
    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; border-left: 4px solid #0073aa;">
        <?php echo nl2br(esc_html(get_post_field('post_content', $post->ID))); ?>
    </div>
    <?php
}

// Reply meta box callback
function wpigo_contact_reply_callback($post) {
    $email = get_post_meta($post->ID, '_contact_email', true);
    wp_nonce_field('wpigo_reply_nonce', 'wpigo_reply_nonce_field');
    ?>
    <p>
        <label for="reply_subject"><strong>Subject:</strong></label><br>
        <input type="text" id="reply_subject" name="reply_subject" value="Re: <?php echo esc_attr(get_post_meta($post->ID, '_contact_subject', true)); ?>" style="width: 100%;">
    </p>
    <p>
        <label for="reply_message"><strong>Message:</strong></label><br>
        <textarea id="reply_message" name="reply_message" rows="10" style="width: 100%;"></textarea>
    </p>
    <p>
        <button type="button" class="button button-primary" onclick="sendReply(<?php echo $post->ID; ?>, '<?php echo esc_js($email); ?>')">Send Reply</button>
        <span id="reply-status" style="margin-left: 10px;"></span>
    </p>
    
    <script>
    function sendReply(postId, email) {
        var subject = document.getElementById('reply_subject').value;
        var message = document.getElementById('reply_message').value;
        var statusEl = document.getElementById('reply-status');
        
        if (!message) {
            alert('Please enter a message');
            return;
        }
        
        statusEl.innerHTML = '<span style="color: #0073aa;">Sending...</span>';
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                'action': 'wpigo_send_reply',
                'post_id': postId,
                'email': email,
                'subject': subject,
                'message': message,
                'nonce': '<?php echo wp_create_nonce('wpigo_reply_nonce'); ?>'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                statusEl.innerHTML = '<span style="color: #46b450;">✓ Reply sent successfully!</span>';
                setTimeout(() => {
                    location.reload();
                }, 1500);
            } else {
                statusEl.innerHTML = '<span style="color: #dc3232;">✗ Error: ' + data.data + '</span>';
            }
        })
        .catch(error => {
            statusEl.innerHTML = '<span style="color: #dc3232;">✗ Error sending reply</span>';
        });
    }
    </script>
    <?php
}

// Save contact meta
function wpigo_save_contact_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['contact_status'])) {
        update_post_meta($post_id, '_contact_status', sanitize_text_field($_POST['contact_status']));
    }
}
add_action('save_post_wpigo_contact', 'wpigo_save_contact_meta');

// AJAX handler for reply
function wpigo_send_reply_ajax() {
    check_ajax_referer('wpigo_reply_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Permission denied');
    }
    
    $post_id = intval($_POST['post_id']);
    $to_email = sanitize_email($_POST['email']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);
    
    if (!$to_email || !$message) {
        wp_send_json_error('Email and message required');
    }
    
    // Send email
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $email_body = '<html><body>';
    $email_body .= '<p>Hello,</p>';
    $email_body .= '<p>' . nl2br($message) . '</p>';
    $email_body .= '<hr>';
    $email_body .= '<p style="font-size: 12px; color: #666;">This is a reply to your message sent via ' . get_bloginfo('name') . '</p>';
    $email_body .= '</body></html>';
    
    $sent = wp_mail($to_email, $subject, $email_body, $headers);
    
    if ($sent) {
        update_post_meta($post_id, '_contact_status', 'replied');
        wp_send_json_success('Reply sent');
    } else {
        wp_send_json_error('Failed to send email');
    }
}
add_action('wp_ajax_wpigo_send_reply', 'wpigo_send_reply_ajax');

// AJAX handler for contact form submission
function wpigo_submit_contact_form() {
    check_ajax_referer('wpigo_contact_nonce', 'nonce');
    
    // Get and sanitize form data
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);
    $user_id = get_current_user_id();
    
    // Validate
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        wp_send_json_error('Please fill all required fields');
    }
    
    if (!is_email($email)) {
        wp_send_json_error('Please enter a valid email address');
    }
    
    // Create post
    $post_id = wp_insert_post(array(
        'post_title'   => $name,
        'post_content' => $message,
        'post_type'    => 'wpigo_contact',
        'post_status'  => 'publish',
    ));
    
    if (is_wp_error($post_id)) {
        wp_send_json_error('Failed to save message');
    }
    
    // Save meta data
    update_post_meta($post_id, '_contact_email', $email);
    update_post_meta($post_id, '_contact_phone', $phone);
    update_post_meta($post_id, '_contact_subject', $subject);
    update_post_meta($post_id, '_contact_status', 'new');
    update_post_meta($post_id, '_contact_ip', $_SERVER['REMOTE_ADDR']);
    if ($user_id) {
        update_post_meta($post_id, '_contact_user_id', $user_id);
    }
    
    // Send email to admin
    $admin_email = get_option('admin_email');
    $admin_subject = '[' . get_bloginfo('name') . '] New Contact Message from ' . $name;
    $admin_message = '<html><body>';
    $admin_message .= '<h2>New Contact Message</h2>';
    $admin_message .= '<p><strong>From:</strong> ' . esc_html($name) . '</p>';
    $admin_message .= '<p><strong>Email:</strong> ' . esc_html($email) . '</p>';
    $admin_message .= '<p><strong>Phone:</strong> ' . esc_html($phone) . '</p>';
    $admin_message .= '<p><strong>Subject:</strong> ' . esc_html($subject) . '</p>';
    $admin_message .= '<p><strong>Message:</strong></p>';
    $admin_message .= '<div style="background: #f5f5f5; padding: 15px; border-left: 4px solid #0073aa;">';
    $admin_message .= nl2br(esc_html($message));
    $admin_message .= '</div>';
    $admin_message .= '<p><a href="' . admin_url('post.php?post=' . $post_id . '&action=edit') . '">View in Admin Panel</a></p>';
    $admin_message .= '</body></html>';
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    wp_mail($admin_email, $admin_subject, $admin_message, $headers);
    
    // Send confirmation email to user
    $user_subject = 'Thank you for contacting ' . get_bloginfo('name');
    $user_message = '<html><body>';
    $user_message .= '<p>Hello ' . esc_html($name) . ',</p>';
    $user_message .= '<p>Thank you for contacting us. We have received your message and will get back to you as soon as possible.</p>';
    $user_message .= '<p><strong>Your message:</strong></p>';
    $user_message .= '<div style="background: #f5f5f5; padding: 15px; border-left: 4px solid #0073aa;">';
    $user_message .= nl2br(esc_html($message));
    $user_message .= '</div>';
    $user_message .= '<p>Best regards,<br>' . get_bloginfo('name') . '</p>';
    $user_message .= '</body></html>';
    
    wp_mail($email, $user_subject, $user_message, $headers);
    
    wp_send_json_success('Message sent successfully! We will get back to you soon.');
}
add_action('wp_ajax_wpigo_contact_submit', 'wpigo_submit_contact_form');
add_action('wp_ajax_nopriv_wpigo_contact_submit', 'wpigo_submit_contact_form');

/**
 * ===================================================================
 * SEO Meta Etiket İyileştirmeleri
 * ===================================================================
 */

// 1. WordPress Generator Etiketini Kaldr
remove_action('wp_head', 'wp_generator');

// CSS ve JS dosyalarından WordPress sürüm numarasını kaldır (gvenlik)
// AMA tema dosyaları için cache busting kullan
add_filter('style_loader_src', 'wpigo_remove_version_from_assets', 9999);
add_filter('script_loader_src', 'wpigo_remove_version_from_assets', 9999);

function wpigo_remove_version_from_assets($src) {
    if (strpos($src, 'ver=')) {
        $theme_uri = get_template_directory_uri();

        // Eğer tema dosyası ise, WordPress sürümünü kaldr ve filemtime ile değiştir
        if (strpos($src, $theme_uri) !== false) {
            // Tema dosyası - cache busting için filemtime kullan
            $src = remove_query_arg('ver', $src);

            // Dosya yolunu al
            $file_path = str_replace($theme_uri, get_template_directory(), $src);
            $file_path = strtok($file_path, '?'); // Query string'i temizle

            if (file_exists($file_path)) {
                $src = add_query_arg('ver', filemtime($file_path), $src);
            }
        } else {
            // WordPress core veya plugin dosyası - sadece sürüm numarasını kaldır
            $src = remove_query_arg('ver', $src);
        }
    }
    return $src;
}

// 2. zel SEO meta etiketleri ekle
if (!function_exists('wpigo_seo_meta_tags')) {
    function wpigo_seo_meta_tags() {
        global $post;
        $description = '';
        $og_image = '';

        if (is_front_page() || is_home()) {
            $description = get_bloginfo('description', 'display');
        } elseif (is_singular('post')) {
            // Product pages - Smart description priority
            $product_desc = get_post_meta($post->ID, 'product_description', true);

            if (!empty($product_desc)) {
                $description = strip_tags($product_desc);
            } else {
                // get_the_excerpt() automatically:
                // 1. Returns manual excerpt if exists
                // 2. Otherwise extracts first 55 words from content (clean)
                $description = get_the_excerpt($post->ID);
                if (empty($description)) {
                    $description = get_the_title() . ' - Premium WordPress plugin/theme available for purchase. High-quality digital product with professional support.';
                }
            }
        } elseif (is_singular()) {
            // Pages and other post types - Only use excerpt
            if (has_excerpt($post->ID)) {
                $description = get_the_excerpt($post->ID);
            } else {
                $description = get_the_title() . ' - ' . get_bloginfo('description', 'display');
            }
        } elseif (is_category()) {
            $description = strip_tags(category_description());
        } elseif (is_tag()) {
            $description = strip_tags(tag_description());
        }

        // Set OG image for all singular content types (consolidated)
        $og_image_width = 1200;  // Default fallback
        $og_image_height = 630;  // Default fallback

        if (is_singular() && has_post_thumbnail()) {
            $thumbnail_id = get_post_thumbnail_id(get_the_ID());
            $image_data = wp_get_attachment_image_src($thumbnail_id, 'full');
            if ($image_data) {
                $og_image = $image_data[0];
                $og_image_width = $image_data[1];
                $og_image_height = $image_data[2];
            }
        }

        if ($description) {
            $description = esc_attr(wp_trim_words($description, 25, '...'));
            echo '<meta name="description" content="' . $description . '">' . "\n";
        }

        // Set OG title based on page type
        if (is_front_page() || is_home()) {
            $og_title = get_bloginfo('name');
            $og_url = home_url('/');
        } elseif (is_singular()) {
            $og_title = get_the_title();
            $og_url = get_permalink();
        } elseif (is_category()) {
            $og_title = single_cat_title('', false);
            $og_url = get_category_link(get_query_var('cat'));
        } else {
            $og_title = get_bloginfo('name');
            $og_url = home_url('/');
        }

// Determine og:type based on content type
if (is_singular('post')) {
    // Check if this is a product post
    $price = get_post_meta(get_the_ID(), 'product_price', true);
    $og_type = $price ? 'product' : 'article'; // If has price, it's a product
} elseif (is_singular()) {
    $og_type = 'article';
} else {
    $og_type = 'website';
}
        if (!$og_image) {
            $custom_logo_id = get_theme_mod('custom_logo');
            if ($custom_logo_id) {
                $logo_data = wp_get_attachment_image_src($custom_logo_id, 'full');
                if ($logo_data) {
                    $og_image = $logo_data[0];
                    $og_image_width = $logo_data[1];
                    $og_image_height = $logo_data[2];
                }
            }
        }

        echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . "\n";
        echo '<meta property="og:description" content="' . $description . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($og_url) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . '">' . "\n";
        echo '<meta property="og:type" content="' . esc_attr($og_type) . '">' . "\n";
        echo '<meta property="og:locale" content="' . esc_attr(str_replace('-', '_', get_bloginfo('language'))) . '">' . "\n";

        // Facebook App ID
        $fb_app_id = get_theme_mod('wpigo_fb_app_id', '');
        if ($fb_app_id) {
            echo '<meta property="fb:app_id" content="' . esc_attr($fb_app_id) . '">' . "\n";
        }

        if ($og_image) {
            echo '<meta property="og:image" content="' . esc_url($og_image) . '">' . "\n";
            echo '<meta property="og:image:width" content="' . esc_attr($og_image_width) . '">' . "\n";
            echo '<meta property="og:image:height" content="' . esc_attr($og_image_height) . '">' . "\n";

            // Add image alt text for accessibility and SEO
            if (is_singular() && has_post_thumbnail()) {
                $thumbnail_id = get_post_thumbnail_id();
                $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                if (!$alt_text) {
                    $alt_text = get_the_title();
                }
                echo '<meta property="og:image:alt" content="' . esc_attr($alt_text) . '">' . "\n";
            }
        }

        // Add dates for articles
        if (is_singular('post')) {
            echo '<meta property="article:published_time" content="' . esc_attr(get_the_date('c')) . '">' . "\n";
            echo '<meta property="article:modified_time" content="' . esc_attr(get_the_modified_date('c')) . '">' . "\n";
            echo '<meta property="og:updated_time" content="' . esc_attr(get_the_modified_date('c')) . '">' . "\n";

            // Add author profile URL (only if username exists)
            $author_login = get_the_author_meta('user_login');
            if (!empty($author_login)) {
                $author_url = home_url('/member/' . urlencode($author_login) . '/');
                echo '<meta property="article:author" content="' . esc_url($author_url) . '">' . "\n";
            }

            // Add product price for Open Graph
            $price = get_post_meta(get_the_ID(), 'product_price', true);
            if ($price) {
                echo '<meta property="product:price:amount" content="' . esc_attr($price) . '">' . "\n";
                echo '<meta property="product:price:currency" content="USD">' . "\n";
            }
        }

        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($og_title) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . $description . '">' . "\n";
        if ($og_image) {
            echo '<meta name="twitter:image" content="' . esc_url($og_image) . '">' . "\n";
            echo '<meta name="twitter:image:width" content="' . esc_attr($og_image_width) . '">' . "\n";
            echo '<meta name="twitter:image:height" content="' . esc_attr($og_image_height) . '">' . "\n";
        }

        $robots_content = 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1';
        if (is_search() || is_404() || is_paged()) {
            $robots_content = 'noindex, follow';
        }
        echo '<meta name="robots" content="' . esc_attr($robots_content) . '">' . "\n";
    }
    add_action('wp_head', 'wpigo_seo_meta_tags');
}



/**
 * ===================================================================
 * SEO Meta Description Meta Box (Admin Panel)
 * ===================================================================
 */

// Add SEO meta box to post editor
if (!function_exists('wpigo_add_seo_meta_box')) {
    function wpigo_add_seo_meta_box() {
        add_meta_box(
            'wpigo_seo_meta_box',
            'SEO & Social Media Description',
            'wpigo_seo_meta_box_callback',
            'post',
            'normal',
            'high'
        );
    }
    add_action('add_meta_boxes', 'wpigo_add_seo_meta_box');
}

// Render meta box
if (!function_exists('wpigo_seo_meta_box_callback')) {
    function wpigo_seo_meta_box_callback($post) {
        wp_nonce_field('wpigo_save_seo_meta', 'wpigo_seo_meta_nonce');
        $product_desc = get_post_meta($post->ID, 'product_description', true);
        ?>
        <p>
            <label for="product_description" style="display: block; margin-bottom: 5px; font-weight: 600;">
                Product Description (For Google & Social Media)
            </label>
            <textarea
                id="product_description"
                name="product_description"
                rows="4"
                style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ddd; border-radius: 4px;"
                placeholder="Enter a compelling description for search engines and social media (Facebook, Twitter, LinkedIn). Recommended: 120-160 characters."
            ><?php echo esc_textarea($product_desc); ?></textarea>
        </p>
        <p style="color: #666; font-size: 13px; margin-top: -10px;">
            <strong>Character count:</strong> <span id="desc-char-count">0</span> / 160 (optimal)
            <br>
            <strong>Usage:</strong> This description will be used for:
            <br>• Google search results (meta description)
            <br>• Facebook sharing (og:description)
            <br>• Twitter cards (twitter:description)
            <br>• LinkedIn and other social platforms
            <br><em>If empty, the excerpt or first sentences from content will be used automatically.</em>
        </p>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">

        <p>
            <label for="product_details" style="display: block; margin-bottom: 5px; font-weight: 600;">
                Product Schema Description (Detailed Information)
            </label>
            <textarea
                id="product_details"
                name="product_details"
                rows="6"
                style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ddd; border-radius: 4px;"
                placeholder="Enter detailed product information for Product Schema. This can be longer and more technical. Include features, specifications, benefits, and usage details. NO CHARACTER LIMIT - write as much as needed."
            ><?php echo esc_textarea(get_post_meta($post->ID, 'product_details', true)); ?></textarea>
        </p>
        <p style="color: #666; font-size: 13px; margin-top: -10px;">
            <strong>Usage:</strong> This detailed description will be used for:
            <br>• Product Schema (JSON-LD structured data)
            <br>• Google Shopping and product rich results
            <br>• Detailed product information for search engines
            <br><strong>Note:</strong> This is separate from SEO description above. Write comprehensive product details here.
            <br><em>If empty, the SEO description will be used as fallback.</em>
        </p>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">

        <h4 style="margin-bottom: 10px;">Software Details (for Schema.org)</h4>

        <p style="margin-bottom: 10px;">
            <label for="software_os" style="display: block; margin-bottom: 5px; font-weight: 600;">
                Operating System / Requirements
            </label>
            <input type="text"
                   id="software_os"
                   name="software_os"
                   value="<?php echo esc_attr(get_post_meta($post->ID, 'software_os', true)); ?>"
                   placeholder="e.g., WordPress 6.0+"
                   style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ddd; border-radius: 4px;">
            <span style="font-size: 12px; color: #666;">Example: WordPress 5.0+, PHP 7.4+, etc.</span>
        </p>

        <p>
            <label for="software_category" style="display: block; margin-bottom: 5px; font-weight: 600;">
                Application Category
            </label>
            <select id="software_category"
                    name="software_category"
                    style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ddd; border-radius: 4px;">
                <?php
                $current_category = get_post_meta($post->ID, 'software_category', true);
                $categories = [
                    'DeveloperApplication' => 'Developer Application (Plugins, Development Tools)',
                    'WebApplication' => 'Web Application',
                    'DesignApplication' => 'Design Application (Themes, Design Tools)',
                    'BusinessApplication' => 'Business Application',
                    'UtilitiesApplication' => 'Utilities Application',
                    'EntertainmentApplication' => 'Entertainment Application',
                    'GameApplication' => 'Game Application'
                ];
                foreach ($categories as $value => $label) {
                    $selected = ($current_category === $value) ? 'selected' : '';
                    echo "<option value='{$value}' {$selected}>{$label}</option>";
                }
                ?>
            </select>
        </p>
        <script>
        (function() {
            const textarea = document.getElementById('product_description');
            const counter = document.getElementById('desc-char-count');

            function updateCount() {
                const count = textarea.value.length;
                counter.textContent = count;
                counter.style.color = count > 160 ? '#d63638' : (count < 120 ? '#dba617' : '#00a32a');
            }

            textarea.addEventListener('input', updateCount);
            updateCount();
        })();
        </script>
        <?php
    }
}

// Save meta box data
if (!function_exists('wpigo_save_seo_meta_box')) {
    function wpigo_save_seo_meta_box($post_id) {
        // Security checks
        if (!isset($_POST['wpigo_seo_meta_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['wpigo_seo_meta_nonce'], 'wpigo_save_seo_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Field POST'ta varsa kaydet, yoksa DOKUNMA
        if (isset($_POST['product_description'])) {
            update_post_meta($post_id, 'product_description', sanitize_textarea_field($_POST['product_description']));
        }

        if (isset($_POST['product_details'])) {
            update_post_meta($post_id, 'product_details', sanitize_textarea_field($_POST['product_details']));
        }

        if (isset($_POST['software_os'])) {
            update_post_meta($post_id, 'software_os', sanitize_text_field($_POST['software_os']));
        }

        if (isset($_POST['software_category'])) {
            update_post_meta($post_id, 'software_category', sanitize_text_field($_POST['software_category']));
        }
    }
    add_action('save_post', 'wpigo_save_seo_meta_box');
}

/**
 * ===================================================================
 * FAQ Schema Meta Box (Admin Panel)
 * ===================================================================
 */

// Add FAQ meta box to post editor
if (!function_exists('wpigo_add_faq_meta_box')) {
    function wpigo_add_faq_meta_box() {
        add_meta_box(
            'wpigo_faq_meta_box',
            'FAQ (Frequently Asked Questions)',
            'wpigo_faq_meta_box_callback',
            'post',
            'normal',
            'default'
        );
    }
    add_action('add_meta_boxes', 'wpigo_add_faq_meta_box');
}

// Render FAQ meta box
if (!function_exists('wpigo_faq_meta_box_callback')) {
    function wpigo_faq_meta_box_callback($post) {
        wp_nonce_field('wpigo_save_faq_meta', 'wpigo_faq_meta_nonce');
        $faq_items = get_post_meta($post->ID, 'product_faq', true);
        if (!empty($faq_items)) {
            $decoded = json_decode($faq_items, true);
            $faq_items = (is_array($decoded) && json_last_error() === JSON_ERROR_NONE) ? $decoded : [];
        } else {
            $faq_items = [];
        }
        ?>
        <div id="wpigo-faq-container">
            <p style="margin-bottom: 15px; color: #666;">
                <strong>Add frequently asked questions for your product.</strong> These will appear on the product page and in Google search results as expandable FAQ snippets.
            </p>

            <?php
            // Veri boyutu kontrolü
            $current_faq_count = count($faq_items);
            $current_json = get_post_meta($post->ID, 'product_faq', true);
            $current_size = strlen($current_json);
            $max_input_vars = ini_get('max_input_vars');
            $post_max_size = ini_get('post_max_size');

            // Boyut bilgisi göster
            if ($current_faq_count > 0) :
            ?>
            <div style="background: #e7f3ff; border-left: 4px solid #0073aa; padding: 10px; margin-bottom: 15px; font-size: 13px;">
                <strong>📊 Mevcut Durum:</strong>
                <?php echo $current_faq_count; ?> FAQ |
                Veri Boyutu: <strong><?php echo number_format($current_size); ?> bytes</strong> (<?php echo number_format($current_size / 1024, 1); ?> KB)
                <?php if ($post_max_size) : ?>
                | POST Limit: <?php echo $post_max_size; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($current_size > 2000000) : // 2MB ?>
            <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin-bottom: 15px;">
                <strong>⚠️ UYARI:</strong> FAQ verileri çok büyük (<?php echo number_format($current_size / 1024, 1); ?> KB)!
                Çok uzun cevaplar yazıyorsanız, <strong>POST limiti aşılabilir ve veriler kaybolabilir!</strong>
            </div>
            <?php endif; ?>

            <?php if ($current_size > 5000000) : // 5MB ?>
            <div style="background: #f8d7da; border-left: 4px solid #dc3545; padding: 12px; margin-bottom: 15px;">
                <strong>🚨 TEHLİKE!</strong> Veri boyutu çok fazla (<?php echo number_format($current_size / 1024 / 1024, 2); ?> MB)!
                Database limiti aşılabilir! <strong>Daha fazla eklemeyin!</strong>
            </div>
            <?php endif; ?>

            <div id="wpigo-faq-items">
                <?php
                if (!empty($faq_items)) {
                    foreach ($faq_items as $index => $item) {
                        ?>
                        <div class="wpigo-faq-item" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; background: #f9f9f9; border-radius: 4px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <strong>Question <?php echo ($index + 1); ?></strong>
                                <button type="button" class="button wpigo-remove-faq" style="background: #d63638; color: white; border-color: #d63638;">Remove</button>
                            </div>
                            <p style="margin-bottom: 5px;">
                                <input type="text" name="faq_question[]" value="<?php echo esc_attr($item['question']); ?>" placeholder="Enter your question..." style="width: 100%; padding: 8px; font-size: 14px;">
                            </p>
                            <p>
                                <textarea name="faq_answer[]" rows="3" placeholder="Enter the answer..." style="width: 100%; padding: 8px; font-size: 14px;"><?php echo esc_textarea($item['answer']); ?></textarea>
                            </p>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>

            <button type="button" id="wpigo-add-faq" class="button button-primary" style="margin-top: 10px;">
                + Add Question
            </button>
        </div>

        <script>
        (function($) {
            let faqCount = <?php echo is_array($faq_items) ? count($faq_items) : 0; ?>;

            $('#wpigo-add-faq').on('click', function() {
                faqCount++;
                const html = `
                    <div class="wpigo-faq-item" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; background: #f9f9f9; border-radius: 4px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <strong>Question ${faqCount}</strong>
                            <button type="button" class="button wpigo-remove-faq" style="background: #d63638; color: white; border-color: #d63638;">Remove</button>
                        </div>
                        <p style="margin-bottom: 5px;">
                            <input type="text" name="faq_question[]" placeholder="Enter your question..." style="width: 100%; padding: 8px; font-size: 14px;">
                        </p>
                        <p>
                            <textarea name="faq_answer[]" rows="3" placeholder="Enter the answer..." style="width: 100%; padding: 8px; font-size: 14px;"></textarea>
                        </p>
                    </div>
                `;
                $('#wpigo-faq-items').append(html);
            });

            $(document).on('click', '.wpigo-remove-faq', function() {
                $(this).closest('.wpigo-faq-item').remove();
            });
        })(jQuery);
        </script>
        <?php
    }
}

// Save FAQ meta box data
if (!function_exists('wpigo_save_faq_meta_box')) {
    function wpigo_save_faq_meta_box($post_id) {
        // Security checks
        if (!isset($_POST['wpigo_faq_meta_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['wpigo_faq_meta_nonce'], 'wpigo_save_faq_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Field POST'ta varsa kaydet, yoksa DOKUNMA
        if (isset($_POST['faq_question']) && isset($_POST['faq_answer'])) {
            $questions = $_POST['faq_question'];
            $answers = $_POST['faq_answer'];

            // GÜVENLİK: Array size kontrolü - POST kesildiyse kaydetme!
            if (!is_array($questions) || !is_array($answers) || count($questions) !== count($answers)) {
                error_log("WPiGo FAQ Save ERROR: POST array mismatch! Questions: " . count($questions) . ", Answers: " . count($answers));
                return; // Veri kaybını önle!
            }

            $faq_items = [];
            for ($i = 0; $i < count($questions); $i++) {
                $question = trim($questions[$i]);
                $answer = trim($answers[$i]);

                if (!empty($question) && !empty($answer)) {
                    $faq_items[] = [
                        'question' => sanitize_text_field($question),
                        'answer' => sanitize_textarea_field($answer)
                    ];
                }
            }

            // Mevcut FAQ sayısını kontrol et
            $existing_faq = get_post_meta($post_id, 'product_faq', true);
            $existing_count = 0;
            if (!empty($existing_faq)) {
                $decoded = json_decode($existing_faq, true);
                if (is_array($decoded)) {
                    $existing_count = count($decoded);
                }
            }

            // GÜVENLİK: Yeni FAQ sayısı eskinden çok azsa, POST kesilmiş olabilir!
            if ($existing_count > 5 && count($faq_items) < ($existing_count / 2)) {
                error_log("WPiGo FAQ Save ERROR: Suspicious data loss! Old: {$existing_count}, New: " . count($faq_items) . " - Aborting save!");
                return; // Veri kaybını önle!
            }

            // JSON encode et
            $json_data = json_encode($faq_items, JSON_UNESCAPED_UNICODE);

            // CRITICAL: JSON encoding başarısız mı?
            if ($json_data === false || json_last_error() !== JSON_ERROR_NONE) {
                $json_error = json_last_error_msg();
                $data_size = strlen(serialize($faq_items));
                error_log("WPiGo FAQ Save ERROR: JSON encoding failed! Error: {$json_error}, Data size: {$data_size} bytes");

                // Admin'e göster
                add_action('admin_notices', function() use ($json_error, $data_size) {
                    echo '<div class="notice notice-error"><p><strong>FAQ Kaydetme HATASI!</strong> Veriler çok büyük olabilir. JSON Error: ' . esc_html($json_error) . ' | Size: ' . number_format($data_size) . ' bytes</p></div>';
                });
                return; // Veri kaybını önle!
            }

            // Boyut kontrolü
            $json_size = strlen($json_data);
            if ($json_size > 5000000) { // 5MB
                error_log("WPiGo FAQ Save WARNING: JSON data very large! Size: {$json_size} bytes");
                add_action('admin_notices', function() use ($json_size) {
                    echo '<div class="notice notice-warning"><p><strong>UYARI!</strong> FAQ verisi çok büyük: ' . number_format($json_size) . ' bytes. Database limiti aşılabilir!</p></div>';
                });
            }

            update_post_meta($post_id, 'product_faq', $json_data);
        }
    }
    add_action('save_post', 'wpigo_save_faq_meta_box');
}

/**
 * ===================================================================
 * HowTo Schema Meta Box (Admin Panel)
 * ===================================================================
 */

// Add HowTo meta box to post editor
if (!function_exists('wpigo_add_howto_meta_box')) {
    function wpigo_add_howto_meta_box() {
        add_meta_box(
            'wpigo_howto_meta_box',
            'How-To Guide (Installation/Setup)',
            'wpigo_howto_meta_box_callback',
            'post',
            'normal',
            'default'
        );
    }
    add_action('add_meta_boxes', 'wpigo_add_howto_meta_box');
}

// Render HowTo meta box
if (!function_exists('wpigo_howto_meta_box_callback')) {
    function wpigo_howto_meta_box_callback($post) {
        wp_nonce_field('wpigo_save_howto_meta', 'wpigo_howto_meta_nonce');
        $howto_data = get_post_meta($post->ID, 'product_howto', true);
        if (!empty($howto_data)) {
            $decoded = json_decode($howto_data, true);
            $howto_data = (is_array($decoded) && json_last_error() === JSON_ERROR_NONE) ? $decoded : ['title' => '', 'description' => '', 'steps' => []];
        } else {
            $howto_data = ['title' => '', 'description' => '', 'steps' => []];
        }
        ?>
        <div id="wpigo-howto-container">
            <p style="margin-bottom: 15px; color: #666;">
                <strong>Add step-by-step installation or setup guide.</strong> This will appear in Google search as a rich How-To result.
            </p>

            <p style="margin-bottom: 10px;">
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Guide Title:</label>
                <input type="text" name="howto_title" value="<?php echo esc_attr($howto_data['title']); ?>" placeholder="e.g., How to Install This Plugin" style="width: 100%; padding: 8px; font-size: 14px;">
            </p>

            <p style="margin-bottom: 10px;">
                <label style="display: block; font-weight: 600; margin-bottom: 5px;">HowTo Description (Schema Only):</label>
                <textarea name="howto_description" rows="3" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ddd; border-radius: 4px;" placeholder="Describe what this guide teaches. This appears ONLY in HowTo schema. NO CHARACTER LIMIT - admin's full control."><?php echo esc_textarea(isset($howto_data['description']) ? $howto_data['description'] : ''); ?></textarea>
                <small style="color: #666; font-style: italic;">This description is ONLY for HowTo schema (different from meta description). Leave empty to use product_description as fallback.</small>
            </p>

            <div id="wpigo-howto-steps">
                <label style="display: block; font-weight: 600; margin-bottom: 10px;">Steps:</label>
                <?php
                if (!empty($howto_data['steps'])) {
                    foreach ($howto_data['steps'] as $index => $step) {
                        ?>
                        <div class="wpigo-howto-step" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; background: #f9f9f9; border-radius: 4px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <strong>Step <?php echo ($index + 1); ?></strong>
                                <button type="button" class="button wpigo-remove-step" style="background: #d63638; color: white; border-color: #d63638;">Remove</button>
                            </div>
                            <p style="margin-bottom: 5px;">
                                <input type="text" name="howto_step_name[]" value="<?php echo esc_attr($step['name']); ?>" placeholder="Step name (e.g., Upload the plugin)" style="width: 100%; padding: 8px; font-size: 14px;">
                            </p>
                            <p>
                                <textarea name="howto_step_text[]" rows="3" placeholder="Detailed instructions for this step..." style="width: 100%; padding: 8px; font-size: 14px;"><?php echo esc_textarea($step['text']); ?></textarea>
                            </p>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>

            <button type="button" id="wpigo-add-step" class="button button-primary" style="margin-top: 10px;">
                + Add Step
            </button>
        </div>

        <script>
        (function($) {
            let stepCount = <?php echo (is_array($howto_data) && isset($howto_data['steps']) && is_array($howto_data['steps'])) ? count($howto_data['steps']) : 0; ?>;

            $('#wpigo-add-step').on('click', function() {
                stepCount++;
                const html = `
                    <div class="wpigo-howto-step" style="border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; background: #f9f9f9; border-radius: 4px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <strong>Step ${stepCount}</strong>
                            <button type="button" class="button wpigo-remove-step" style="background: #d63638; color: white; border-color: #d63638;">Remove</button>
                        </div>
                        <p style="margin-bottom: 5px;">
                            <input type="text" name="howto_step_name[]" placeholder="Step name (e.g., Upload the plugin)" style="width: 100%; padding: 8px; font-size: 14px;">
                        </p>
                        <p>
                            <textarea name="howto_step_text[]" rows="3" placeholder="Detailed instructions for this step..." style="width: 100%; padding: 8px; font-size: 14px;"></textarea>
                        </p>
                    </div>
                `;
                $('#wpigo-howto-steps').append(html);
            });

            $(document).on('click', '.wpigo-remove-step', function() {
                $(this).closest('.wpigo-howto-step').remove();
            });
        })(jQuery);
        </script>
        <?php
    }
}

// Save HowTo meta box data
if (!function_exists('wpigo_save_howto_meta_box')) {
    function wpigo_save_howto_meta_box($post_id) {
        // Security checks
        if (!isset($_POST['wpigo_howto_meta_nonce'])) {
            return;
        }
        if (!wp_verify_nonce($_POST['wpigo_howto_meta_nonce'], 'wpigo_save_howto_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Field POST'ta varsa kaydet, yoksa DOKUNMA
        if (isset($_POST['howto_title'])) {
            $howto_data = [
                'title' => trim(sanitize_text_field($_POST['howto_title'])),
                'description' => isset($_POST['howto_description']) ? trim(sanitize_textarea_field($_POST['howto_description'])) : '',
                'steps' => []
            ];

            if (isset($_POST['howto_step_name']) && isset($_POST['howto_step_text'])) {
                $step_names = $_POST['howto_step_name'];
                $step_texts = $_POST['howto_step_text'];

                // GÜVENLİK: Array size kontrolü
                if (!is_array($step_names) || !is_array($step_texts) || count($step_names) !== count($step_texts)) {
                    error_log("WPiGo HowTo Save ERROR: POST array mismatch!");
                    return;
                }

                for ($i = 0; $i < count($step_names); $i++) {
                    $step_name = trim($step_names[$i]);
                    $step_text = trim($step_texts[$i]);

                    if (!empty($step_name) && !empty($step_text)) {
                        $howto_data['steps'][] = [
                            'name' => sanitize_text_field($step_name),
                            'text' => sanitize_textarea_field($step_text)
                        ];
                    }
                }

                // GÜVENLİK: Veri kaybı kontrolü
                $existing_howto = get_post_meta($post_id, 'product_howto', true);
                $existing_count = 0;
                if (!empty($existing_howto)) {
                    $decoded = json_decode($existing_howto, true);
                    if (is_array($decoded) && isset($decoded['steps'])) {
                        $existing_count = count($decoded['steps']);
                    }
                }

                if ($existing_count > 5 && count($howto_data['steps']) < ($existing_count / 2)) {
                    error_log("WPiGo HowTo Save ERROR: Suspicious data loss! Old: {$existing_count}, New: " . count($howto_data['steps']));
                    return;
                }
            }

            // JSON encode et
            $json_data = json_encode($howto_data, JSON_UNESCAPED_UNICODE);

            // CRITICAL: JSON encoding başarısız mı?
            if ($json_data === false || json_last_error() !== JSON_ERROR_NONE) {
                $json_error = json_last_error_msg();
                error_log("WPiGo HowTo Save ERROR: JSON encoding failed! Error: {$json_error}");
                add_action('admin_notices', function() use ($json_error) {
                    echo '<div class="notice notice-error"><p><strong>HowTo Kaydetme HATASI!</strong> JSON Error: ' . esc_html($json_error) . '</p></div>';
                });
                return;
            }

            update_post_meta($post_id, 'product_howto', $json_data);
        }
    }
    add_action('save_post', 'wpigo_save_howto_meta_box');
}

/**
 * ===================================================================
 * Google PageSpeed & CLS/LCP Optimizations
 * ===================================================================
 */

// 1. Kritik (Critical) CSS'i <head> etiketine satır ii olarak ekler.
// Bu, sayfann üst kısmınn (above-the-fold) anında oluturulmasın sağlar ve LCP'yi iyileştirir.
if (!function_exists('wpigo_inline_critical_css')) {
    function wpigo_inline_critical_css() {
        // Sadece admin olmayan kullanıcılara ve ana sayfa dşındaki sayfalara uygula
        if ( is_admin() ) {
            return;
        }
        $critical_css_path = get_template_directory() . '/critical.css';
        if (file_exists($critical_css_path)) {
            $critical_css = file_get_contents($critical_css_path);
            echo '<style id="critical-css">' . $critical_css . '</style>';
        }
    }
    add_action('wp_head', 'wpigo_inline_critical_css', 1);
}

// 2. Ana stil dosyasını (style.css) erteleyerek yükler.
// Oluturmayı engellemeyi (render-blocking) önler.
if (!function_exists('wpigo_defer_main_stylesheet')) {
    function wpigo_defer_main_stylesheet() {
        if (is_admin()) {
            return;
        }
        // Orijinal 'marketplace-style' stilini kuyruktan çıkar
        wp_dequeue_style('marketplace-style');
        
        // Stili 'print' medyasıyla ekle ve 'onload' ile tüm medyaya uygula
        wp_enqueue_style('marketplace-style-deferred', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'), 'print');
    }
    // 'marketplace_theme_scripts' sonrası çalışmalı, bu yüzden öncelik 20.
    add_action('wp_enqueue_scripts', 'wpigo_defer_main_stylesheet', 20);
}


// 3. Ertelenen stil dosyasına 'onload' niteliği ekler ve <noscript> yedeği sağlar.
if (!function_exists('wpigo_add_stylesheet_onload_attribute')) {
    function wpigo_add_stylesheet_onload_attribute($html, $handle) {
        if ($handle === 'marketplace-style-deferred') {
            $html = str_replace("media='print'", "media='print' onload=\"this.media='all'\"", $html);
            $html .= "<noscript><link rel='stylesheet' href='" . get_stylesheet_uri() . "'></noscript>";
        }
        return $html;
    }
    add_filter('style_loader_tag', 'wpigo_add_stylesheet_onload_attribute', 10, 2);
}

/**
 * ===================================================================
 * JavaScript Optimizasyonu (Render-Blocking Önleme)
 * ===================================================================
 */
if (!function_exists('wpigo_defer_js_scripts')) {
    function wpigo_defer_js_scripts($tag, $handle) {
        // Sadece admin paneli dışnda çalşsın
        if (is_admin()) {
            return $tag;
        }
        
        // Defer edilecek script'lerin listesi
        $scripts_to_defer = array(
            'jquery-core',
            'jquery-migrate',
            'wpigo-product',
            'wpigo-shop'
        );

        if (in_array($handle, $scripts_to_defer)) {
            // 'defer' niteliğini ekle
            return str_replace(' src', ' defer src', $tag);
        }

        return $tag;
    }
    // Önceliği yüksek bir numara (99) olarak ayarlayarak diğer eklentilerden sonra çalışmasını sağlıyoruz.
    add_filter('script_loader_tag', 'wpigo_defer_js_scripts', 99, 2);
}

// ============================================
// GLOBAL ANNOUNCEMENT SYSTEM FOR LICENSE API
// ============================================

/**
 * Add announcement settings page to admin menu
 */
function wpigo_add_announcement_menu() {
    add_submenu_page(
        'options-general.php',
        'License API Announcements',
        'License Announcements',
        'manage_options',
        'wpigo-announcements',
        'wpigo_render_announcement_page'
    );
}
add_action('admin_menu', 'wpigo_add_announcement_menu');

/**
 * Register announcement settings
 */
function wpigo_register_announcement_settings() {
    register_setting('wpigo_announcement_group', 'wpigo_announcement_enabled');
    register_setting('wpigo_announcement_group', 'wpigo_announcement_message');
    register_setting('wpigo_announcement_group', 'wpigo_announcement_type');
    register_setting('wpigo_announcement_group', 'wpigo_announcement_id');
}
add_action('admin_init', 'wpigo_register_announcement_settings');

/**
 * Render announcement settings page
 */
function wpigo_render_announcement_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Save settings
    if (isset($_POST['wpigo_save_announcement'])) {
        check_admin_referer('wpigo_announcement_nonce');

        $enabled = isset($_POST['wpigo_announcement_enabled']) ? 1 : 0;
        $message = isset($_POST['wpigo_announcement_message']) ? wp_kses_post($_POST['wpigo_announcement_message']) : '';
        $type = isset($_POST['wpigo_announcement_type']) ? sanitize_text_field($_POST['wpigo_announcement_type']) : 'info';

        // Generate new ID when message changes or announcement is re-enabled
        $old_message = get_option('wpigo_announcement_message', '');
        $old_enabled = get_option('wpigo_announcement_enabled', 0);

        if ($message !== $old_message || ($enabled && !$old_enabled)) {
            update_option('wpigo_announcement_id', wp_generate_uuid4());
        }

        update_option('wpigo_announcement_enabled', $enabled);
        update_option('wpigo_announcement_message', $message);
        update_option('wpigo_announcement_type', $type);

        echo '<div class="notice notice-success is-dismissible"><p><strong>Announcement settings saved!</strong></p></div>';
    }

    $enabled = get_option('wpigo_announcement_enabled', 0);
    $message = get_option('wpigo_announcement_message', '');
    $type = get_option('wpigo_announcement_type', 'info');
    $announcement_id = get_option('wpigo_announcement_id', '');

    ?>
    <div class="wrap">
        <h1>License API Announcements</h1>
        <p>Send important announcements to all sites using your licensed plugins/themes via the License API.</p>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>Current Announcement</h2>

            <form method="post" action="">
                <?php wp_nonce_field('wpigo_announcement_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="wpigo_announcement_enabled">Enable Announcement</label>
                        </th>
                        <td>
                            <label>
                                <input
                                    type="checkbox"
                                    id="wpigo_announcement_enabled"
                                    name="wpigo_announcement_enabled"
                                    value="1"
                                    <?php checked($enabled, 1); ?>
                                >
                                <strong>Show announcement to all license users</strong>
                            </label>
                            <p class="description">
                                When enabled, this announcement will be shown on all sites that use the License API,<br>
                                regardless of their license status (active or inactive).
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="wpigo_announcement_type">Announcement Type</label>
                        </th>
                        <td>
                            <select id="wpigo_announcement_type" name="wpigo_announcement_type" style="width: 200px;">
                                <option value="info" <?php selected($type, 'info'); ?>>ℹ️ Info (Blue)</option>
                                <option value="success" <?php selected($type, 'success'); ?>>✅ Success (Green)</option>
                                <option value="warning" <?php selected($type, 'warning'); ?>>⚠️ Warning (Yellow)</option>
                                <option value="error" <?php selected($type, 'error'); ?>> Error (Red)</option>
                            </select>
                            <p class="description">Choose the visual style of the announcement.</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="wpigo_announcement_message">Announcement Message</label>
                        </th>
                        <td>
                            <textarea
                                id="wpigo_announcement_message"
                                name="wpigo_announcement_message"
                                rows="5"
                                style="width: 100%; max-width: 600px;"
                                placeholder="Enter your announcement message here. HTML is allowed."
                            ><?php echo esc_textarea($message); ?></textarea>
                            <p class="description">
                                Write your announcement message. Basic HTML tags are allowed (strong, em, a, br, etc.).<br>
                                <strong>Note:</strong> Changing the message will create a new announcement ID, so users will see it even if they dismissed the previous one.
                            </p>
                        </td>
                    </tr>
                </table>

                <?php if (!empty($announcement_id)) : ?>
                <p style="color: #666; font-size: 12px;">
                    <strong>Current Announcement ID:</strong> <code><?php echo esc_html($announcement_id); ?></code>
                </p>
                <?php endif; ?>

                <p class="submit">
                    <button type="submit" name="wpigo_save_announcement" class="button button-primary">
                        Save Announcement Settings
                    </button>
                </p>
            </form>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>Preview</h2>
            <?php if ($enabled && !empty($message)) : ?>
                <div class="notice notice-<?php echo esc_attr($type); ?>" style="padding: 15px;">
                    <p style="margin: 0;">
                        <?php echo wp_kses_post($message); ?>
                    </p>
                </div>
            <?php else : ?>
                <p style="color: #666;">No announcement active. Enable and write a message to see preview.</p>
            <?php endif; ?>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>How It Works</h2>
            <ol>
                <li><strong>Write your message:</strong> Enter the announcement text above</li>
                <li><strong>Choose type:</strong> Select info, success, warning, or error</li>
                <li><strong>Enable it:</strong> Check the "Enable Announcement" checkbox</li>
                <li><strong>Save:</strong> Click "Save Announcement Settings"</li>
                <li><strong>Distribution:</strong> The announcement will be sent via License API to all sites on their next license check</li>
                <li><strong>Dismissible:</strong> Users can dismiss the announcement. If you change the message, they'll see it again</li>
            </ol>
        </div>
    </div>
    <?php
}

/**
 * Get current announcement data for API response
 */
function wpigo_get_announcement_data() {
    $enabled = get_option('wpigo_announcement_enabled', 0);

    if (!$enabled) {
        return null;
    }

    $message = get_option('wpigo_announcement_message', '');
    if (empty($message)) {
        return null;
    }

    return array(
        'enabled' => true,
        'id' => get_option('wpigo_announcement_id', wp_generate_uuid4()),
        'message' => $message,
        'type' => get_option('wpigo_announcement_type', 'info')
    );
}

/**
 * ===================================================================
 * AJAX Handler: Auto-fill FAQ and How-To data
 * ===================================================================
 * This allows console scripts to directly save FAQ/How-To data via AJAX
 */
add_action('wp_ajax_wpigo_save_faq_howto', 'wpigo_ajax_save_faq_howto');

function wpigo_ajax_save_faq_howto() {
    // Security check
    check_ajax_referer('wpigo-ajax-nonce', 'nonce');

    // Get post ID
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

    if (empty($post_id)) {
        wp_send_json_error(array('message' => 'Post ID is required'));
    }

    // Check if user can edit this post
    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'You do not have permission to edit this post'));
    }

    // Check if post exists
    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error(array('message' => 'Post not found'));
    }

    $results = array();

    // ============================================
    // SAVE FAQ DATA
    // ============================================
    if (isset($_POST['faq_data'])) {
        $faq_questions = isset($_POST['faq_data']['questions']) ? $_POST['faq_data']['questions'] : array();
        $faq_answers = isset($_POST['faq_data']['answers']) ? $_POST['faq_data']['answers'] : array();

        if (!empty($faq_questions) && !empty($faq_answers)) {
            $faq_items = array();

            foreach ($faq_questions as $index => $question) {
                if (!empty($question) && !empty($faq_answers[$index])) {
                    $faq_items[] = array(
                        'question' => sanitize_text_field($question),
                        'answer' => wp_kses_post($faq_answers[$index])
                    );
                }
            }

            if (!empty($faq_items)) {
                $json_data = json_encode($faq_items, JSON_UNESCAPED_UNICODE);
                if (json_last_error() === JSON_ERROR_NONE) {
                    update_post_meta($post_id, 'product_faq', $json_data);
                    $results['faq'] = array(
                        'success' => true,
                        'count' => count($faq_items),
                        'message' => count($faq_items) . ' FAQ items saved'
                    );
                } else {
                    $results['faq'] = array(
                        'success' => false,
                        'message' => 'JSON encoding failed: ' . json_last_error_msg()
                    );
                }
            } else {
                delete_post_meta($post_id, 'product_faq');
                $results['faq'] = array(
                    'success' => true,
                    'count' => 0,
                    'message' => 'FAQ data cleared (no valid items)'
                );
            }
        } else {
            delete_post_meta($post_id, 'product_faq');
            $results['faq'] = array(
                'success' => true,
                'count' => 0,
                'message' => 'FAQ data cleared'
            );
        }
    }

    // ============================================
    // SAVE HOW-TO DATA
    // ============================================
    if (isset($_POST['howto_data'])) {
        $howto_title = isset($_POST['howto_data']['title']) ? sanitize_text_field($_POST['howto_data']['title']) : '';
        $howto_step_names = isset($_POST['howto_data']['step_names']) ? $_POST['howto_data']['step_names'] : array();
        $howto_step_texts = isset($_POST['howto_data']['step_texts']) ? $_POST['howto_data']['step_texts'] : array();

        if (!empty($howto_title) && !empty($howto_step_names) && !empty($howto_step_texts)) {
            $howto_steps = array();

            foreach ($howto_step_names as $index => $step_name) {
                if (!empty($step_name) && !empty($howto_step_texts[$index])) {
                    $howto_steps[] = array(
                        'name' => sanitize_text_field($step_name),
                        'text' => wp_kses_post($howto_step_texts[$index])
                    );
                }
            }

            if (!empty($howto_steps)) {
                $howto_data = array(
                    'title' => $howto_title,
                    'steps' => $howto_steps
                );

                $json_data = json_encode($howto_data, JSON_UNESCAPED_UNICODE);
                if (json_last_error() === JSON_ERROR_NONE) {
                    update_post_meta($post_id, 'product_howto', $json_data);
                    $results['howto'] = array(
                        'success' => true,
                        'count' => count($howto_steps),
                        'message' => 'How-To saved with ' . count($howto_steps) . ' steps'
                    );
                } else {
                    $results['howto'] = array(
                        'success' => false,
                        'message' => 'JSON encoding failed: ' . json_last_error_msg()
                    );
                }
            } else {
                delete_post_meta($post_id, 'product_howto');
                $results['howto'] = array(
                    'success' => true,
                    'count' => 0,
                    'message' => 'How-To data cleared (no valid steps)'
                );
            }
        } else {
            delete_post_meta($post_id, 'product_howto');
            $results['howto'] = array(
                'success' => true,
                'count' => 0,
                'message' => 'How-To data cleared'
            );
        }
    }

    wp_send_json_success($results);
}

/**
 * Enqueue admin script to add nonce for AJAX
 */
add_action('admin_enqueue_scripts', 'wpigo_enqueue_ajax_nonce');

function wpigo_enqueue_ajax_nonce($hook) {
    if ($hook == 'post-new.php' || $hook == 'post.php') {
        wp_localize_script('jquery', 'wpigoAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wpigo-ajax-nonce')
        ));
    }
}

/**
 * WordPress Emoji betiklerini devre dışı bırak.
 */
function disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'disable_emojis');

/**
 * jQuery Migrate betiğini kaldır.
 */
function remove_jquery_migrate($scripts) {
    if (!is_admin() && isset($scripts->registered['jquery'])) {
        $script = $scripts->registered['jquery'];
        if ($script->deps) { 
            // 'jquery-migrate' bağımlılığnı kaldır
            $script->deps = array_diff($script->deps, array('jquery-migrate'));
        }
    }
}
add_action('wp_default_scripts', 'remove_jquery_migrate');

// ============================================================================
// WPIGO DEMO SITE AUTOMATION
// ============================================================================
// Automatically creates demo sites on demo.wpigo.com when products are saved
// Version: 1.0.0
// ============================================================================

/**
 * Create or update demo site when product is saved
 */
add_action('save_post', 'wpigo_create_demo_site', 20, 3);

// functions.php - (yaklaşk 880. satır)
function wpigo_create_demo_site($post_id, $post, $update) {
    global $wpigo_current_post_id;
    $wpigo_current_post_id = $post_id; // Log fonksiyonu iin global değişken

    // Check if this is the right post type
    if ($post->post_type !== 'post') {
        return;
    }

    // Check for autosave/revision
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check if nonce is set (from the file meta box)
    if (!isset($_POST['wpigo_product_file_nonce'])) {
        return;
    }

    // Check if create_demo_site checkbox is checked
    if (!isset($_POST['create_demo_site']) || $_POST['create_demo_site'] != '1') {
        return;
    }

    // Get product information
    $product_name = get_the_title($post_id);
    $product_slug = $post->post_name;

    if (empty($product_slug)) {
        $product_slug = sanitize_title($product_name);
    }

    // Get product meta
    // DÜZELTME: 'product_short_description' yerine sizin SEO kutunuz olan 'product_description' alıyoruz
    $short_desc = get_post_meta($post_id, 'product_description', true);
    $features = get_post_meta($post_id, 'product_features', true);
    $plugin_file_id = get_post_meta($post_id, '_product_file_id', true);

    // --- YENİ EKLENEN KOD BAŞLANGICI ---
    // Fiyatı ve ana site URL'sini al
    $price = get_post_meta($post_id, 'product_price', true);
    $purchase_url = get_permalink($post_id);
    // --- YENİ EKLENEN KOD BİTİŞİ ---


    // --- YENİ & GÜNCELLENMİŞ --- Ürün tipini post meta'dan al
    $product_type = get_post_meta($post_id, '_product_type', true);
    if (empty($product_type)) {
        $product_type = 'plugin'; // Varsaylan değer
    }

    // Check if product file exists
    if (empty($plugin_file_id)) {
        update_post_meta($post_id, 'demo_site_status', '❌ Error: No product file uploaded');
        return;
    }

    $product_file_url = wp_get_attachment_url($plugin_file_id);

    if (empty($product_file_url)) {
        update_post_meta($post_id, 'demo_site_status', '❌ Error: Could not get product file URL');
        return;
    }

    // Prepare data for API
    $demo_data = array(
        'product_slug' => $product_slug,
        'product_name' => $product_name,
        'short_description' => $short_desc,
        'long_description' => get_post_field('post_content', $post_id),
        'features' => $features,
        'product_url' => $product_file_url, // 'plugin_url' -> 'product_url' olarak değiştirildi
        'product_type' => $product_type, // Yeni eklendi
        
        // --- YENİ EKLENEN KOD BAŞLANGICI ---
        'product_price' => $price,
        'purchase_url' => $purchase_url,
        // --- YENİ EKLENEN KOD BİTŞİ ---
    );

    // Update status to "creating"
    update_post_meta($post_id, 'demo_site_status', '⏳ Creating demo site...');

    // Call multisite API
    $result = wpigo_call_multisite_api($demo_data);

    // Update meta based on result
    if ($result['success']) {
        update_post_meta($post_id, 'demo_site_url', $result['demo_url']);
        update_post_meta($post_id, 'demo_site_status',
            "✅ Demo site {$result['action']} successfully!\n" .
            "Created: " . current_time('Y-m-d H:i:s') . "\n" .
            "Asset Installed: " . ($result['asset_installed'] ? 'Yes' : 'No') // 'plugin_installed' -> 'asset_installed'
        );
    } else {
        update_post_meta($post_id, 'demo_site_status',
            "❌ Error: {$result['message']}\n" .
            "Time: " . current_time('Y-m-d H:i:s')
        );
    }
}

/**
 * Call multisite API to create/update demo site
 */
function wpigo_call_multisite_api($demo_data) {
    global $wpigo_current_post_id;

    $multisite_url = 'https://demo.wpigo.com/wp-json/wpigo/v1/create-demo';
    $api_key = 'wpigo_secure_key_2024_sgkd27fg30seka'; // ← CHANGE THIS TO MATCH DEMO SITE!

    // ============================================================================
    // DETAILED LOGGING - BAŞLANGIÇ
    // ============================================================================
    $log_entry = array(
        'timestamp' => current_time('Y-m-d H:i:s'),
        'request_url' => $multisite_url,
        'request_method' => 'POST',
        'request_headers' => array(
            'Content-Type' => 'application/json',
            'X-WPigo-API-Key' => substr($api_key, 0, 20) . '...' // Gvenlik için sadece ilk 20 karakter
        ),
        'request_body' => $demo_data,
        'request_body_json' => json_encode($demo_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
    );

    $response = wp_remote_post($multisite_url, array(
        'timeout' => 60,
        'headers' => array(
            'Content-Type' => 'application/json',
            'X-WPigo-API-Key' => $api_key,
        ),
        'body' => json_encode($demo_data),
    ));

    // WP_Error kontrol
    if (is_wp_error($response)) {
        $log_entry['response_type'] = 'WP_ERROR';
        $log_entry['error_message'] = $response->get_error_message();
        $log_entry['error_code'] = $response->get_error_code();
        $log_entry['success'] = false;

        // Log kaydet
        wpigo_save_api_log($wpigo_current_post_id, $log_entry);

        return array(
            'success' => false,
            'message' => $response->get_error_message(),
        );
    }

    // Response bilgilerini log'a ekle
    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $response_headers = wp_remote_retrieve_headers($response);

    $log_entry['response_code'] = $status_code;
    $log_entry['response_body_raw'] = $body;
    $log_entry['response_headers'] = $response_headers->getAll();

    // Body'yi parse et
    $data = json_decode($body, true);
    $log_entry['response_body_parsed'] = $data;

    if ($status_code !== 200) {
        $error_message = isset($data['message']) ? $data['message'] : 'HTTP ' . $status_code;

        $log_entry['response_type'] = 'HTTP_ERROR';
        $log_entry['error_message'] = $error_message;
        $log_entry['success'] = false;

        // Log kaydet
        wpigo_save_api_log($wpigo_current_post_id, $log_entry);

        return array(
            'success' => false,
            'message' => $error_message,
        );
    }

    if (isset($data['success']) && $data['success']) {
        $log_entry['response_type'] = 'SUCCESS';
        $log_entry['success'] = true;
        $log_entry['demo_url'] = isset($data['demo_url']) ? $data['demo_url'] : 'N/A';
        $log_entry['action'] = isset($data['action']) ? $data['action'] : 'N/A';
        $log_entry['site_id'] = isset($data['site_id']) ? $data['site_id'] : 'N/A';

        // Log kaydet
        wpigo_save_api_log($wpigo_current_post_id, $log_entry);

        return array(
            'success' => true,
            'demo_url' => $data['demo_url'],
            'action' => $data['action'],
            'asset_installed' => isset($data['asset_installed']) ? $data['asset_installed'] : false, // 'plugin_installed' -> 'asset_installed'
        );
    } else {
        $log_entry['response_type'] = 'API_ERROR';
        $log_entry['error_message'] = isset($data['message']) ? $data['message'] : 'Unknown error from API';
        $log_entry['success'] = false;

        // Log kaydet
        wpigo_save_api_log($wpigo_current_post_id, $log_entry);

        return array(
            'success' => false,
            'message' => isset($data['message']) ? $data['message'] : 'Unknown error from API',
        );
    }
}

/**
 * Save detailed API log to post meta
 */
function wpigo_save_api_log($post_id, $log_entry) {
    if (empty($post_id)) {
        return;
    }

    // Mevcut logları al
    $logs = get_post_meta($post_id, '_wpigo_api_logs', true);

    if (!is_array($logs)) {
        $logs = array();
    }

    // Yeni log'u ekle
    array_unshift($logs, $log_entry);

    // Son 20 log'u sakla
    $logs = array_slice($logs, 0, 20);

    // Kaydet
    update_post_meta($post_id, '_wpigo_api_logs', $logs);
}

/**
 * Add demo site column to product list
 */
add_filter('manage_posts_columns', 'wpigo_add_demo_column');
function wpigo_add_demo_column($columns) {
    global $typenow;
    if ($typenow !== 'post') {
        return $columns;
    }

    $new_columns = array();
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key === 'title') {
            $new_columns['demo_actions'] = 'Demo Site';
        }
    }
    return $new_columns;
}

/**
 * Display demo site column content
 */
add_action('manage_posts_custom_column', 'wpigo_demo_column_content', 10, 2);
function wpigo_demo_column_content($column, $post_id) {
    if ($column === 'demo_actions') {
        $demo_url = get_post_meta($post_id, 'demo_site_url', true);
        $status = get_post_meta($post_id, 'demo_site_status', true);

        if ($demo_url) {
            echo '<div style="display: flex; flex-direction: column; gap: 5px;">';
            echo '<a href="' . esc_url($demo_url) . '" target="_blank" class="button button-small" style="text-align: center;">
                <span class="dashicons dashicons-external" style="font-size: 13px; margin-top: 3px;"></span> View Demo
            </a>';
            echo '<button class="button button-small wpigo-sync-demo" data-post-id="' . $post_id . '" style="text-align: center;">
                <span class="dashicons dashicons-update" style="font-size: 13px; margin-top: 3px;"></span> Sync
            </button>';

            if (strpos($status, '✅') !== false) {
                echo '<small style="color: #46b450; font-size: 11px;">● Active</small>';
            } elseif (strpos($status, '') !== false) {
                echo '<small style="color: #d63638; font-size: 11px;"> Error</small>';
            } else {
                echo '<small style="color: #f0b849; font-size: 11px;">● Pending</small>';
            }
            echo '</div>';
        } else {
            echo '<small style="color: #999; font-size: 11px;">No demo site</small>';
        }
    }
}

/**
 * AJAX handler for sync button
 */
add_action('wp_ajax_wpigo_sync_demo', 'wpigo_sync_demo_ajax');

function wpigo_sync_demo_ajax() {
    global $wpigo_current_post_id;

    check_ajax_referer('wpigo_sync_demo', 'nonce');

    $post_id = intval($_POST['post_id']);
    $wpigo_current_post_id = $post_id; // Log için global değişken ayarla

    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error('Permission denied');
    }

    // Simulate the checkbox being checked
    $_POST['create_demo_site'] = '1';
    $_POST['wpigo_product_file_nonce'] = wp_create_nonce('wpigo_product_file_meta_box');

    $post = get_post($post_id);
    wpigo_create_demo_site($post_id, $post, true);

    $new_status = get_post_meta($post_id, 'demo_site_status', true);
    $demo_url = get_post_meta($post_id, 'demo_site_url', true);

    wp_send_json_success(array(
        'message' => 'Demo site synced successfully',
        'status' => $new_status,
        'url' => $demo_url,
    ));
}

/**
 * Admin JavaScript for sync button
 */
add_action('admin_footer', 'wpigo_demo_sync_js');

function wpigo_demo_sync_js() {
    $screen = get_current_screen();
    if (!$screen || ($screen->post_type !== 'post' && $screen->id !== 'edit-post')) {
        return;
    }
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('.wpigo-sync-demo').on('click', function(e) {
            e.preventDefault();

            var button = $(this);
            var postId = button.data('post-id');
            var buttonText = button.html();

            button.prop('disabled', true)
                  .html('<span class="dashicons dashicons-update spin" style="font-size: 13px; margin-top: 3px;"></span> Syncing...');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wpigo_sync_demo',
                    post_id: postId,
                    nonce: '<?php echo wp_create_nonce('wpigo_sync_demo'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        button.html('<span class="dashicons dashicons-yes" style="font-size: 13px; margin-top: 3px; color: #46b450;"></span> Synced!');

                        setTimeout(function() {
                            button.html(buttonText).prop('disabled', false);
                            location.reload();
                        }, 1500);
                    } else {
                        alert('Error: ' + response.data);
                        button.html(buttonText).prop('disabled', false);
                    }
                },
                error: function() {
                    alert('AJAX error occurred');
                    button.html(buttonText).prop('disabled', false);
                }
            });
        });
    });
    </script>
    <style>
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .dashicons.spin {
            animation: spin 1s linear infinite;
        }
    </style>
    <?php
}

/**
 * Add API Debug Logs meta box
 */
add_action('add_meta_boxes', 'wpigo_add_api_logs_meta_box');

function wpigo_add_api_logs_meta_box() {
    add_meta_box(
        'wpigo_api_logs',
        '🔍 Demo Site API Debug Logs',
        'wpigo_api_logs_meta_box_callback',
        'post',
        'normal',
        'high'
    );
}

function wpigo_api_logs_meta_box_callback($post) {
    $logs = get_post_meta($post->ID, '_wpigo_api_logs', true);

    if (empty($logs) || !is_array($logs)) {
        echo '<div style="padding: 15px; background: #f0f0f0; border-left: 4px solid #999; margin: 10px 0;">';
        echo '<p style="margin: 0; color: #666;">No API logs yet. Save the post with "Create/Update Demo Site" checkbox to see logs.</p>';
        echo '</div>';
        return;
    }

    echo '<div style="margin: 10px 0;">';
    echo '<p style="font-size: 13px; color: #666; margin-bottom: 15px;">Showing last ' . count($logs) . ' API requests. Click on each log to expand details.</p>';

    foreach ($logs as $index => $log) {
        $success = isset($log['success']) ? $log['success'] : false;
        $timestamp = isset($log['timestamp']) ? $log['timestamp'] : 'N/A';
        $response_type = isset($log['response_type']) ? $log['response_type'] : 'UNKNOWN';

        // Renk belirleme
        if ($success) {
            $color = '#46b450';
            $icon = '';
            $status_text = 'SUCCESS';
        } else {
            $color = '#d63638';
            $icon = '';
            $status_text = 'FAILED';
        }

        // Log balığı
        echo '<details style="margin-bottom: 10px; border: 2px solid ' . $color . '; border-radius: 4px; background: #fff;">';
        echo '<summary style="padding: 12px; cursor: pointer; background: ' . $color . '20; font-weight: 600; border-bottom: 1px solid ' . $color . ';">';
        echo $icon . ' ' . $status_text . ' - ' . $timestamp . ' (' . $response_type . ')';
        echo '</summary>';

        echo '<div style="padding: 15px; font-family: monospace; font-size: 12px;">';

        // REQUEST SECTION
        echo '<div style="margin-bottom: 20px;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #0073aa; border-bottom: 2px solid #0073aa; padding-bottom: 5px;"> REQUEST</h4>';

        echo '<p style="margin: 5px 0;"><strong>URL:</strong> <code>' . esc_html($log['request_url']) . '</code></p>';
        echo '<p style="margin: 5px 0;"><strong>Method:</strong> <code>' . esc_html($log['request_method']) . '</code></p>';

        echo '<p style="margin: 5px 0;"><strong>Headers:</strong></p>';
        echo '<pre style="background: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto;">';
        print_r($log['request_headers']);
        echo '</pre>';

        echo '<p style="margin: 5px 0;"><strong>Body (JSON):</strong></p>';
        echo '<pre style="background: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 300px;">';
        echo esc_html($log['request_body_json']);
        echo '</pre>';
        echo '</div>';

        // RESPONSE SECTION
        echo '<div>';
        echo '<h4 style="margin: 0 0 10px 0; color: ' . ($success ? '#46b450' : '#d63638') . '; border-bottom: 2px solid ' . ($success ? '#46b450' : '#d63638') . '; padding-bottom: 5px;"> RESPONSE</h4>';

        if (isset($log['response_code'])) {
            $code_color = ($log['response_code'] == 200) ? '#46b450' : '#d63638';
            echo '<p style="margin: 5px 0;"><strong>HTTP Status Code:</strong> <code style="background: ' . $code_color . '20; color: ' . $code_color . '; padding: 3px 8px; border-radius: 3px; font-weight: bold;">' . esc_html($log['response_code']) . '</code></p>';
        }

        if (isset($log['error_message'])) {
            echo '<p style="margin: 5px 0;"><strong style="color: #d63638;">Error Message:</strong> <code style="background: #ffc1c1; padding: 5px 10px; border-radius: 3px;">' . esc_html($log['error_message']) . '</code></p>';
        }

        if (isset($log['error_code'])) {
            echo '<p style="margin: 5px 0;"><strong>Error Code:</strong> <code>' . esc_html($log['error_code']) . '</code></p>';
        }

        if (isset($log['demo_url'])) {
            echo '<p style="margin: 5px 0;"><strong style="color: #46b450;">Demo URL:</strong> <a href="' . esc_url($log['demo_url']) . '" target="_blank" style="color: #0073aa;">' . esc_html($log['demo_url']) . '</a></p>';
        }

        if (isset($log['action'])) {
            echo '<p style="margin: 5px 0;"><strong>Action:</strong> <code>' . esc_html($log['action']) . '</code></p>';
        }

        if (isset($log['site_id'])) {
            echo '<p style="margin: 5px 0;"><strong>Site ID:</strong> <code>' . esc_html($log['site_id']) . '</code></p>';
        }

        if (isset($log['response_headers']) && !empty($log['response_headers'])) {
            echo '<p style="margin: 10px 0 5px 0;"><strong>Response Headers:</strong></p>';
            echo '<pre style="background: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 200px;">';
            print_r($log['response_headers']);
            echo '</pre>';
        }

        echo '<p style="margin: 10px 0 5px 0;"><strong>Response Body (Raw):</strong></p>';
        echo '<pre style="background: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 300px;">';
        echo esc_html($log['response_body_raw']);
        echo '</pre>';

        if (isset($log['response_body_parsed']) && !empty($log['response_body_parsed'])) {
            echo '<p style="margin: 10px 0 5px 0;"><strong>Response Body (Parsed):</strong></p>';
            echo '<pre style="background: #f5f5f5; padding: 10px; border-radius: 3px; overflow-x: auto; max-height: 300px;">';
            print_r($log['response_body_parsed']);
            echo '</pre>';
        }

        echo '</div>';

        echo '</div>'; // End of log content
        echo '</details>';
    }

    echo '</div>';

    // Clear logs button
    echo '<div style="margin-top: 15px; padding: 10px; background: #f0f0f0; border-radius: 4px;">';
    echo '<button type="button" class="button" id="wpigo-clear-logs" data-post-id="' . $post->ID . '">🗑️ Clear All Logs</button>';
    echo '<span id="wpigo-clear-logs-status" style="margin-left: 10px; color: #46b450; display: none;"></span>';
    echo '</div>';

    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#wpigo-clear-logs').on('click', function() {
            if (!confirm('Are you sure you want to clear all API logs?')) {
                return;
            }

            var button = $(this);
            var postId = button.data('post-id');
            var status = $('#wpigo-clear-logs-status');

            button.prop('disabled', true).text(' Clearing...');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wpigo_clear_api_logs',
                    post_id: postId,
                    nonce: '<?php echo wp_create_nonce('wpigo_clear_logs'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        status.text('✅ Logs cleared!').show();
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        alert('Error: ' + response.data);
                        button.prop('disabled', false).text(' Clear All Logs');
                    }
                },
                error: function() {
                    alert('AJAX error occurred');
                    button.prop('disabled', false).text('🗑️ Clear All Logs');
                }
            });
        });
    });
    </script>
    <?php
}

/**
 * AJAX handler to clear logs
 */
add_action('wp_ajax_wpigo_clear_api_logs', 'wpigo_clear_api_logs_ajax');

function wpigo_clear_api_logs_ajax() {
    check_ajax_referer('wpigo_clear_logs', 'nonce');

    $post_id = intval($_POST['post_id']);

    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error('Permission denied');
    }

    delete_post_meta($post_id, '_wpigo_api_logs');

    wp_send_json_success(array('message' => 'Logs cleared successfully'));
}
// Completely override WordPress title
remove_action('wp_head', '_wp_render_title_tag', 1);

add_action('wp_head', 'wpigo_manual_title_tag', 1);

function wpigo_manual_title_tag() {
    $site_name = 'WPiGo';
    
    if (is_front_page() || is_home()) {
        // Ana sayfada tam aıklama olsun
        $title = get_bloginfo('name') . ' – ' . get_bloginfo('description');
    } elseif (is_singular()) {
        $title = get_the_title() . ' | ' . $site_name;
    } elseif (is_category()) {
        $title = single_cat_title('', false) . ' | ' . $site_name;
    } elseif (is_tag()) {
        $title = single_tag_title('', false) . ' | ' . $site_name;
    } elseif (is_archive()) {
        $title = get_the_archive_title() . ' | ' . $site_name;
    } elseif (is_search()) {
        $title = 'Search: ' . get_search_query() . ' | ' . $site_name;
    } elseif (is_404()) {
        $title = 'Page Not Found | ' . $site_name;
    } else {
        $title = $site_name;
    }
    
    echo '<title>' . esc_html($title) . '</title>' . "\n";
}
// ============================================================================
// END OF WPIGO DEMO SITE AUTOMATION

// ============================================================================
// COMMENT RATING SYSTEM
// ============================================================================

/**
 * Get rating field HTML (reverse order 5-1 for CSS-only rating system in critical.css)
 */
function wpigo_get_rating_field_html() {
    return '<p class="comment-form-rating">
        <label for="rating">' . __('Your Rating', 'wpigo') . ' <span class="required">*</span></label>
        <span class="comment-form-rating-stars">
            <input type="radio" id="rating-5" name="rating" value="5" required />
            <label for="rating-5" title="5 stars">★</label>
            <input type="radio" id="rating-4" name="rating" value="4" />
            <label for="rating-4" title="4 stars">★</label>
            <input type="radio" id="rating-3" name="rating" value="3" />
            <label for="rating-3" title="3 stars">★</label>
            <input type="radio" id="rating-2" name="rating" value="2" />
            <label for="rating-2" title="2 stars">★</label>
            <input type="radio" id="rating-1" name="rating" value="1" />
            <label for="rating-1" title="1 star">★</label>
        </span>
    </p>';
}

/**
 * Add rating field to comment form for guests (non-logged in users)
 */
function wpigo_add_comment_rating_field($fields) {
    $fields['rating'] = wpigo_get_rating_field_html();
    return $fields;
}
add_filter('comment_form_default_fields', 'wpigo_add_comment_rating_field');

/**
 * Add rating field to comment form for logged in users
 */
function wpigo_add_comment_rating_field_logged_in() {
    echo wpigo_get_rating_field_html();
}
add_action('comment_form_logged_in_after', 'wpigo_add_comment_rating_field_logged_in');

/**
 * Validate and save comment rating
 */
function wpigo_save_comment_rating($comment_id) {
    if (isset($_POST['rating']) && !empty($_POST['rating'])) {
        $rating = intval($_POST['rating']);
        if ($rating >= 1 && $rating <= 5) {
            add_comment_meta($comment_id, 'rating', $rating);
        }
    }
}
add_action('comment_post', 'wpigo_save_comment_rating');

/**
 * Require rating field
 */
function wpigo_require_comment_rating($commentdata) {
    if (!is_admin() && (!isset($_POST['rating']) || empty($_POST['rating']))) {
        wp_die(__('Error: Please select a rating. Click the Back button on your browser and try again.', 'wpigo'));
    }
    return $commentdata;
}
add_filter('preprocess_comment', 'wpigo_require_comment_rating');

/**
 * Display star rating in comment
 */
function wpigo_display_comment_rating($comment_text, $comment = null) {
    if (!$comment) {
        return $comment_text;
    }

    $rating = get_comment_meta($comment->comment_ID, 'rating', true);
    if ($rating) {
        $stars = wpigo_generate_stars(intval($rating));
        $rating_html = '<div class="comment-rating-display">' . $stars . '</div>';
        $comment_text = $rating_html . $comment_text;
    }

    return $comment_text;
}
add_filter('comment_text', 'wpigo_display_comment_rating', 10, 2);

/**
 * Get comment rating (helper function for schema)
 */
function wpigo_get_comment_rating($comment_id) {
    return get_comment_meta($comment_id, 'rating', true);
}

// CSS is already in critical.css - no need for additional styles

// ============================================================================
// END OF COMMENT RATING SYSTEM
// ============================================================================
// ============================================================================
