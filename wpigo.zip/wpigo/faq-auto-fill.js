/**
 * FAQ Auto-Fill Script
 * Bu dosyayi edit post sayfasinda F12 Console'dan yukleyin
 * Kullanim: Console'a su komutu yapistirin:
 *
 * fetch('/wp-content/themes/wpigo/faq-auto-fill.js').then(r=>r.text()).then(eval)
 *
 * VEYA bu dosyanin iceriğini kopyalayip console'a yapistirin
 */

(function() {
    var faqData = [
        {
            question: "How do I install this plugin?",
            answer: "Simply upload the plugin ZIP file through WordPress admin panel (Plugins > Add New > Upload), activate it, and you are ready to go. Detailed installation guide is included in the documentation."
        },
        {
            question: "Is this plugin compatible with the latest WordPress version?",
            answer: "Yes, this plugin is fully compatible with WordPress 6.0 and above. We regularly test and update our plugin to ensure compatibility with the latest WordPress releases."
        },
        {
            question: "Do you provide support and updates?",
            answer: "Absolutely! We provide lifetime updates and 6 months of premium support with every purchase. Extended support packages are also available. All updates are automatic and hassle-free."
        },
        {
            question: "Can I use this on multiple websites?",
            answer: "Your license allows installation on one production website. If you need to use it on multiple sites, please purchase additional licenses. We offer volume discounts for bulk purchases."
        },
        {
            question: "Is there a refund policy?",
            answer: "Yes, we offer a 15-day money-back guarantee. If you are not satisfied with the plugin for any reason, contact us within 15 days of purchase for a full refund, no questions asked."
        },
        {
            question: "Does this plugin slow down my website?",
            answer: "No, our plugin is optimized for performance with clean, efficient code. It uses minimal resources and includes built-in caching mechanisms to ensure your site runs fast."
        },
        {
            question: "How do I get the license key after purchase?",
            answer: "Your license key is automatically generated and sent to your email immediately after purchase. You can also find it in your account dashboard under My Purchases section."
        }
    ];

    var addButton = document.getElementById('wpigo-add-faq');
    if (!addButton) {
        console.error('FAQ meta box not found! Make sure you are on edit post page.');
        return;
    }

    console.log('FAQ auto-fill starting...');

    faqData.forEach(function(faq, index) {
        setTimeout(function() {
            addButton.click();

            setTimeout(function() {
                var allQuestions = document.querySelectorAll('input[name="faq_question[]"]');
                var allAnswers = document.querySelectorAll('textarea[name="faq_answer[]"]');

                var lastQuestion = allQuestions[allQuestions.length - 1];
                var lastAnswer = allAnswers[allAnswers.length - 1];

                if (lastQuestion && lastAnswer) {
                    lastQuestion.value = faq.question;
                    lastAnswer.value = faq.answer;
                    console.log('Question ' + (index + 1) + ' added: ' + faq.question);
                }
            }, 100);

        }, index * 300);
    });

    setTimeout(function() {
        console.log('Done! 7 FAQ questions added.');
        console.log('Now click Update button to save.');
    }, faqData.length * 300 + 500);
})();
