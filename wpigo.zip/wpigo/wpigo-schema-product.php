<?php
/**
 * Product & SoftwareApplication Schema
 *
 * Generates Schema.org markup for single product pages
 * Includes Product, SoftwareApplication, Review, and AggregateRating
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate Product + SoftwareApplication Schema
 *
 * @param int $post_id Post ID
 * @return string JSON-LD schema markup
 */
function wpigo_schema_product($post_id) {
    if (!$post_id) {
        return '';
    }

    // Get post data
    $price = get_post_meta($post_id, 'product_price', true);
    $version = get_post_meta($post_id, 'product_version', true);
    $software_os = get_post_meta($post_id, 'software_os', true);
    $software_category = get_post_meta($post_id, 'software_category', true);
    $ratings = wpigo_get_ratings($post_id);

    // Get image metadata
    $thumbnail_id = get_post_thumbnail_id($post_id);
    $image_full = wp_get_attachment_image_src($thumbnail_id, 'full');
    $image_thumb = wp_get_attachment_image_src($thumbnail_id, 'grid-thumbnail');
    $image_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);

    // Build image array (featured + gallery images)
    $images_array = [];

    // Featured image (detailed ImageObject)
    if ($image_full) {
        $images_array[] = [
            "@type" => "ImageObject",
            "url" => $image_full[0],
            "width" => $image_full[1],
            "height" => $image_full[2],
            "caption" => !empty($image_alt) ? $image_alt : get_the_title($post_id),
            "thumbnailUrl" => $image_thumb[0],
            "creator" => [
                "@type" => "Organization",
                "name" => "WPiGo"
            ],
            "copyrightHolder" => [
                "@type" => "Organization",
                "name" => "WPiGo"
            ],
            "creditText" => "WPiGo",
            "copyrightNotice" => "© " . date("Y") . " WPiGo. All Rights Reserved.",
            "license" => home_url('/license/'),
            "acquireLicensePage" => home_url('/license/')
        ];
    }

    // Gallery images (simple URLs)
    $gallery_images = get_attached_media('image', $post_id);
    foreach ($gallery_images as $attachment) {
        if ($attachment->ID !== $thumbnail_id) { // Skip featured image
            $image_url = wp_get_attachment_image_url($attachment->ID, 'full');
            if ($image_url) {
                $images_array[] = $image_url;
            }
        }
    }

    // Build combined Product + SoftwareApplication schema
    $schema = [
        "@context" => "https://schema.org",
        "@type" => ["Product", "SoftwareApplication"],
        "name" => get_the_title($post_id),
        "image" => $images_array,

        // Description priority: product_details > product_description > excerpt (NO LIMITS)
        "description" => (function() use ($post_id) {
            $product_details = get_post_meta($post_id, 'product_details', true);
            $product_desc = get_post_meta($post_id, 'product_description', true);

            if (!empty($product_details)) {
                return strip_tags($product_details); // Admin's full detailed content
            } elseif (!empty($product_desc)) {
                return strip_tags($product_desc); // Admin's SEO description
            } else {
                return get_the_excerpt($post_id); // Fallback to excerpt
            }
        })(),

        // Product-specific
        "sku" => "WP-" . $post_id,
        "mpn" => "WPIGO-" . $post_id,
        "brand" => [
            "@type" => "Brand",
            "name" => "WPiGo"
        ],
        "category" => (function() use ($post_id) {
            $categories = get_the_category($post_id);
            if (!empty($categories)) {
                $cat = $categories[0]; // Primary category

                // Get category hierarchy (parent to child)
                $ancestors = get_ancestors($cat->term_id, 'category');
                $ancestors = array_reverse($ancestors); // Top to bottom

                $hierarchy = [];
                foreach ($ancestors as $ancestor_id) {
                    $ancestor = get_category($ancestor_id);
                    $hierarchy[] = $ancestor->name;
                }
                $hierarchy[] = $cat->name; // Add current category

                return implode(' > ', $hierarchy);
            }
            return "WordPress Plugins & Themes"; // Fallback
        })(),
        "releaseDate" => get_the_date('c', $post_id),

        // SoftwareApplication-specific
        "operatingSystem" => !empty($software_os) ? $software_os : "WordPress 5.0+",
        "applicationCategory" => !empty($software_category) ? $software_category : "DeveloperApplication",
        "softwareVersion" => $version,
        "datePublished" => get_the_date('c', $post_id),

        // Offers
        "offers" => [
            "@type" => "Offer",
            "url" => get_permalink($post_id),
            "priceCurrency" => "USD",
            "price" => $price,
            "availability" => "https://schema.org/InStock",
            "priceValidUntil" => date('Y-m-d', strtotime('+1 year')), // Always future-dated
            "itemCondition" => "https://schema.org/NewCondition",
            "shippingDetails" => [
                "@type" => "OfferShippingDetails",
                "shippingRate" => [
                    "@type" => "MonetaryAmount",
                    "value" => "0",
                    "currency" => "USD"
                ],
                "deliveryTime" => [
                    "@type" => "ShippingDeliveryTime",
                    "handlingTime" => [
                        "@type" => "QuantitativeValue",
                        "minValue" => 0,
                        "maxValue" => 0,
                        "unitCode" => "DAY"
                    ],
                    "transitTime" => [
                        "@type" => "QuantitativeValue",
                        "minValue" => 0,
                        "maxValue" => 0,
                        "unitCode" => "DAY"
                    ]
                ],
                "shippingDestination" => [
                    "@type" => "DefinedRegion",
                    "addressCountry" => "US"
                ]
            ],
            "hasMerchantReturnPolicy" => [
                "@type" => "MerchantReturnPolicy",
                "applicableCountry" => "US",
                "returnPolicyCategory" => "https://schema.org/MerchantReturnFiniteReturnWindow",
                "merchantReturnDays" => 30,
                "merchantReturnLink" => "https://wpigo.com/refund-policy/",
                "returnMethod" => "https://schema.org/ReturnByMail",
                "returnFees" => "https://schema.org/FreeReturn"
            ],
            "seller" => [
                "@type" => "Organization",
                "name" => "WPiGo",
                "url" => home_url('/')
            ]
        ]
    ];

    // Add aggregateRating if exists
    if ($ratings['overall'] > 0 && $ratings['total_rating_count'] > 0) {
        $schema["aggregateRating"] = [
            "@type" => "AggregateRating",
            "ratingValue" => number_format($ratings['overall'], 1),
            "reviewCount" => $ratings['total_rating_count'],
            "bestRating" => "5",
            "worstRating" => "1"
        ];
    }

    // Add reviews from comments
    $comments = get_comments([
        'post_id' => $post_id,
        'status' => 'approve',
        'type' => 'comment',
        'number' => 10
    ]);

    if (!empty($comments)) {
        $reviews_array = [];
        foreach ($comments as $comment) {
            $comment_rating = get_comment_meta($comment->comment_ID, 'rating', true);

            // Only include comments with ratings
            if (!empty($comment_rating)) {
                $reviews_array[] = [
                    "@type" => "Review",
                    "author" => [
                        "@type" => "Person",
                        "name" => $comment->comment_author
                    ],
                    "datePublished" => get_comment_date('c', $comment),
                    "reviewBody" => wp_strip_all_tags($comment->comment_content),
                    "reviewRating" => [
                        "@type" => "Rating",
                        "ratingValue" => intval($comment_rating),
                        "bestRating" => "5",
                        "worstRating" => "1"
                    ]
                ];
            }
        }

        if (!empty($reviews_array)) {
            $schema["review"] = $reviews_array;
        }
    }

    return WPiGo_Schema::output_json_ld($schema);
}
