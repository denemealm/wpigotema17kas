/**
 * Rating System JavaScript
 */
jQuery(document).ready(function($) {
    // Star input hover effect
    $('.wpigo-star-input').each(function() {
        const $container = $(this);
        const $stars = $container.find('.wpigo-star');

        $stars.on('mouseenter', function() {
            const value = $(this).data('value');
            $stars.each(function(index) {
                if (index < value) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        });

        $container.on('mouseleave', function() {
            const currentRating = parseInt($container.attr('data-rating')) || 0;
            $stars.each(function(index) {
                if (index < currentRating) {
                    $(this).addClass('active');
                } else {
                    $(this).removeClass('active');
                }
            });
        });

        $stars.on('click', function() {
            const value = $(this).data('value');
            $container.attr('data-rating', value);

            $stars.each(function(index) {
                if (index < value) {
                    $(this).addClass('active').text('★');
                } else {
                    $(this).removeClass('active').text('☆');
                }
            });
        });
    });

    // Form submission
    $('#wpigo-rating-form').on('submit', function(e) {
        e.preventDefault();

        const $form = $(this);
        const $button = $form.find('.wpigo-btn-submit-rating');
        const $message = $form.find('.wpigo-rating-message');
        const postId = $form.data('post-id');

        // Get all ratings
        const ratings = {};
        let allRated = true;

        $form.find('.wpigo-star-input').each(function() {
            const category = $(this).data('category');
            const rating = parseInt($(this).attr('data-rating')) || 0;

            if (rating === 0) {
                allRated = false;
            }

            ratings[category] = rating;
        });

        // Validate
        if (!allRated) {
            $message.removeClass('success').addClass('error').text('Please rate all categories').show();
            return;
        }

        // Disable button
        $button.prop('disabled', true).text('Submitting...');
        $message.hide();

        // Submit via AJAX
        $.ajax({
            url: wpigoRatings.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_submit_rating',
                nonce: wpigoRatings.nonce,
                post_id: postId,
                code_quality: ratings.code_quality,
                documentation: ratings.documentation,
                support: ratings.support,
                features: ratings.features,
                design: ratings.design
            },
            success: function(response) {
                if (response.success) {
                    $message.removeClass('error').addClass('success').text(response.data.message).show();

                    // Hide the form
                    setTimeout(function() {
                        $form.fadeOut(300, function() {
                            $(this).remove();
                            // Show a thank you message
                            $('.wpigo-rating-section').append(
                                '<div class="wpigo-rating-thank-you" style="text-align: center; padding: 1rem; background: #d4edda; border-radius: 0.25rem; color: #155724; margin-top: 0.5rem;">' +
                                '<strong>Thank you for rating!</strong> Your ratings have been recorded.' +
                                '</div>'
                            );
                        });
                    }, 1500);
                } else {
                    $message.removeClass('success').addClass('error').text(response.data.message).show();
                    $button.prop('disabled', false).text('Submit Rating');
                }
            },
            error: function() {
                $message.removeClass('success').addClass('error').text('An error occurred. Please try again.').show();
                $button.prop('disabled', false).text('Submit Rating');
            }
        });
    });
});
