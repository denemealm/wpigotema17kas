<?php
/**
 * Organization & WebSite Schema
 *
 * Generates Schema.org markup for site-wide Organization and WebSite
 *
 * @package WPiGo
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate Organization Schema
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_organization() {
    // Collect social media URLs
    $social_urls = array_filter([
        get_theme_mod('wpigo_social_facebook'),
        get_theme_mod('wpigo_social_twitter'),
        get_theme_mod('wpigo_social_instagram'),
        get_theme_mod('wpigo_social_linkedin'),
        get_theme_mod('wpigo_social_youtube'),
        get_theme_mod('wpigo_social_github')
    ]);

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "Organization",
        "name" => get_bloginfo('name'),
        "url" => home_url('/'),
        "logo" => [
            "@type" => "ImageObject",
            "url" => get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : ''
        ],
        "description" => get_bloginfo('description'),
        "address" => [
            "@type" => "PostalAddress",
            "streetAddress" => "İhsaniye Mahallesi Turan Sokak No:4",
            "addressLocality" => "Nilüfer",
            "addressRegion" => "Bursa",
            "postalCode" => "16200",
            "addressCountry" => "TR"
        ],
        "contactPoint" => [
            "@type" => "ContactPoint",
            "telephone" => "+905369379337",
            "email" => "contact@wpigo.com",
            "contactType" => "Customer Service",
            "areaServed" => "TR",
            "availableLanguage" => "en"
        ],
        "sameAs" => array_values($social_urls)
    ];

    return WPiGo_Schema::output_json_ld($schema);
}

/**
 * Generate WebSite Schema with SearchAction
 *
 * @return string JSON-LD schema markup
 */
function wpigo_schema_website() {
    $schema = [
        "@context" => "https://schema.org",
        "@type" => "WebSite",
        "name" => get_bloginfo('name'),
        "url" => home_url('/'),
        "description" => get_bloginfo('description'),
        "potentialAction" => [
            "@type" => "SearchAction",
            "target" => [
                "@type" => "EntryPoint",
                "urlTemplate" => home_url('/?s={search_term_string}')
            ],
            "query-input" => "required name=search_term_string"
        ],
        "inLanguage" => get_bloginfo('language')
    ];

    return WPiGo_Schema::output_json_ld($schema);
}
