<?php
/**
 * Template Name: Shopping Cart
 * Cart Page Template
 */
get_header();

$cart_items = wpigo_get_cart_items();
$cart_total = wpigo_get_cart_total();
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container">

        <div class="wpigo-page-title-section">
            <h1 class="wpigo-page-title">Shopping Cart</h1>
        </div>

        <?php if (empty($cart_items)) : ?>
            
            <div class="wpigo-empty-cart" role="status" aria-live="polite">
                <div class="wpigo-empty-cart-icon" aria-hidden="true">🛒</div>
                <h2 class="wpigo-empty-cart-title">Your cart is empty</h2>
                <p class="wpigo-empty-cart-text">Browse our products and add items to your cart.</p>
                <a href="<?php echo home_url('/'); ?>" class="wpigo-btn wpigo-btn-primary">Continue Shopping</a>
            </div>

        <?php else : ?>
            
            <div class="wpigo-cart-layout">
                <div class="wpigo-cart-items" role="region" aria-label="Shopping cart items">
                    <?php 
                    // Pre-cache post meta for all items in the cart to avoid N+1 queries.
                    $product_ids = array_keys($cart_items);
                    update_meta_cache('post', $product_ids);
                    ?>
                    <?php foreach ($cart_items as $product_id => $item) :
                        $product = get_post($product_id);
                        if (!$product) continue;

                        $all_meta = get_post_meta($product_id);
                        $price = isset($all_meta['product_price'][0]) ? floatval($all_meta['product_price'][0]) : 29;
                        
                        $thumbnail_id = get_post_thumbnail_id($product_id);
                        $image_1x = $thumbnail_id ? wp_get_attachment_image_src($thumbnail_id, 'cart-thumb') : false;
                        $image_2x = $thumbnail_id ? wp_get_attachment_image_src($thumbnail_id, 'cart-thumb-2x') : false;
                    ?>
                        <article class="wpigo-cart-item" 
                                 data-product-id="<?php echo $product_id; ?>"
                                 aria-label="Cart item: <?php echo esc_attr($product->post_title); ?>">
                            
                            <div class="wpigo-cart-item-image">
                                <?php if ($image_1x) : 
                                    $srcset = esc_url($image_1x[0]) . ' ' . $image_1x[1] . 'w';
                                    if ($image_2x) {
                                        $srcset .= ', ' . esc_url($image_2x[0]) . ' ' . $image_2x[1] . 'w';
                                    }
                                ?>
                                    <img src="<?php echo esc_url($image_1x[0]); ?>"
                                         srcset="<?php echo $srcset; ?>"
                                         sizes="180px"
                                         width="<?php echo esc_attr($image_1x[1]); ?>"
                                         height="<?php echo esc_attr($image_1x[2]); ?>"
                                         alt="<?php echo esc_attr($product->post_title); ?>"
                                         loading="lazy">
                                <?php else : ?>
                                    <img src="https://via.placeholder.com/180x120/e8e8e8/999?text=Product" 
                                         alt="<?php echo esc_attr($product->post_title); ?>" 
                                         width="180" 
                                         height="120"
                                         loading="lazy">
                                <?php endif; ?>
                            </div>

                            <div class="wpigo-cart-item-details">
                                <h3 class="wpigo-cart-item-title">
                                    <a href="<?php echo get_permalink($product_id); ?>">
                                        <?php echo esc_html($product->post_title); ?>
                                    </a>
                                </h3>
                                <p class="wpigo-cart-item-author">
                                    by <?php echo get_the_author_meta('display_name', $product->post_author); ?>
                                </p>
                            </div>

                            <div class="wpigo-cart-item-price" aria-label="Price">
                                <span aria-hidden="true">$</span><?php echo number_format($price, 2); ?>
                            </div>

                            <div class="wpigo-cart-item-actions">
                                <button class="wpigo-cart-remove-btn" 
                                        data-product-id="<?php echo $product_id; ?>"
                                        data-nonce="<?php echo wp_create_nonce('wpigo_remove_from_cart_' . $product_id); ?>"
                                        aria-label="Remove <?php echo esc_attr($product->post_title); ?> from cart"
                                        type="button">
                                    <span aria-hidden="true">×</span>
                                    <span>Remove</span>
                                </button>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>

                <aside class="wpigo-cart-summary" role="complementary" aria-label="Order summary">
                    <div class="wpigo-card">
                        <h3 class="wpigo-card-title">Order Summary</h3>

                        <div class="wpigo-cart-summary-row">
                            <span class="wpigo-cart-summary-label">
                                Items <span class="screen-reader-text">(<?php echo count($cart_items); ?>)</span>
                                <span aria-hidden="true">(<?php echo count($cart_items); ?>)</span>
                            </span>
                            <span class="wpigo-cart-summary-value" 
                                  id="wpigo-cart-subtotal" 
                                  aria-label="Subtotal">
                                $<?php echo number_format($cart_total, 2); ?>
                            </span>
                        </div>

                        <div class="wpigo-cart-summary-row wpigo-cart-summary-total">
                            <span class="wpigo-cart-summary-label">Total</span>
                            <span class="wpigo-cart-summary-value" 
                                  id="wpigo-cart-total" 
                                  aria-label="Total amount">
                                $<?php echo number_format($cart_total, 2); ?>
                            </span>
                        </div>

                        <a href="#" 
                           class="wpigo-btn wpigo-btn-primary wpigo-btn-block wpigo-btn-checkout"
                           role="button">
                            Proceed to Checkout
                        </a>

                        <a href="<?php echo home_url('/'); ?>" 
                           class="wpigo-btn wpigo-btn-secondary wpigo-btn-block">
                            Continue Shopping
                        </a>
                    </div>

                    <div class="wpigo-cart-info" aria-label="Additional information">
                        <p class="wpigo-cart-info-text">
                            <strong>Secure Checkout:</strong> All transactions are secured and encrypted.
                        </p>
                        <p class="wpigo-cart-info-text">
                            <strong>Instant Access:</strong> Get immediate download access after purchase.
                        </p>
                    </div>
                </aside>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php get_footer(); ?>