<?php
/**
 * Template Name: Checkout
 * Description: Secure checkout page for processing orders (supports guests!)
 */

get_header();

$is_guest = !is_user_logged_in();
$current_user = $is_guest ? null : wp_get_current_user();

// Get products to checkout
$checkout_items = array();
$checkout_total = 0;

// Check if coming from single product (Purchase Now)
if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);
    $product = get_post($product_id);

    if ($product && $product->post_status === 'publish') {
        // Performance: Prime meta cache for the single product.
        update_meta_cache('post', array($product_id));

        $price = get_post_meta($product_id, 'product_price', true);
        $price = $price ? floatval($price) : 29;

        $checkout_items[] = array(
            'product_id' => $product_id,
            'title' => $product->post_title,
            'price' => $price,
            'thumbnail_id' => get_post_thumbnail_id($product_id),
            'support_period' => get_post_meta($product_id, '_support_period', true),
            'updates_period' => get_post_meta($product_id, '_updates_period', true),
            'update_extension_price' => get_post_meta($product_id, '_update_extension_price', true),
            'response_time' => get_post_meta($product_id, '_response_time', true)
        );

        $checkout_total = $price;
    }
} else {
    // Get items from cart
    $cart_items = wpigo_get_cart_items();

    // Performance: Prime meta cache for all products in the cart to prevent N+1 queries.
    if (!empty($cart_items)) {
        $product_ids = array_keys($cart_items);
        update_meta_cache('post', $product_ids);
    }

    foreach ($cart_items as $product_id => $item) {
        $product = get_post($product_id);
        if (!$product) continue;

        $price = get_post_meta($product_id, 'product_price', true);
        $price = $price ? floatval($price) : 29;

        $checkout_items[] = array(
            'product_id' => $product_id,
            'title' => $product->post_title,
            'price' => $price,
            'thumbnail_id' => get_post_thumbnail_id($product_id),
            'support_period' => get_post_meta($product_id, '_support_period', true),
            'updates_period' => get_post_meta($product_id, '_updates_period', true),
            'update_extension_price' => get_post_meta($product_id, '_update_extension_price', true),
            'response_time' => get_post_meta($product_id, '_response_time', true)
        );

        $checkout_total += $price;
    }
}

// Redirect if no items
if (empty($checkout_items)) {
    wp_redirect(esc_url(home_url('/cart/')));
    exit;
}
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container" role="main">

        <div class="wpigo-checkout-page">
            <h1 class="wpigo-checkout-title"><?php _e('Secure Checkout', 'wpigo'); ?></h1>

            <?php if ($is_guest) : ?>
            <!-- Guest Notice -->
            <div class="wpigo-guest-notice">
                <div class="wpigo-guest-notice-icon" aria-hidden="true">👤</div>
                <div class="wpigo-guest-notice-content">
                    <h3><?php _e('Checkout as Guest', 'wpigo'); ?></h3>
                    <p><?php _e("You're checking out as a guest. An account will be automatically created for you to manage your purchases and license keys.", 'wpigo'); ?></p>
                    <p><strong><?php _e('Already have an account?', 'wpigo'); ?></strong> <a href="<?php echo esc_url(wp_login_url(get_permalink())); ?>"><?php _e('Login here', 'wpigo'); ?></a> <?php _e('for faster checkout.', 'wpigo'); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <div class="wpigo-checkout-layout">

                <!-- Left Column: Order Summary -->
                <div class="wpigo-checkout-summary">
                    <h2><?php _e('Order Summary', 'wpigo'); ?></h2>

                    <div class="wpigo-checkout-items">
                        <?php foreach ($checkout_items as $item) : ?>
                            <div class="wpigo-checkout-item">
                                <?php
                                $thumbnail_id = $item['thumbnail_id'];
                                if ($thumbnail_id) :
                                    // Responsive görseller
                                    $image_1x = wp_get_attachment_image_src($thumbnail_id, 'checkout-thumb');
                                    $image_2x = wp_get_attachment_image_src($thumbnail_id, 'checkout-thumb-2x');

                                    if ($image_1x) :
                                        // srcset: piksel genişliği ile (w descriptor)
                                        $srcset = esc_url($image_1x[0]) . ' ' . $image_1x[1] . 'w';
                                        if ($image_2x) {
                                            $srcset .= ', ' . esc_url($image_2x[0]) . ' ' . $image_2x[1] . 'w';
                                        }
                                ?>
                                    <div class="wpigo-checkout-item-image">
                                        <img src="<?php echo esc_url($image_1x[0]); ?>"
                                             srcset="<?php echo esc_attr($srcset); ?>"
                                             sizes="120px"
                                             width="<?php echo esc_attr($image_1x[1]); ?>"
                                             height="<?php echo esc_attr($image_1x[2]); ?>"
                                             alt="<?php echo esc_attr($item['title']); ?>"
                                             loading="lazy">
                                    </div>
                                <?php
                                    endif;
                                endif;
                                ?>
                                <div class="wpigo-checkout-item-details">
                                    <h4><a href="<?php echo esc_url(get_permalink($item['product_id'])); ?>" target="_blank"><?php echo esc_html($item['title']); ?></a></h4>
                                    <p class="wpigo-checkout-item-price">$<?php echo number_format($item['price'], 2); ?></p>

                                    <?php if ($item['support_period'] || $item['updates_period'] || $item['response_time']) : ?>
                                    <div class="wpigo-checkout-item-support">
                                        <strong aria-hidden="true">🛠️</strong> <?php _e('Support & Maintenance:', 'wpigo'); ?>
                                        <ul>
                                            <?php if ($item['support_period']) : ?>
                                                <li><?php printf(esc_html__('Free Support: %s', 'wpigo'), sprintf(_n('%d month', '%d months', $item['support_period'], 'wpigo'), $item['support_period'])); ?></li>
                                            <?php endif; ?>
                                            <?php if ($item['updates_period']) : ?>
                                                <li><?php if ($item['updates_period'] === 'lifetime') { printf(esc_html__('Updates: %s', 'wpigo'), __('Lifetime', 'wpigo')); } else { printf(esc_html__('Updates: %s', 'wpigo'), sprintf(_n('%d year', '%d years', $item['updates_period'], 'wpigo'), $item['updates_period'])); } ?></li>
                                            <?php endif; ?>
                                            <?php if ($item['updates_period'] !== 'lifetime' && !empty($item['update_extension_price']) && $item['update_extension_price'] > 0) : ?>
                                                <li><?php printf(esc_html__('Update Extension: %s', 'wpigo'), '$' . number_format($item['update_extension_price'], 2)); ?></li>
                                            <?php endif; ?>
                                            <?php if ($item['response_time']) : ?>
                                                <li><?php echo esc_html__('Response Time:', 'wpigo'); ?> &lt;<?php echo esc_html($item['response_time']); ?> <?php echo esc_html__('hours', 'wpigo'); ?></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="wpigo-checkout-total">
                        <div class="wpigo-checkout-total-row">
                            <span><?php _e('Subtotal:', 'wpigo'); ?></span>
                            <span>$<?php echo number_format($checkout_total, 2); ?></span>
                        </div>
                        <div class="wpigo-checkout-total-row wpigo-checkout-total-grand">
                            <span><?php _e('Total:', 'wpigo'); ?></span>
                            <span>$<?php echo number_format($checkout_total, 2); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Right Column: Payment & Billing Form -->
                <div class="wpigo-checkout-form-container">

                    <!-- Billing Information (for guests) -->
                    <?php if ($is_guest) : ?>
                    <div class="wpigo-checkout-section">
                        <h3><?php _e('Billing Information', 'wpigo'); ?></h3>
                        <p class="wpigo-checkout-section-desc"><?php _e("We'll create your account with this information", 'wpigo'); ?></p>

                        <div class="wpigo-form-grid">
                            <div class="wpigo-form-field">
                                <label for="billing_email"><?php _e('Email Address *', 'wpigo'); ?></label>
                                <input type="email" id="billing_email" name="billing_email" required placeholder="you@example.com" aria-required="true">
                                <small><?php _e("You'll receive your license keys here", 'wpigo'); ?></small>
                            </div>

                            <div class="wpigo-form-field">
                                <label for="billing_name"><?php _e('Full Name *', 'wpigo'); ?></label>
                                <input type="text" id="billing_name" name="billing_name" required placeholder="John Doe" aria-required="true">
                            </div>
                        </div>

                        <div class="wpigo-form-field">
                            <label>
                                <input type="checkbox" name="create_account" id="create_account" checked>
                                <span><?php _e('Create an account to manage purchases & license keys', 'wpigo'); ?></span>
                            </label>
                            <small><?php _e('Password will be sent to your email', 'wpigo'); ?></small>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Payment Information -->
                    <form id="wpigo-checkout-form" role="form" class="wpigo-checkout-form">
                        <?php wp_nonce_field('wpigo_checkout_nonce', 'checkout_nonce'); ?>
                        <!-- Message area -->
                        <div id="wpigo-checkout-message" role="alert" style="display: none; margin-bottom: 1.5rem;"></div>

                        <div class="wpigo-checkout-section">
                            <h3><?php _e('Payment Information', 'wpigo'); ?></h3>
                            <p class="wpigo-checkout-section-desc"><?php _e('All transactions are secure and encrypted', 'wpigo'); ?></p>

                            <div class="wpigo-form-field">
                                <label for="card_number"><?php _e('Card Number *', 'wpigo'); ?></label>
                                <input type="text" id="card_number" name="card_number" required maxlength="19" placeholder="4242 4242 4242 4242" aria-required="true">
                            </div>

                            <div class="wpigo-form-field">
                                <label for="card_name"><?php _e('Cardholder Name *', 'wpigo'); ?></label>
                                <input type="text" id="card_name" name="card_name" required placeholder="Name on card" aria-required="true">
                            </div>

                            <div class="wpigo-form-grid">
                                <div class="wpigo-form-field">
                                    <label for="card_expiry"><?php _e('Expiry Date *', 'wpigo'); ?></label>
                                    <input type="text" id="card_expiry" name="card_expiry" required maxlength="5" placeholder="MM/YY" aria-required="true">
                                </div>

                                <div class="wpigo-form-field">
                                    <label for="card_cvc"><?php _e('CVC *', 'wpigo'); ?></label>
                                    <input type="text" id="card_cvc" name="card_cvc" required maxlength="4" placeholder="123" aria-required="true">
                                </div>
                            </div>
                        </div>

                        <!-- Hidden fields for product IDs -->
                        <?php foreach ($checkout_items as $item) : ?>
                            <input type="hidden" name="product_ids[]" value="<?php echo esc_attr($item['product_id']); ?>">
                        <?php endforeach; ?>

                        <!-- Guest fields (hidden if logged in) -->
                        <?php if (!$is_guest) : ?>
                            <input type="hidden" name="user_id" value="<?php echo $current_user->ID; ?>">
                            <input type="hidden" name="user_email" value="<?php echo esc_attr($current_user->user_email); ?>">
                        <?php endif; ?>

                        <div class="wpigo-checkout-actions">
                            <button type="submit" id="wpigo-checkout-submit" class="wpigo-btn wpigo-btn-primary wpigo-btn-lg">
                                <?php printf(esc_html__('Complete Order - %s', 'wpigo'), '$' . number_format($checkout_total, 2)); ?>
                            </button>
                            <p class="wpigo-checkout-secure">
                                <?php _e('🔒 Secure payment processing', 'wpigo'); ?>
                            </p>
                        </div>
                    </form>

                </div>

            </div>

        </div>

    </main>
</div>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CheckoutPage",
  "name": "<?php echo esc_js(get_the_title()); ?>",
  "url": "<?php echo esc_url(get_permalink()); ?>",
  "mainEntity": {
    "@type": "ItemList",
    "itemListElement": [
      <?php
      $list_items = array();
      foreach ($checkout_items as $index => $item) {
          $list_items[] = '{ "@type": "ListItem", "position": ' . ($index + 1) . ', "item": { "@type": "Product", "name": "' . esc_js($item['title']) . '", "url": "' . esc_url(get_permalink($item['product_id'])) . '", "offers": { "@type": "Offer", "price": "' . esc_attr($item['price']) . '", "priceCurrency": "USD" } } }';
      }
      echo implode(',', $list_items);
      ?>
    ]
  },
  "potentialAction": {
    "@type": "ConfirmAction",
    "name": "Complete Order",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "<?php echo esc_url(get_permalink()); ?>",
      "actionPlatform": [
        "http://schema.org/DesktopWebPlatform",
        "http://schema.org/MobileWebPlatform"
      ]
    }
  }
}
</script>

<?php get_footer(); ?>
