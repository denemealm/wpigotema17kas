/**
 * WPiGo Shop Functionality
 * Combines: Cart, Checkout, Member Profile
 */

jQuery(document).ready(function($) {
    'use strict';

    // ==============================================
    // SHOPPING CART
    // ==============================================

    // Add to Cart button handler
    $(document).on('click', '.wpigo-btn-cart', function(e) {
        e.preventDefault();

        var $btn = $(this);
        var productId = $btn.data('product-id');
        var originalText = $btn.text();

        $btn.prop('disabled', true).text('Adding...');

        $.ajax({
            url: wpigoCart.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_add_to_cart',
                product_id: productId,
                nonce: wpigoCart.nonce
            },
            success: function(response) {
                if (response.success) {
                    if (response.data.cart_token) {
                        document.cookie = 'wpigo_cart_token=' + response.data.cart_token + '; path=/; max-age=' + (86400 * 30);
                    }

                    $btn.text('Added!').css('background', '#27ae60');

                    setTimeout(function() {
                        window.location.href = wpigoCart.cart_url;
                    }, 1000);
                } else {
                    alert(response.data.message || 'Failed to add to cart');
                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Remove from Cart button handler
    $(document).on('click', '.wpigo-cart-remove-btn', function(e) {
        e.preventDefault();

        var $btn = $(this);
        var productId = $btn.data('product-id');
        var productNonce = $btn.data('nonce');
        var $cartItem = $btn.closest('.wpigo-cart-item');

        if (!confirm('Remove this item from cart?')) {
            return;
        }

        $btn.prop('disabled', true).text('Removing...');

        $.ajax({
            url: wpigoCart.ajaxurl,
            type: 'POST',
            data: {
                action: 'wpigo_remove_from_cart',
                product_id: productId,
                nonce: productNonce
            },
            success: function(response) {
                if (response.success) {
                    $cartItem.fadeOut(300, function() {
                        $(this).remove();

                        var cartTotal = response.data.cart_total;
                        var cartCount = response.data.cart_count;

                        $('#wpigo-cart-subtotal').text('$' + cartTotal.toFixed(2));
                        $('#wpigo-cart-total').text('$' + cartTotal.toFixed(2));

                        if (cartCount === 0) {
                            location.reload();
                        }
                    });
                } else {
                    alert(response.data.message || 'Failed to remove item');
                    $btn.prop('disabled', false).text('Remove');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                $btn.prop('disabled', false).text('Remove');
            }
        });
    });

    // Checkout button - Redirect to checkout page
    $(document).on('click', '.wpigo-btn-checkout', function(e) {
        e.preventDefault();
        window.location.href = wpigoCart.checkout_url;
    });

    // Purchase Now button - Direct checkout for single product
    $(document).on('click', '.wpigo-btn-purchase', function(e) {
        e.preventDefault();

        var $card = $(this).closest('.wpigo-card-purchase');
        var $addToCartBtn = $card.find('.wpigo-btn-cart');
        var productId = $addToCartBtn.data('product-id');

        if (!productId) {
            alert('Product ID not found');
            return;
        }

        window.location.href = wpigoCart.checkout_url + '?product_id=' + productId;
    });

    // ==============================================
    // CHECKOUT FORM
    // ==============================================

    // Format card number with spaces
    $('#card_number').on('input', function() {
        var value = $(this).val().replace(/\s/g, '');
        var formatted = value.match(/.{1,4}/g);
        $(this).val(formatted ? formatted.join(' ') : '');
    });

    // Format expiry date
    $('#card_expiry').on('input', function() {
        var value = $(this).val().replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        $(this).val(value);
    });

    // Only allow numbers in CVC
    $('#card_cvc').on('input', function() {
        $(this).val($(this).val().replace(/\D/g, ''));
    });

    // Checkout form submission
    $('#wpigo-checkout-form').on('submit', function(e) {
        e.preventDefault();

        var $form = $(this);
        var $submitBtn = $('#wpigo-checkout-submit');
        var $message = $('#wpigo-checkout-message');
        var originalText = $submitBtn.text();

        $message.html('').removeClass('wpigo-member-message-success wpigo-member-message-error');

        // Basic validation
        var cardNumber = $('#card_number').val().replace(/\s/g, '');
        var cardName = $('#card_name').val().trim();
        var cardExpiry = $('#card_expiry').val();
        var cardCvc = $('#card_cvc').val();

        // Guest billing validation
        var billingEmail = $('#billing_email').val() ? $('#billing_email').val().trim() : '';
        var billingName = $('#billing_name').val() ? $('#billing_name').val().trim() : '';

        // If billing fields exist (guest checkout), validate them
        if ($('#billing_email').length > 0) {
            if (!billingEmail) {
                showMessage('Please enter your email address', 'error');
                return;
            }

            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(billingEmail)) {
                showMessage('Please enter a valid email address', 'error');
                return;
            }

            if (!billingName) {
                showMessage('Please enter your full name', 'error');
                return;
            }
        }

        if (!cardName) {
            showMessage('Please enter cardholder name', 'error');
            return;
        }

        if (cardNumber.length < 13 || cardNumber.length > 19) {
            showMessage('Please enter a valid card number', 'error');
            return;
        }

        if (!cardExpiry.match(/^\d{2}\/\d{2}$/)) {
            showMessage('Please enter expiry in MM/YY format', 'error');
            return;
        }

        if (cardCvc.length < 3 || cardCvc.length > 4) {
            showMessage('Please enter a valid CVC', 'error');
            return;
        }

        $submitBtn.prop('disabled', true).text('Processing...');

        // Prepare data
        var formData = {
            action: 'wpigo_create_order',
            nonce: wpigoCheckout.nonce,
            card_number: cardNumber,
            card_name: cardName,
            card_expiry: cardExpiry,
            card_cvc: cardCvc,
            product_ids: []
        };

        // Add guest billing data if exists
        if (billingEmail) {
            formData.billing_email = billingEmail;
            formData.billing_name = billingName;
            formData.create_account = $('#create_account').is(':checked') ? 1 : 0;
        }

        // Get product IDs
        $form.find('input[name="product_ids[]"]').each(function() {
            formData.product_ids.push($(this).val());
        });

        // Send AJAX request
        $.ajax({
            url: wpigoCheckout.ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    showMessage(response.data.message, 'success');

                    setTimeout(function() {
                        window.location.href = response.data.redirect_url;
                    }, 1000);
                } else {
                    showMessage(response.data.message || 'Order failed. Please try again.', 'error');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                showMessage('An error occurred. Please try again.', 'error');
                $submitBtn.prop('disabled', false).text(originalText);
            }
        });
    });

    function showMessage(message, type) {
        var $message = $('#wpigo-checkout-message');
        var className = type === 'success' ? 'wpigo-member-message-success' : 'wpigo-member-message-error';

        $message
            .html(message)
            .removeClass('wpigo-member-message-success wpigo-member-message-error')
            .addClass('wpigo-member-message ' + className)
            .fadeIn();

        $('html, body').animate({
            scrollTop: $message.offset().top - 100
        }, 300);
    }

    // ==============================================
    // MEMBER PROFILE - LICENSE KEYS
    // ==============================================

    // Toggle license keys expand/collapse
    $('.wpigo-toggle-license-btn').on('click', function() {
        var $btn = $(this);
        var targetId = $btn.data('target');
        var $target = $('#' + targetId);

        if ($target.length === 0) {
            return;
        }

        if ($target.is(':visible')) {
            $target.slideUp(300);
            $btn.text('🔑 Show License Keys');
        } else {
            $('.wpigo-license-keys-expandable').slideUp(300);
            $('.wpigo-toggle-license-btn').text('🔑 Show License Keys');

            $target.slideDown(300);
            $btn.text('🔑 Hide License Keys');
        }
    });

    // Copy to clipboard
    $('.wpigo-license-copy-btn').on('click', function() {
        var $btn = $(this);
        var targetSelector = $btn.data('copy-target');
        var $input = $(targetSelector);
        var originalType = $input.attr('type');

        $input.attr('type', 'text');
        $input.select();
        document.execCommand('copy');
        $input.attr('type', originalType);

        var originalText = $btn.text();
        $btn.text('✓ Copied!').css('background', '#27ae60');

        setTimeout(function() {
            $btn.text(originalText).css('background', '');
        }, 2000);
    });

    // Toggle show/hide for password fields
    $('.wpigo-license-toggle-btn').on('click', function() {
        var $btn = $(this);
        var targetSelector = $btn.data('toggle-target');
        var $input = $(targetSelector);

        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $btn.text('👁 Hide');
        } else {
            $input.attr('type', 'password');
            $btn.text('👁 Show');
        }
    });
});
