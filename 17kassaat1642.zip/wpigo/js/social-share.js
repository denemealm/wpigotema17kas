/**
 * Social Share - Copy Link Functionality
 */
(function() {
    'use strict';

    // Copy link functionality
    document.addEventListener('DOMContentLoaded', function() {
        const copyButtons = document.querySelectorAll('.wpigo-share-copy');

        copyButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const url = this.getAttribute('data-url');

                // Try Clipboard API first
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(url).then(function() {
                        showCopyFeedback(button, 'Copied!');
                    }).catch(function() {
                        fallbackCopy(url, button);
                    });
                } else {
                    fallbackCopy(url, button);
                }
            });
        });
    });

    // Fallback copy method for older browsers
    function fallbackCopy(text, button) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();

        try {
            document.execCommand('copy');
            showCopyFeedback(button, 'Copied!');
        } catch (err) {
            showCopyFeedback(button, 'Failed');
        }

        document.body.removeChild(textarea);
    }

    // Show feedback when link is copied
    function showCopyFeedback(button, message) {
        const originalLabel = button.querySelector('.wpigo-share-label').textContent;

        button.querySelector('.wpigo-share-label').textContent = message;
        button.classList.add('wpigo-share-copied');

        setTimeout(function() {
            button.querySelector('.wpigo-share-label').textContent = originalLabel;
            button.classList.remove('wpigo-share-copied');
        }, 2000);
    }
})();
