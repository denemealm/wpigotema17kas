/**
 * Screenshot Gallery Modal
 * Handles screenshot gallery modal functionality with keyboard navigation
 */

(function($) {
    'use strict';

    // Check if screenshots exist
    if (typeof wpigoScreenshots === 'undefined' || !wpigoScreenshots.length) {
        return;
    }

    var currentIndex = 0;
    var $modal = $('#wpigo-screenshot-modal');
    var $image = $('#wpigo-screenshot-image');
    var $currentCounter = $('#wpigo-screenshot-current');
    var totalScreenshots = wpigoScreenshots.length;

    /**
     * Open modal with screenshot gallery
     */
    function openModal(index) {
        currentIndex = index || 0;
        updateScreenshot();
        $modal.addClass('active');
        $('body').css('overflow', 'hidden'); // Prevent body scroll
    }

    /**
     * Close modal
     */
    function closeModal() {
        $modal.removeClass('active');
        $('body').css('overflow', ''); // Restore body scroll
    }

    /**
     * Show next screenshot
     */
    function nextScreenshot() {
        currentIndex = (currentIndex + 1) % totalScreenshots;
        updateScreenshot();
    }

    /**
     * Show previous screenshot
     */
    function prevScreenshot() {
        currentIndex = (currentIndex - 1 + totalScreenshots) % totalScreenshots;
        updateScreenshot();
    }

    /**
     * Update screenshot image and counter
     */
    function updateScreenshot() {
        $image.attr('src', wpigoScreenshots[currentIndex]);
        $currentCounter.text(currentIndex + 1);
    }

    /**
     * Event: Screenshots button click
     */
    $('.wpigo-action-screenshots').on('click', function(e) {
        e.preventDefault();

        // Check if screenshots exist
        if (totalScreenshots === 0) {
            alert('No screenshots available for this product.');
            return;
        }

        openModal(0);
    });

    /**
     * Event: Close button click
     */
    $('.wpigo-screenshot-close').on('click', function(e) {
        e.preventDefault();
        closeModal();
    });

    /**
     * Event: Overlay click to close
     */
    $('.wpigo-screenshot-modal-overlay').on('click', function() {
        closeModal();
    });

    /**
     * Event: Next button click
     */
    $('.wpigo-screenshot-next').on('click', function(e) {
        e.preventDefault();
        nextScreenshot();
    });

    /**
     * Event: Previous button click
     */
    $('.wpigo-screenshot-prev').on('click', function(e) {
        e.preventDefault();
        prevScreenshot();
    });

    /**
     * Event: Keyboard navigation
     */
    $(document).on('keydown', function(e) {
        // Only handle if modal is open
        if (!$modal.hasClass('active')) {
            return;
        }

        switch(e.keyCode) {
            case 27: // ESC key
                closeModal();
                break;
            case 37: // Left arrow
                prevScreenshot();
                break;
            case 39: // Right arrow
                nextScreenshot();
                break;
        }
    });

    /**
     * Event: Prevent modal content clicks from closing
     */
    $('.wpigo-screenshot-modal-content').on('click', function(e) {
        e.stopPropagation();
    });

    /**
     * Preload images for better performance
     */
    function preloadImages() {
        wpigoScreenshots.forEach(function(url) {
            var img = new Image();
            img.src = url;
        });
    }

    // Preload images on page load
    preloadImages();

})(jQuery);
