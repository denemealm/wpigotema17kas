document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('wpigo-contact-form');
    if (!form) {
        return;
    }

    const submitBtn = document.getElementById('contact-submit-btn');
    const responseEl = document.getElementById('contact-response');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoader = submitBtn.querySelector('.btn-loader');

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Disable submit button and set aria-busy
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-busy', 'true');
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline-block';
        responseEl.style.display = 'none';

        // Get form data
        const formData = new FormData(form);
        formData.append('action', 'wpigo_contact_submit');
        // Use nonce from localized script
        formData.append('nonce', wpigoContact.nonce);

        // Convert to URLSearchParams
        const params = new URLSearchParams(formData);

        // Submit via AJAX using ajax_url from localized script
        fetch(wpigoContact.ajax_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params
        })
        .then(response => response.json())
        .then(data => {
            // Re-enable button and remove aria-busy
            submitBtn.disabled = false;
            submitBtn.setAttribute('aria-busy', 'false');
            btnText.style.display = 'inline-block';
            btnLoader.style.display = 'none';

            if (data.success) {
                responseEl.className = 'wpigo-form-response wpigo-form-success';
                responseEl.textContent = data.data;
                responseEl.style.display = 'block';
                form.reset();

                // Scroll to response
                responseEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                responseEl.className = 'wpigo-form-response wpigo-form-error';
                responseEl.textContent = data.data;
                responseEl.style.display = 'block';
            }
        })
        .catch(error => {
            // Re-enable button and remove aria-busy
            submitBtn.disabled = false;
            submitBtn.setAttribute('aria-busy', 'false');
            btnText.style.display = 'inline-block';
            btnLoader.style.display = 'none';

            responseEl.className = 'wpigo-form-response wpigo-form-error';
            responseEl.textContent = 'An error occurred. Please try again.';
            responseEl.style.display = 'block';
        });
    });
});
