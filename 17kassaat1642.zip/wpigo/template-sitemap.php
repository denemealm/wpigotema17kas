<?php
/**
 * Template Name: Sitemap
 * Description: HTML sitemap page for better navigation and SEO
 */

get_header();
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container" role="main">

        <!-- Page Title Section -->
        <header class="wpigo-page-title-section">
            <h1 class="wpigo-page-title"><?php _e('Site Map', 'wpigo'); ?></h1>
            <p class="wpigo-page-subtitle"><?php _e('Complete overview of all pages and products on WPiGo', 'wpigo'); ?></p>
        </header>

        <!-- Sitemap Content -->
        <article class="wpigo-sitemap-container" role="article">

            <div class="wpigo-sitemap-grid">

                <!-- Main Pages -->
                <section class="wpigo-sitemap-section" role="region" aria-labelledby="main-pages-title">
                    <h2 id="main-pages-title" class="wpigo-sitemap-section-title">
                        <span class="wpigo-sitemap-icon" aria-hidden="true">🏠</span>
                        <?php _e('Main Pages', 'wpigo'); ?>
                    </h2>
                    <ul class="wpigo-sitemap-list">
                        <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php _e('Home', 'wpigo'); ?></a></li>
                        <?php
                        // Get all pages (excluding sitemap)
                        $all_pages = get_pages(array(
                            'post_type' => 'page',
                            'post_status' => 'publish',
                            'sort_column' => 'post_title',
                            'exclude' => get_the_ID()
                        ));

                        // Performance: Pre-cache post meta for all pages to avoid N+1 queries.
                        $page_ids = wp_list_pluck($all_pages, 'ID');
                        if (!empty($page_ids)) {
                            update_meta_cache('post', $page_ids);
                        }

                        $sitemap_page_count = 0;
                        foreach ($all_pages as $page) {
                            // Skip if excluded from sitemap
                            $exclude = get_post_meta($page->ID, '_exclude_from_sitemap', true);
                            if ($exclude == '1') {
                                continue;
                            }
                            $sitemap_page_count++;
                            echo '<li><a href="' . esc_url(get_permalink($page->ID)) . '">' . esc_html($page->post_title) . '</a></li>';
                        }
                        ?>
                    </ul>
                </section>

                <section class="wpigo-sitemap-section" role="region" aria-labelledby="products-title">
                    <h2 id="products-title" class="wpigo-sitemap-section-title">
                        <span class="wpigo-sitemap-icon" aria-hidden="true">📦</span>
                        <?php _e('Products', 'wpigo'); ?>
                    </h2>
                    <?php
                    // Performance: Get all products and their categories in an optimized way.
                    $all_products = get_posts(array(
                        'post_type' => 'wpigo_product',
                        'posts_per_page' => -1,
                        'post_status' => 'publish',
                        'orderby' => 'title',
                        'order' => 'ASC',
                    ));
                    $sitemap_product_count = count($all_products);

                    // Performance: Pre-cache taxonomy terms for all products to avoid N+1 queries.
                    $product_ids = wp_list_pluck($all_products, 'ID');
                    if (!empty($product_ids)) {
                        update_object_term_cache($product_ids, 'wpigo_product_category');
                    }

                    // Group products by category term_id.
                    $products_by_cat = array();
                    foreach ($all_products as $product) {
                        $terms = get_the_terms($product->ID, 'wpigo_product_category');
                        if ($terms && !is_wp_error($terms)) {
                            foreach ($terms as $term) {
                                $products_by_cat[$term->term_id][] = $product;
                            }
                        }
                    }

                    $categories = get_terms(array(
                        'taxonomy' => 'wpigo_product_category',
                        'hide_empty' => true,
                        'orderby' => 'name',
                        'order' => 'ASC'
                    ));

                    if ($categories && !is_wp_error($categories)) :
                        foreach ($categories as $category) :
                            // Use the pre-fetched and grouped products.
                            if (!empty($products_by_cat[$category->term_id])) :
                                $products = $products_by_cat[$category->term_id];
                    ?>
                        <div class="wpigo-sitemap-category">
                            <h3 class="wpigo-sitemap-category-title">
                                <a href="<?php echo esc_url(get_term_link($category)); ?>">
                                    <?php echo esc_html($category->name); ?>
                                    <span class="wpigo-sitemap-count" aria-label="<?php echo count($products); ?> products">(<?php echo count($products); ?>)</span>
                                </a>
                            </h3>
                            <ul class="wpigo-sitemap-product-list">
                                <?php foreach ($products as $product) : ?>
                                    <li><a href="<?php echo esc_url(get_permalink($product->ID)); ?>"><?php echo esc_html($product->post_title); ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php
                            endif;
                        endforeach;
                    endif;
                    ?>
                </section>

                <!-- Blog Posts -->
                <?php
                $posts = get_posts(array(
                    'post_type' => 'post',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'orderby' => 'date',
                    'order' => 'DESC'
                ));

                if ($posts) :
                    // Performance: Pre-cache post meta for all posts to avoid N+1 queries.
                    $post_ids = wp_list_pluck($posts, 'ID');
                    if (!empty($post_ids)) {
                        update_meta_cache('post', $post_ids);
                    }
                ?>
                <section class="wpigo-sitemap-section" role="region" aria-labelledby="blog-posts-title">
                    <h2 id="blog-posts-title" class="wpigo-sitemap-section-title">
                        <span class="wpigo-sitemap-icon" aria-hidden="true">📝</span>
                        <?php _e('Blog Posts', 'wpigo'); ?>
                    </h2>
                    <ul class="wpigo-sitemap-list">
                        <?php                                   // ✅ PHP tag ekle
                        $sitemap_post_count = 0;
                        foreach ($posts as $post) :
                            // Skip if excluded from sitemap
                            $exclude = get_post_meta($post->ID, '_exclude_from_sitemap', true);
                            if ($exclude == '1') {
                                continue;
                            }
                            $sitemap_post_count++;
                        ?>
                            <li><a href="<?php echo esc_url(get_permalink($post->ID)); ?>"><?php echo esc_html($post->post_title); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </section>
                <?php 
                else:
                    $sitemap_post_count = 0;
                endif; 
                ?>

            </div>

            <!-- SEO Footer Text -->
            <footer class="wpigo-sitemap-footer">
                <p>
                    <?php _e('This sitemap provides a complete overview of all pages and products available on WPiGo. For automated crawling, please refer to our', 'wpigo'); ?>
                    <a href="<?php echo esc_url(home_url('/wp-sitemap.xml')); ?>"><?php _e('XML Sitemap', 'wpigo'); ?></a>.
                </p>
                <p class="wpigo-sitemap-update">
                    <strong><?php _e('Last Updated:', 'wpigo'); ?></strong>
                    <time datetime="<?php echo current_time('c'); ?>"><?php echo current_time('F j, Y'); ?></time>
                </p>
            </footer>

        </article>

    </main>
</div>

<?php                                           // ✅ Tek PHP tag
// Generate dynamic description using the efficient counters from above.
$sitemap_description = sprintf(
    __('Complete sitemap with %d pages, %d products, and %d blog posts.', 'wpigo'),
    $sitemap_page_count ?? 0,
    $sitemap_product_count ?? 0,
    $sitemap_post_count ?? 0
);
?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "<?php echo esc_js(get_the_title()); ?>",
  "url": "<?php echo esc_url(get_permalink()); ?>",
  "description": "<?php echo esc_js($sitemap_description); ?>",
  "dateModified": "<?php echo get_the_modified_date('c'); ?>",
  "inLanguage": "<?php echo get_bloginfo('language'); ?>"
}
</script>

<?php get_footer(); ?>