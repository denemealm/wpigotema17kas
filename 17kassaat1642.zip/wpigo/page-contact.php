<?php
/**
 * Template Name: Contact Page
 * Description: Contact form page with message submission
 */

get_header();

// Get current user info if logged in
$current_user = wp_get_current_user();
$user_name = $current_user->exists() ? $current_user->display_name : '';
$user_email = $current_user->exists() ? $current_user->user_email : '';
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container">

        <!-- Page Header -->
        <header class="wpigo-page-title-section">
            <h1 class="wpigo-page-title" id="form-title">Contact Us</h1>
            <p class="wpigo-page-subtitle">Have a question? We'd love to hear from you. Send us a message and we'll respond as soon as possible.</p>
        </header>

        <!-- Contact Form Section -->
        <div class="wpigo-contact-page">

            <div class="wpigo-contact-grid">

                <!-- Contact Form -->
                <div class="wpigo-contact-form-wrapper">
                    <form id="wpigo-contact-form" class="wpigo-contact-form" role="form" aria-labelledby="form-title">

                        <div class="wpigo-form-group">
                            <label for="contact_name">Full Name <span class="required">*</span></label>
                            <input type="text"
                                   id="contact_name"
                                   name="name"
                                   value="<?php echo esc_attr($user_name); ?>"
                                   required
                                   aria-required="true"
                                   placeholder="Enter your full name">
                        </div>

                        <div class="wpigo-form-group">
                            <label for="contact_email">Email Address <span class="required">*</span></label>
                            <input type="email"
                                   id="contact_email"
                                   name="email"
                                   value="<?php echo esc_attr($user_email); ?>"
                                   <?php echo $current_user->exists() ? 'readonly' : ''; ?>
                                   required
                                   aria-required="true"
                                   placeholder="your@email.com">
                            <?php if ($current_user->exists()) : ?>
                                <small class="wpigo-form-help">Using your registered email</small>
                            <?php endif; ?>
                        </div>

                        <div class="wpigo-form-group">
                            <label for="contact_phone">Phone Number (Optional)</label>
                            <input type="tel"
                                   id="contact_phone"
                                   name="phone"
                                   placeholder="+1 234 567 890">
                        </div>

                        <div class="wpigo-form-group">
                            <label for="contact_subject">Subject <span class="required">*</span></label>
                            <select id="contact_subject" name="subject" required aria-required="true">
                                <option value="">Select a subject</option>
                                <option value="General Inquiry">General Inquiry</option>
                                <option value="Technical Support">Technical Support</option>
                                <option value="Sales Question">Sales Question</option>
                                <option value="Refund Request">Refund Request</option>
                                <option value="License Issue">License Issue</option>
                                <option value="DMCA Complaint">DMCA Complaint</option>
                                <option value="Data Deletion Request">Data Deletion Request (GDPR)</option>
                                <option value="Report Abuse">Report Abuse</option>
                                <option value="Partnership">Partnership</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="wpigo-form-group">
                            <label for="contact_message">Your Message <span class="required">*</span></label>
                            <textarea id="contact_message"
                                      name="message"
                                      rows="6"
                                      required
                                      aria-required="true"
                                      placeholder="Tell us how we can help you..."></textarea>
                        </div>

                        <div class="wpigo-form-response" id="contact-response" role="alert" aria-live="polite" aria-atomic="true" style="display: none;"></div>

                        <button type="submit" class="wpigo-btn wpigo-btn-primary wpigo-btn-large" id="contact-submit-btn">
                            <span class="btn-text">Send Message</span>
                            <span class="btn-loader" style="display: none;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10" opacity="0.25"></circle>
                                    <path d="M12 2 A10 10 0 0 1 22 12" opacity="0.75">
                                        <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/>
                                    </path>
                                </svg>
                            </span>
                        </button>

                    </form>
                </div>

                <!-- Contact Info Sidebar -->
                <div class="wpigo-contact-info">
                    <h3>Get in Touch</h3>
                    <p>We're here to help and answer any question you might have. We look forward to hearing from you!</p>

                    <?php
                    $contact_address = get_theme_mod('wpigo_footer_address');
                    $contact_phone = get_theme_mod('wpigo_footer_phone');
                    $contact_email = get_theme_mod('wpigo_footer_email');

                    if ($contact_address || $contact_phone || $contact_email) :
                    ?>
                    <div class="wpigo-contact-details">
                        <?php if ($contact_address) : ?>
                        <div class="wpigo-contact-detail-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <div>
                                <strong>Address</strong>
                                <p><?php echo esc_html($contact_address); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($contact_phone) : ?>
                        <div class="wpigo-contact-detail-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <div>
                                <strong>Phone</strong>
                                <p><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $contact_phone)); ?>"><?php echo esc_html($contact_phone); ?></a></p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($contact_email) : ?>
                        <div class="wpigo-contact-detail-item">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <div>
                                <strong>Email</strong>
                                <p><a href="mailto:<?php echo esc_attr($contact_email); ?>"><?php echo esc_html($contact_email); ?></a></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="wpigo-contact-note">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M12 16v-4"></path>
                            <path d="M12 8h.01"></path>
                        </svg>
                        <p><strong>Response Time:</strong> We typically respond within 1-2 hours, 7 days a week.</p>
                    </div>
                </div>

            </div>

        </div>

    </main>
</div>



<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ContactPage",
  "name": "<?php echo esc_js(get_the_title()); ?>",
  "url": "<?php echo esc_url(get_permalink()); ?>",
  "description": "Contact WPiGo for support, sales inquiries, or other questions.",
  "mainEntity": {
    "@type": "ContactPoint",
    "contactType": "Customer Service",
    "availableLanguage": ["en", "tr"]
  }
}
</script>

<?php get_footer(); ?>
