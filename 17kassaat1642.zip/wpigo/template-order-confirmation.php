<?php
/**
 * Template Name: Order Confirmation
 * Description: Order success and license keys display
 */

// Security check - must be logged in
if (!is_user_logged_in()) {
    wp_redirect(esc_url(wp_login_url(home_url())));
    exit;
}

// Get order ID
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if (!$order_id) {
    wp_redirect(esc_url(home_url('/')));
    exit;
}

// Get order
$order = get_post($order_id);

if (!$order || $order->post_type !== 'wpigo_order') {
    wp_redirect(esc_url(home_url('/')));
    exit;
}

// Security check - user must own this order
if ($order->post_author != get_current_user_id()) {
    wp_redirect(esc_url(home_url('/')));
    exit;
}

// Get order meta
$all_meta = get_post_meta($order_id);
$order_number = $all_meta['_order_number'][0] ?? '';
$order_total = $all_meta['_order_total'][0] ?? 0;
$order_items = isset($all_meta['_order_items'][0]) ? maybe_unserialize($all_meta['_order_items'][0]) : array();
$buyer_email = $all_meta['_buyer_email'][0] ?? '';
$order_date = get_the_date('F j, Y', $order_id);

get_header();
?>

<div class="wpigo-wrapper">
    <main class="wpigo-content-container" role="main">

        <div class="wpigo-member-profile-page">

            <!-- Success Header -->
            <div class="wpigo-order-success-header">
                <div class="wpigo-order-success-icon" aria-hidden="true">✅</div>
                <h1 class="wpigo-order-success-title"><?php _e('Order Completed Successfully!', 'wpigo'); ?></h1>
                <p class="wpigo-order-success-subtitle">
                    <?php _e('Thank you for your purchase. Your order has been confirmed and processed.', 'wpigo'); ?>
                </p>
            </div>

            <!-- Order Details -->
            <div class="wpigo-order-details-grid">

                <!-- Order Information -->
                <div class="wpigo-member-card wpigo-order-info-card">
                    <div class="wpigo-member-card-header">
                        <h3 class="wpigo-member-card-title">
                            <span class="wpigo-member-card-icon">📋</span>
                            <?php _e('Order Information', 'wpigo'); ?>
                        </h3>
                    </div>
                    <div class="wpigo-member-card-body">
                        <div class="wpigo-order-info-list">
                            <div class="wpigo-order-info-item">
                                <span class="wpigo-order-info-label"><?php _e('Order Number:', 'wpigo'); ?></span>
                                <span class="wpigo-order-info-value"><?php echo esc_html($order_number); ?></span>
                            </div>
                            <div class="wpigo-order-info-item">
                                <span class="wpigo-order-info-label"><?php _e('Order Date:', 'wpigo'); ?></span>
                                <span class="wpigo-order-info-value"><?php echo esc_html($order_date); ?></span>
                            </div>
                            <div class="wpigo-order-info-item">
                                <span class="wpigo-order-info-label"><?php _e('Order Total:', 'wpigo'); ?></span>
                                <span class="wpigo-order-info-value">$<?php echo number_format($order_total, 2); ?></span>
                            </div>
                            <div class="wpigo-order-info-item">
                                <span class="wpigo-order-info-label"><?php _e('Billing Email:', 'wpigo'); ?></span>
                                <span class="wpigo-order-info-value"><?php echo esc_html($buyer_email); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Purchased Items -->
                <div class="wpigo-member-card wpigo-order-purchased-card">
                    <div class="wpigo-member-card-header wpigo-order-purchased-header">
                        <h3 class="wpigo-member-card-title">
                            <span class="wpigo-member-card-icon">🛒</span>
                            <?php _e('Purchased Items', 'wpigo'); ?>
                        </h3>
                    </div>
                    <div class="wpigo-member-card-body">
                        <?php if (is_array($order_items) && !empty($order_items)) : ?>
                            <div class="wpigo-order-items-list">
                                <?php foreach ($order_items as $item) : ?>
                                    <div class="wpigo-order-item">
                                        <div class="wpigo-order-item-details">
                                            <h4 class="wpigo-order-item-title">
                                                <a href="<?php echo esc_url(get_permalink($item['product_id'])); ?>">
                                                    <?php echo esc_html($item['title']); ?>
                                                </a>
                                            </h4>
                                            <p class="wpigo-order-item-price">$<?php echo number_format($item['price'], 2); ?></p>
                                        </div>
                                        <div class="wpigo-order-item-action">
                                            <a href="<?php echo esc_url(get_permalink($item['product_id'])); ?>" class="wpigo-member-btn wpigo-member-btn-secondary">
                                                <?php _e('View Product', 'wpigo'); ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

            <!-- License Keys - Per Product -->
            <div class="wpigo-member-card wpigo-license-keys-card">
                <div class="wpigo-member-card-header wpigo-order-license-header">
                    <h3 class="wpigo-member-card-title">
                        <span class="wpigo-member-card-icon">🔑</span>
                        <?php _e('Your License Keys', 'wpigo'); ?>
                    </h3>
                </div>
                <div class="wpigo-member-card-body">

                    <!-- Security Notice -->
                    <div class="wpigo-license-notice">
                        <strong><?php _e('⚠️ Important:', 'wpigo'); ?></strong> <?php _e('Keep these keys secure. They have been sent to your email', 'wpigo'); ?> (<strong><?php echo esc_html($buyer_email); ?></strong>).
                        <?php if (is_array($order_items) && count($order_items) > 1) : ?>
                            <br><strong><?php _e('Note:', 'wpigo'); ?></strong> <?php _e('Each product has unique license keys below.', 'wpigo'); ?>
                        <?php endif; ?>
                    </div>

                    <?php if (is_array($order_items) && !empty($order_items)) : ?>
                        <?php foreach ($order_items as $index => $item) : ?>
                            <?php
                            // Get license keys for this item
                            $license_keys = isset($item['license_keys']) ? $item['license_keys'] : array(
                                'purchase_code' => get_post_meta($order_id, '_purchase_code', true),
                                'api_key' => get_post_meta($order_id, '_api_key', true),
                                'secret_key' => get_post_meta($order_id, '_secret_key', true),
                            );
                            ?>

                            <!-- Product License Keys Section -->
                            <div class="wpigo-product-license-section">
                                <?php if (count($order_items) > 1) : ?>
                                    <h4 class="wpigo-product-license-title">
                                        📦 <?php echo esc_html($item['title']); ?>
                                    </h4>
                                <?php endif; ?>

                                <div class="wpigo-license-keys-grid-order">
                                    <!-- Purchase Code -->
                                    <div class="wpigo-license-key-item">
                                        <label class="wpigo-license-key-label"><?php _e('Purchase Code', 'wpigo'); ?></label>
                                        <div class="wpigo-license-key-input-group">
                                            <input
                                                type="text"
                                                class="wpigo-license-key-input"
                                                value="<?php echo esc_attr($license_keys['purchase_code']); ?>"
                                                readonly
                                                id="purchase-code-<?php echo $index; ?>"
                                            >
                                            <button
                                                type="button"
                                                class="wpigo-license-copy-btn"
                                                data-copy-target="#purchase-code-<?php echo $index; ?>"
                                                title="<?php esc_attr_e('Copy to clipboard', 'wpigo'); ?>"
                                                aria-label="<?php esc_attr_e('Copy purchase code to clipboard', 'wpigo'); ?>"
                                            >
                                                <?php _e('📋 Copy', 'wpigo'); ?>
                                            </button>
                                        </div>
                                        <small class="wpigo-license-key-help">
                                            <?php _e('Use this code for product activation and license verification', 'wpigo'); ?>
                                        </small>
                                    </div>

                                    <!-- API Key -->
                                    <div class="wpigo-license-key-item">
                                        <label class="wpigo-license-key-label"><?php _e('API Key', 'wpigo'); ?></label>
                                        <div class="wpigo-license-key-input-group">
                                            <input
                                                type="password"
                                                class="wpigo-license-key-input wpigo-toggleable-key"
                                                value="<?php echo esc_attr($license_keys['api_key']); ?>"
                                                readonly
                                                id="api-key-<?php echo $index; ?>"
                                            >
                                            <button
                                                type="button"
                                                class="wpigo-license-toggle-btn"
                                                data-toggle-target="#api-key-<?php echo $index; ?>"
                                                title="<?php esc_attr_e('Show/Hide', 'wpigo'); ?>"
                                            >
                                                👁 Show
                                            </button>
                                            <button
                                                type="button"
                                                class="wpigo-license-copy-btn"
                                                data-copy-target="#api-key-<?php echo $index; ?>"
                                                title="<?php esc_attr_e('Copy to clipboard', 'wpigo'); ?>"
                                                aria-label="<?php esc_attr_e('Copy API key to clipboard', 'wpigo'); ?>"
                                            >
                                                <?php _e('📋 Copy', 'wpigo'); ?>
                                            </button>
                                        </div>
                                        <small class="wpigo-license-key-help">
                                            <?php _e('Use this for public API requests and plugin updates', 'wpigo'); ?>
                                        </small>
                                    </div>

                                    <!-- Secret Key -->
                                    <div class="wpigo-license-key-item">
                                        <label class="wpigo-license-key-label"><?php _e('Secret Key', 'wpigo'); ?></label>
                                        <div class="wpigo-license-key-input-group">
                                            <input
                                                type="password"
                                                class="wpigo-license-key-input wpigo-toggleable-key"
                                                value="<?php echo esc_attr($license_keys['secret_key']); ?>"
                                                readonly
                                                id="secret-key-<?php echo $index; ?>"
                                            >
                                            <button
                                                type="button"
                                                class="wpigo-license-toggle-btn"
                                                data-toggle-target="#secret-key-<?php echo $index; ?>"
                                                title="<?php esc_attr_e('Show/Hide', 'wpigo'); ?>"
                                            >
                                                👁 Show
                                            </button>
                                            <button
                                                type="button"
                                                class="wpigo-license-copy-btn"
                                                data-copy-target="#secret-key-<?php echo $index; ?>"
                                                title="<?php esc_attr_e('Copy to clipboard', 'wpigo'); ?>"
                                                aria-label="<?php esc_attr_e('Copy secret key to clipboard', 'wpigo'); ?>"
                                            >
                                                <?php _e('📋 Copy', 'wpigo'); ?>
                                            </button>
                                        </div>
                                        <small class="wpigo-license-key-help">
                                            <?php _e('Use this for webhook verification and secure API calls', 'wpigo'); ?>
                                        </small>
                                    </div>
                                </div>

                                <!-- Download Button -->
                                <div style="text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e0e0e0;">
                                    <a href="<?php echo esc_url(home_url('/download/' . urlencode($license_keys['purchase_code']))); ?>"
                                       class="wpigo-member-btn wpigo-member-btn-success"
                                       style="font-size: 1.1rem; padding: 1rem 2rem;">
                                        <?php printf(esc_html__('⬇️ Download %s', 'wpigo'), esc_html($item['title'])); ?>
                                    </a>
                                    <p style="margin-top: 0.75rem; font-size: 0.875rem; color: #666;">
                                        <?php _e('Click to securely download your product file', 'wpigo'); ?>
                                    </p>
                                </div>
                            </div>

                        <?php endforeach; ?>
                    <?php endif; ?>

                </div>
            </div>

            <!-- Action Buttons -->
            <div class="wpigo-order-actions">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="wpigo-member-btn wpigo-member-btn-primary">
                    <?php _e('Continue Shopping', 'wpigo'); ?>
                </a>
                <a href="<?php
                    $current_user = wp_get_current_user();
                    echo esc_url(home_url('/member/' . urlencode($current_user->user_login) . '/'));
                ?>" class="wpigo-member-btn wpigo-member-btn-secondary">
                    <?php _e('View My Purchases', 'wpigo'); ?>
                </a>
            </div>

        </div>

    </main>
</div>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Order",
  "orderNumber": "<?php echo esc_js($order_number); ?>",
  "orderDate": "<?php echo get_the_date('c', $order_id); ?>",
  "orderStatus": "https://schema.org/OrderDelivered"
}
</script>

<?php get_footer(); ?>
