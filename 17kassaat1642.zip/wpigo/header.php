<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <?php
    // Global schemas
    if (is_front_page() || is_home()) {
        echo wpigo_get_organization_schema();
        echo wpigo_get_website_schema();
    }
    // Breadcrumb schema for all pages
    echo wpigo_get_breadcrumb_schema();
    ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="wpigo-header">
    <div class="wpigo-header-container">
        <div class="wpigo-header-inner">
            <div class="wpigo-site-branding">
                <?php
                if (has_custom_logo()) {
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    
                    if ($logo && isset($logo[0], $logo[1], $logo[2])) :
                    ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" 
                           class="custom-logo-link" 
                           rel="home"
                           aria-label="<?php echo esc_attr(get_bloginfo('name')); ?> - Home">
                            <img src="<?php echo esc_url($logo[0]); ?>" 
                                 alt="<?php echo esc_attr(get_bloginfo('name')); ?>" 
                                 fetchpriority="high"
                                 width="<?php echo esc_attr($logo[1]); ?>"
                                 height="<?php echo esc_attr($logo[2]); ?>">
                        </a>
                    <?php
                    endif;
                } else {
                    ?>
                    <h1 class="wpigo-site-title">
                        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                            <?php bloginfo('name'); ?>
                        </a>
                    </h1>
                    <?php
                }
                ?>
            </div>

            <nav class="wpigo-nav" aria-label="Primary Navigation">
                <input type="checkbox" 
                       id="wpigo-mobile-menu-toggle" 
                       class="wpigo-mobile-menu-toggle" 
                       aria-label="Toggle mobile menu">
                
                <label for="wpigo-mobile-menu-toggle"
                       class="wpigo-hamburger"
                       aria-label="Menu">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </label>

                <div class="wpigo-nav-content">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'wpigo-menu',
                        'fallback_cb' => false,
                    ));
                    ?>

                    <div class="wpigo-nav-actions">
                        <?php if (is_user_logged_in()) : ?>
                            <?php 
                            $current_user = wp_get_current_user();
                            $user_profile_url = home_url('/member/' . urlencode($current_user->user_login) . '/');
                            $logout_url = wp_logout_url(home_url('/'));
                            ?>
                            <a href="<?php echo esc_url($user_profile_url); ?>" 
                               class="wpigo-btn wpigo-btn-sell">
                                My Account
                            </a>
                            <a href="<?php echo esc_url($logout_url); ?>" 
                               class="wpigo-btn wpigo-btn-secondary">
                                Logout
                            </a>
                        <?php else : ?>
                            <a href="<?php echo esc_url(wp_login_url()); ?>" 
                               class="wpigo-btn wpigo-btn-secondary">
                                Login
                            </a>
                            <a href="<?php echo esc_url(wp_registration_url()); ?>" 
                               class="wpigo-btn wpigo-btn-primary">
                                Register
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>